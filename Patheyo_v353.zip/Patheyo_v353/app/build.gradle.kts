import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.services)
}

// ✅ ইন-অ্যাপ আপডেট: keystore.properties থেকে সাইনিং তথ্য পড়া (ফাইলটি GitHub-এ আপলোড করবেন না)
val keystoreProps = Properties()
val keystoreFile = rootProject.file("keystore.properties")
if (keystoreFile.exists()) keystoreProps.load(FileInputStream(keystoreFile))
// v197: keystore.properties তখনই কাজে লাগে যখন সত্যিই ঠিক আছে — কী-ফাইল এই কম্পিউটারে আছে ও পাসওয়ার্ড বসানো (placeholder নয়)।
// নইলে (যেমন GitHub-এর কম্পিউটারে Windows-পথ F:/… থাকলে) সাইনিং বাদ — বিল্ড ভাঙে না, সাধারণ debug কী দিয়ে সাইন হয়।
val keystoreOk: Boolean = keystoreFile.exists() &&
    (keystoreProps["storeFile"] as String?)?.let { File(it).isFile } == true &&
    listOf("storePassword", "keyAlias", "keyPassword").all { k ->
        val v = keystoreProps[k] as String?; !v.isNullOrBlank() && !v.contains("এখানে")
    }

android {
    namespace = "com.gunjoron.patheyo"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.gunjoron.patheyo"
        minSdk = 24
        targetSdk = 37
        versionCode = 12
        versionName = "3.2.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // ✅ ধাপ ১০: প্রিমিয়ামের পেমেন্ট লেয়ার (docs/PREMIUM_SETUP.md)
        //  DISTRIBUTION = "github" → বাংলাদেশি গেটওয়ে (bKash/Nagad/কার্ড) — আমাদের সার্ভার (server/payments) হয়ে
        //  DISTRIBUTION = "play"   → Google Play Billing (Play Store-এ গেলে শুধু এটা বদলান)
        //  PAY_API_URL  = সার্ভারের ঠিকানা (যেমন https://….cloudfunctions.net/pay) — খালি থাকলে পেওয়ালে "শীঘ্রই চালু" দেখায়
        buildConfigField("String", "DISTRIBUTION", "\"github\"")
        buildConfigField("String", "PAY_API_URL", "\"https://patheyo-pay-delta.vercel.app\"")   // SSLCommerz স্যান্ডবক্স (পরীক্ষা) — Vercel
    }

    buildFeatures { buildConfig = true }

    // ✅ ধাপ ১২: লাইব্রেরিগুলোর ১০০+ ভাষার অনুবাদ বাদ — অ্যাপ শুধু বাংলা ও ইংরেজি
    androidResources {
        localeFilters += listOf("en", "bn")
    }

    // ✅ ইন-অ্যাপ আপডেট: সাইনিং কনফিগ
    signingConfigs {
        create("release") {
            if (keystoreOk) {
                storeFile = File(keystoreProps["storeFile"] as String)
                storePassword = keystoreProps["storePassword"] as String
                keyAlias = keystoreProps["keyAlias"] as String
                keyPassword = keystoreProps["keyPassword"] as String
            }
        }
    }

    buildTypes {
        // v195: debug বিল্ডও একই release কী দিয়ে সাইন হয় (keystore.properties থাকলে) — Android Studio ও GitHub, দুই জায়গাতেই
        // একই SHA-1 হয়, তাই Google সাইন-ইন সবখানে এক নিয়মে চলে। keystore.properties না থাকলে সাধারণ debug কী।
        debug {
            if (keystoreOk) signingConfig = signingConfigs.getByName("release")
        }
        release {
            // v346 (নিরাপত্তা ৫): আসল কী (keystore.properties) না থাকলে রিলিজ বিল্ড থেমে যায় — debug কী দিয়ে সাইন করা
            // "রিলিজ" APK ভুল করে ছড়িয়ে পড়লে পরে আসল আপডেট আর বসত না। ফাইলের শেষে releaseSigningOk দেখুন।
            // শুধু নিজের পরীক্ষার জন্য debug কী চাইলে: -PallowDebugSignedRelease=true (এই APK কাউকে দেবেন না)।
            signingConfig = signingConfigs.getByName(if (keystoreOk) "release" else "debug")
            isDebuggable = false
            // v346 (নিরাপত্তা ৬): R8 এখন ডিফল্ট চালু — অব্যবহৃত কোড/রিসোর্স বাদ, নাম এলোমেলো (APK থেকে কোড পড়া কঠিন), APK ছোট।
            //   -PminifyRelease=false    → R8 বন্ধ (সমস্যা খুঁজতে)
            //   -PkeepAppCode=true       → শুধু অ্যাপের নিজের কোড (com.gunjoron.patheyo) নাম-বদল থেকে রক্ষা (proguard-keepapp.pro)
            //   -PshrinkResRelease=false → R8 চালু থাকলেও রিসোর্স-ছাঁটাই বন্ধ
            // নিয়ম: proguard-rules.pro (নতুন @JavascriptInterface এমনিতেই রক্ষা পায়; রিফ্লেকশন/নাম ধরে খোঁজা যোগ করলে নিয়ম লিখুন)
            val minify = (project.findProperty("minifyRelease") as String?) != "false"
            val keepApp = (project.findProperty("keepAppCode") as String?) == "true"
            val shrinkRes = (project.findProperty("shrinkResRelease") as String?) != "false"
            isMinifyEnabled = minify
            isShrinkResources = minify && shrinkRes
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keepApp) proguardFiles("proguard-keepapp.pro")
        }
    }

    @Suppress("DEPRECATION")
    aaptOptions {
        noCompress("mp3")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation("com.google.firebase:firebase-config-ktx:21.6.3")
    // ✅ নতুন: FCM push (অ্যাপ বন্ধ থাকলেও আরবি তারিখ আপডেট করতে)
    implementation("com.google.firebase:firebase-messaging-ktx:24.1.0")
    // ✅ নতুন: Realtime Database (রিয়েল-টাইম push-based sync)
    implementation("com.google.firebase:firebase-database-ktx:21.0.0")
    // ✅ ধাপ ৯: অ্যাকাউন্ট — Firebase Authentication (Google + ইমেইল) ও Android Credential Manager (Google-এর এক-ট্যাপ সাইন-ইন)
    implementation("com.google.firebase:firebase-auth:23.1.0")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    // ✅ ধাপ ১০: Google Play Billing — কোড তৈরি, কিন্তু DISTRIBUTION = "play" না হলে কখনো চালু হয় না
    implementation("com.android.billingclient:billing-ktx:7.1.1")
    
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    // ✅ v168: কুরআন তিলাওয়াতের পূর্ণ ব্যাকগ্রাউন্ড প্লেয়ার (ফোরগ্রাউন্ড সার্ভিস + নোটিফিকেশন কন্ট্রোল + মিডিয়া-সেশন)
    implementation("androidx.media3:media3-exoplayer:1.8.0")
    implementation("androidx.media3:media3-session:1.8.0")
    implementation("com.google.guava:guava:33.3.1-android")
    // ✅ ইন-অ্যাপ আপডেট: lifecycleScope ও ProcessLifecycleOwner-এর জন্য
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}

// v346 (নিরাপত্তা ৫): রিলিজ বিল্ডে আসল সাইনিং কী বাধ্যতামূলক।
// keystore.properties না থাকলে/ভুল হলে assembleRelease/bundleRelease শুরুতেই পরিষ্কার বার্তা দিয়ে থামে।
// (configuration-cache-বান্ধব: কাজের ভেতরে শুধু Boolean মান, project নয়)
val releaseSigningOk: Boolean = keystoreOk ||
    (project.findProperty("allowDebugSignedRelease") as String?) == "true"
tasks.matching { it.name == "preReleaseBuild" }.configureEach {
    val signingOk = releaseSigningOk          // স্থানীয় কপি — কাজের ভেতরে স্ক্রিপ্টের রেফারেন্স যায় না
    doFirst {
        if (!signingOk) throw GradleException(
            "রিলিজ বিল্ড থামানো হলো: keystore.properties নেই বা ঠিক নেই (storeFile/storePassword/keyAlias/keyPassword)।\n" +
            "Release build stopped: a real signing key is required. See docs/GITHUB_BUILD_SIGNING.md.\n" +
            "Local test only: add -PallowDebugSignedRelease=true (never distribute that APK)."
        )
    }
}
