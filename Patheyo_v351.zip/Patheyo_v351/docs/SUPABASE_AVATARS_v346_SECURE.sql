-- =============================================================================
-- পাথেয় v346 — নিরাপত্তা সংশোধন ১: প্রোফাইল ছবির বাকেট (avatars) লক করা
-- =============================================================================
-- সমস্যা (আগে): anon (পাবলিক) কী দিয়ে যে কেউ avatars বাকেটের সব ফাইলের নাম (= সব ইউজারের uid) দেখতে পারত,
--               আর যেকোনো ইউজারের ছবি বদলে/মুছে দিতে পারত। anon কী APK থেকে সহজেই বের করা যায়।
-- সমাধান (এখন): লেখা/বদল/মোছা শুধু Edge Function "avatar" দিয়ে (service_role; Firebase টোকেন যাচাই করে শুধু নিজের ফাইল)।
--               anon/authenticated-এর জন্য কোনো policy নেই → তালিকা দেখা, লেখা, মোছা — সব বন্ধ।
--               বাকেট পাবলিক থাকে, তাই ছবি দেখা আগের মতোই চলে: /storage/v1/object/public/avatars/{uid}.jpg
--
-- চালানোর ক্রম (জরুরি):
--   ১) আগে Edge Function "avatar" ডিপ্লয় করুন (docs/supabase-functions/avatar/index.ts — নির্দেশনা: docs/SECURITY_SETUP_v346.md)
--   ২) তারপর এই পুরো ফাইলটি Supabase → SQL Editor-এ পেস্ট করে Run
--   আগে ২ করলে নতুন ফাংশন বসানো না হওয়া পর্যন্ত কেউ ছবি বদলাতে পারবে না (দেখা চলবে)।
-- বারবার চালালেও ক্ষতি নেই।
-- =============================================================================

-- বাকেট: পাবলিক পড়া, সর্বোচ্চ ১০০KB, শুধু JPEG (আগের মতোই)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 102400, array['image/jpeg'])
on conflict (id) do update
  set public = true,
      file_size_limit = 102400,
      allowed_mime_types = array['image/jpeg'];

-- আগের খোলা নিয়মগুলো সরানো (select = তালিকা দেখা, insert/update/delete = লেখা/বদল/মোছা)
drop policy if exists "avatars_select" on storage.objects;
drop policy if exists "avatars_insert" on storage.objects;
drop policy if exists "avatars_update" on storage.objects;
drop policy if exists "avatars_delete" on storage.objects;

-- ইচ্ছে করে কোনো নতুন policy নেই। service_role (Edge Function) RLS এড়িয়ে চলে, তাই শুধু সে-ই লিখতে পারে।

-- যাচাই: নিচের কোয়েরি avatars-এর জন্য ০টি সারি দেখালে ঠিক আছে
select policyname from pg_policies
where schemaname = 'storage' and tablename = 'objects' and policyname like 'avatars_%';
