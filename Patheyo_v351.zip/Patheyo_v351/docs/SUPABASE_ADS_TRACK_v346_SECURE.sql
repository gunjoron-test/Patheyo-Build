-- =============================================================================
-- পাথেয় v346 — নিরাপত্তা সংশোধন ৩: এডের ভিউ/ক্লিক গোনায় ভুয়া সংখ্যা ঠেকানো
-- =============================================================================
-- সমস্যা (আগে): অ্যাপ anon (পাবলিক) কী দিয়ে সরাসরি public.track_ad(p_ad, p_event) ডাকত। anon কী APK থেকে বের করা
--   যায়, তাই যে কেউ স্ক্রিপ্ট চালিয়ে লাখো ভুয়া ভিউ/ক্লিক বসাতে পারত — বিজ্ঞাপনদাতার পরিসংখ্যান ভুল হতো।
-- সমাধান (এখন):
--   • অ্যাপ ডাকে নতুন public.track_ad_v2(p_ad, p_event, p_device)। p_device = অ্যাপ-ইনস্টলের এলোমেলো আইডি
--     (কারো পরিচয়ের সাথে যুক্ত নয়)।
--   • একই ডিভাইস থেকে একই এডের "view" দিনে একবারই গোনা; "click"/"copy" দিনে সর্বোচ্চ ৩ বার।
--   • একই IP থেকে ঘণ্টায় সর্বোচ্চ ৬০টি গণনা (ডিভাইস-আইডি বদলে বদলে পাঠালেও আটকায়)। IP সংরক্ষিত হয় না —
--     শুধু তার md5-হ্যাশ, তাও ৩ দিন পর মুছে যায়।
--   • পুরনো public.track_ad আর anon/authenticated ডাকতে পারে না — শুধু track_ad_v2 ভেতর থেকে ডাকে।
--     (track_ad-এর ভেতরের হিসাব-কোড বদলানো হয়নি; ওয়েবসাইটের পরিসংখ্যান আগের মতোই কাজ করবে।)
--
-- চালানোর ক্রম: নতুন অ্যাপ (v346) রিলিজের পর এই ফাইল Supabase → SQL Editor-এ Run।
--   আগে চালালে পুরনো অ্যাপগুলোর গণনা বন্ধ হবে (অ্যাপ নিজে চলবে, শুধু পরিসংখ্যান যাবে না)।
--   চাইলে নিচের "পুরনো অ্যাপের জন্য সাময়িক" অংশ ব্যবহার করুন।
-- বারবার চালালেও ক্ষতি নেই।
-- =============================================================================

-- ১) গোনার খাতা (শুধু ফাংশনের ভেতর থেকে ছোঁয়া যায় — RLS চালু, কোনো policy নেই)
create table if not exists public.ad_track_seen (
  ad      text        not null,
  device  text        not null,
  event   text        not null,
  day     date        not null default current_date,
  n       int         not null default 1,
  primary key (ad, device, event, day)
);
create table if not exists public.ad_track_ip (
  ip_hash text        not null,
  hour    timestamptz not null,
  n       int         not null default 1,
  primary key (ip_hash, hour)
);
alter table public.ad_track_seen enable row level security;
alter table public.ad_track_ip   enable row level security;
revoke all on public.ad_track_seen from anon, authenticated;
revoke all on public.ad_track_ip   from anon, authenticated;

-- ২) নতুন গণনা-ফাংশন
create or replace function public.track_ad_v2(p_ad text, p_event text, p_device text)
returns boolean
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_ip   text;
  v_hash text;
  v_n    int;
  v_lim  int;
begin
  -- ইনপুট যাচাই
  if p_ad is null or p_ad !~ '^[0-9a-fA-F-]{36}$' then return false; end if;
  if p_event is null or p_event not in ('view', 'click', 'copy') then return false; end if;
  if p_device is null or p_device !~ '^[A-Za-z0-9-]{16,64}$' then return false; end if;

  -- IP-সীমা: ঘণ্টায় ৬০ (Supabase-এর API গেটওয়ে আসল IP হেডারে দেয়)
  begin
    v_ip := coalesce(
      nullif(current_setting('request.headers', true), '')::json ->> 'cf-connecting-ip',
      split_part(nullif(current_setting('request.headers', true), '')::json ->> 'x-forwarded-for', ',', 1),
      'none');
  exception when others then v_ip := 'none';
  end;
  v_hash := md5('patheyo-ads:' || trim(v_ip));
  insert into public.ad_track_ip as t (ip_hash, hour) values (v_hash, date_trunc('hour', now()))
    on conflict (ip_hash, hour) do update set n = t.n + 1
    returning t.n into v_n;
  if v_n > 60 then return false; end if;

  -- একই ডিভাইস-এড-ঘটনা: view দিনে ১বার, click/copy দিনে ৩বার
  v_lim := case when p_event = 'view' then 1 else 3 end;
  insert into public.ad_track_seen as s (ad, device, event, day) values (lower(p_ad), p_device, p_event, current_date)
    on conflict (ad, device, event, day) do update set n = s.n + 1
    returning s.n into v_n;
  if v_n > v_lim then return false; end if;

  -- আসল গণনা: পুরনো track_ad (যার ভেতরের হিসাব ওয়েবসাইট ব্যবহার করে)। প্যারামিটারের ধরন uuid বা text — দুটোতেই চলে।
  execute format('select public.track_ad(%L, %L)', p_ad, p_event);

  -- পুরনো খাতা মাঝে মাঝে পরিষ্কার (প্রায় প্রতি ২০০ ডাকে একবার)
  if random() < 0.005 then
    delete from public.ad_track_seen where day < current_date - 3;
    delete from public.ad_track_ip   where hour < now() - interval '1 day';
  end if;
  return true;
exception when others then
  return false;   -- গণনায় সমস্যা হলে অ্যাপকে কিছু জানানোর দরকার নেই
end;
$$;

revoke all on function public.track_ad_v2(text, text, text) from public;
grant execute on function public.track_ad_v2(text, text, text) to anon, authenticated;

-- ৩) পুরনো track_ad সরাসরি ডাকা বন্ধ (সব রূপ/ওভারলোড)। track_ad_v2 security definer, তাই ভেতর থেকে ডাকতে পারে।
do $$
declare r record;
begin
  for r in select p.oid::regprocedure as sig
           from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.proname = 'track_ad'
  loop
    execute format('revoke execute on function %s from public, anon, authenticated', r.sig);
  end loop;
end $$;

-- ৪) যাচাই: নিচে "track_ad_v2 | true" আর "track_ad | false" দেখালে ঠিক আছে
select p.proname, has_function_privilege('anon', p.oid, 'execute') as anon_can_call
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('track_ad', 'track_ad_v2');

-- -----------------------------------------------------------------------------
-- পুরনো অ্যাপের জন্য সাময়িক (ঐচ্ছিক): বেশিরভাগ ইউজার v346-এ না আসা পর্যন্ত পুরনো অ্যাপের গণনাও চালু রাখতে চাইলে
-- নিচের লাইনটি আলাদা করে চালান। পরে আবার উপরের ৩ নম্বর অংশ চালিয়ে বন্ধ করে দিন।
--   grant execute on function public.track_ad(uuid, text) to anon;
-- -----------------------------------------------------------------------------
