// Supabase Edge Function: avatar  (পাথেয় v346 — নিরাপত্তা সংশোধন ১)
// কাজ: সাইন-ইন করা ইউজারের প্রোফাইল ছবি Storage-এর "avatars/{uid}.jpg"-এ রাখা বা মোছা।
//
// কেন: আগে অ্যাপ নিজেই anon (পাবলিক) কী দিয়ে Storage-এ লিখত। anon কী APK থেকে সহজে বের করা যায়, আর বাকেটের
// নিয়ম শুধু ফাইলের নাম দেখত — তাই যে কেউ সব ফাইলের নাম (= সবার uid) দেখে যেকোনো ইউজারের ছবি বদলে/মুছে দিতে পারত।
// এখন: লেখা/মোছা শুধু এই ফাংশন দিয়ে। ফাংশন Firebase ID টোকেন (x-firebase-token) Google-এর পাবলিক কী দিয়ে যাচাই করে
// uid বের করে, আর শুধু সেই uid-এর ফাইলটাই ছোঁয়। ফাইলের নাম ক্লায়েন্ট ঠিক করে না।
//
// অনুরোধ (POST, JSON):
//   { "action": "upload", "data": "<base64 JPEG>" }   → { ok: true, size }
//   { "action": "delete" }                            → { ok: true }
// ছবি দেখা (GET) আগের মতোই পাবলিক URL দিয়ে: /storage/v1/object/public/avatars/{uid}.jpg — এজন্য কোনো policy লাগে না।
//
// service_role কী Supabase নিজেই এই ফাংশনে দেয় (SUPABASE_SERVICE_ROLE_KEY); অ্যাপে বা কোনো ফাইলে কখনো নয়।
import { createClient } from "npm:@supabase/supabase-js@2";
import { createRemoteJWKSet, jwtVerify } from "npm:jose@5";

const PROJECT_ID = Deno.env.get("FIREBASE_PROJECT_ID") ?? "hijri-tarikh";
const JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"),
);
const db = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } },
);
const BUCKET = "avatars";
const MAX_BYTES = 100 * 1024;          // অ্যাপও ১০০KB-এর মধ্যে ছোট করে পাঠায় (AuthBridge.fitAvatar)
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-firebase-token",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...CORS, "Content-Type": "application/json" } });

async function uidFrom(req: Request): Promise<string | null> {
  const tok = req.headers.get("x-firebase-token");
  if (!tok) return null;
  try {
    const { payload } = await jwtVerify(tok, JWKS, {
      issuer: `https://securetoken.google.com/${PROJECT_ID}`,
      audience: PROJECT_ID,
    });
    const sub = payload.sub;
    // Firebase uid: অক্ষর ও সংখ্যা (১০-১২৮)। অন্য কিছু হলে ফাইলের নামে বসানো হয় না।
    return typeof sub === "string" && /^[A-Za-z0-9]{10,128}$/.test(sub) ? sub : null;
  } catch (_) {
    return null;
  }
}

function decodeBase64(s: string): Uint8Array | null {
  try {
    const clean = s.includes(",") ? s.slice(s.indexOf(",") + 1) : s;   // "data:image/jpeg;base64,..." হলেও চলে
    const bin = atob(clean.replace(/\s+/g, ""));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  } catch (_) {
    return null;
  }
}

/** সত্যিই JPEG কি না: শুরুতে FF D8 FF, শেষে FF D9 */
function isJpeg(b: Uint8Array): boolean {
  return b.length > 4 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff &&
    b[b.length - 2] === 0xff && b[b.length - 1] === 0xd9;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ ok: false, msg: "POST দিন" }, 405);

  const uid = await uidFrom(req);
  if (!uid) return json({ ok: false, msg: "সাইন-ইন যাচাই হয়নি" }, 401);

  let body: { action?: string; data?: unknown };
  try { body = await req.json(); } catch (_) { return json({ ok: false, msg: "ভুল অনুরোধ" }, 400); }

  const path = `${uid}.jpg`;                 // নাম সার্ভার ঠিক করে — ক্লায়েন্টের দেওয়া কোনো নাম নেওয়া হয় না

  if (body.action === "upload") {
    if (typeof body.data !== "string" || body.data.length > MAX_BYTES * 2) return json({ ok: false, msg: "ছবি বড়" }, 413);
    const bytes = decodeBase64(body.data);
    if (!bytes) return json({ ok: false, msg: "ছবি পড়া যায়নি" }, 400);
    if (bytes.length > MAX_BYTES) return json({ ok: false, msg: "ছবি ১০০KB-এর বেশি" }, 413);
    if (!isJpeg(bytes)) return json({ ok: false, msg: "শুধু JPEG ছবি" }, 415);
    const { error } = await db.storage.from(BUCKET).upload(path, bytes, {
      contentType: "image/jpeg", upsert: true, cacheControl: "60",
    });
    if (error) return json({ ok: false, msg: error.message }, 500);
    return json({ ok: true, size: bytes.length });
  }

  if (body.action === "delete") {
    const { error } = await db.storage.from(BUCKET).remove([path]);
    if (error) return json({ ok: false, msg: error.message }, 500);
    return json({ ok: true });
  }

  return json({ ok: false, msg: "অজানা action" }, 400);
});
