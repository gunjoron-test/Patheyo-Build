# পাথেয় — নিরাপত্তার নিয়ম (Security Rules)

> **যেকোনো AI বা ডেভেলপার এই প্রজেক্টে কাজ শুরুর আগে এই ফাইল পুরোটা পড়বেন এবং প্রতিটি পরিবর্তনে মানবেন।**
> **Every AI assistant or developer MUST read this file fully before changing this project, and follow it in every change.**
>
> কোনো নিয়ম ভাঙতে হলে আগে মালিককে (অ্যাপের মালিক) কারণসহ জিজ্ঞেস করুন — নিজে থেকে নয়।
> If a task seems to require breaking a rule, STOP and ask the owner first, explaining why.
>
> সর্বশেষ হালনাগাদ: v346 (নিরাপত্তা-সংশোধনের ৭টি কাজ — `docs/SECURITY_SETUP_v346.md`)

---

## ০) মূল ধারণা (Threat model)

- APK-র ভেতরের সবকিছু **পাবলিক** ধরে নিন। যে কেউ APK খুলে Supabase anon কী, Firebase কনফিগ, সব URL দেখতে পারে।
  → anon কী দিয়ে যা করা যায়, তা **পৃথিবীর যে কেউ** করতে পারে।
- WebView-এর পেজগুলো ১৮টি নেটিভ ব্রিজ (অ্যাকাউন্ট, ব্যাকআপ, পেমেন্ট, ফাইল…) ছুঁতে পারে। তাই পেজে বাইরের কোনো কোড/লিংক ঢুকলে
  তা পুরো অ্যাপের নিয়ন্ত্রণ পায়। **বাইরে থেকে আসা প্রতিটি লেখা অবিশ্বাস্য।**
- ইউজারের ফোনে রাখা কিছুই (localStorage, SharedPreferences) প্রমাণ নয় — রুট করা ফোনে সব বদলানো যায়।
  টাকা, প্রিমিয়াম, অন্যের ডেটা — এসব সিদ্ধান্ত **শুধু সার্ভারে**।

---

## ১) গোপন তথ্য (Secrets)

1. `service_role` কী, পেমেন্ট গেটওয়ের পাসওয়ার্ড (SSLC_STORE_PASSWD, bKash, ShurjoPay), Firebase সার্ভিস-অ্যাকাউন্ট JSON,
   `CHECK_TOKEN`, keystore ও তার পাসওয়ার্ড — **কখনো অ্যাপের কোডে, assets-এ, জিপে বা GitHub-এ নয়।**
   শুধু হোস্টের Environment Variables / GitHub Secrets / Supabase Secrets-এ।
2. `.env`, `keystore.properties`, `*.jks`, `*.keystore` কখনো জিপ বা কমিটে নয় (`.gitignore`-এ আছে — সরাবেন না)।
3. অ্যাপে শুধু এগুলো থাকতে পারে: Supabase URL + **anon** কী, Firebase-এর `google-services.json`, পাবলিক ওয়েব-ঠিকানা।
4. লগে (Log.d, console.log) টোকেন, পাসওয়ার্ড, ইমেইল, পূর্ণ uid লিখবেন না।

## ২) সার্ভার/ডাটাবেস — anon কী দিয়ে কী করা যাবে

1. Supabase-এ নতুন টেবিল = **RLS চালু, anon/authenticated-এর জন্য কোনো policy নয়** (ডিফল্ট সব বন্ধ)।
   ইউজারের নিজের ডেটা ছুঁতে হলে **Edge Function** বানান, যে `x-firebase-token` হেডারের Firebase ID টোকেন
   `jose`-এর `jwtVerify` দিয়ে (issuer + audience সহ) যাচাই করে uid নেয় — নমুনা: `docs/supabase-functions/cloud-sync`, `avatar`।
2. ক্লায়েন্ট যে uid/ফাইলের নাম/ইউজার-আইডি পাঠায় তা **কখনো বিশ্বাস নয়** — uid শুধু যাচাই-করা টোকেন থেকে।
3. anon-এর জন্য খোলা RPC (`security definer`) হলে: প্রতিটি ইনপুট যাচাই (ধরন, দৈর্ঘ্য, রেজেক্স), `set search_path = public, pg_temp`,
   আর সংখ্যা বাড়ায় এমন কিছু হলে **রেট-লিমিট/ডুপ্লিকেট-রোধ** (নমুনা: `docs/SUPABASE_ADS_TRACK_v346_SECURE.sql`)।
4. Storage বাকেট: anon-এর জন্য insert/update/delete/select (তালিকা) policy নয়। লেখা শুধু Edge Function দিয়ে।
   পাবলিক বাকেটের ফাইল দেখা এমনিতেই চলে — তার জন্য select policy লাগে না।
5. Firebase Realtime Database: `docs/database.rules.json` মানুন। **উপরের স্তরে `.write`/`.read` দিলে নিচে false দিয়ে আটকানো যায় না।**
   `users/$uid/premium`-এ অ্যাপের লেখার অনুমতি কখনো নয় — শুধু পেমেন্ট সার্ভার (Admin SDK)।
6. SQL ফাইল বারবার চালালেও যেন ক্ষতি না হয় (`if not exists`, `create or replace`, `drop policy if exists`)।

## ৩) পেমেন্ট ও প্রিমিয়াম

1. দাম সবসময় সার্ভারের `server/payments/plans.js` থেকে — অ্যাপ থেকে আসা টাকার অঙ্ক/প্ল্যান-মেয়াদ বিশ্বাস নয়।
2. পেমেন্ট "সফল" = গেটওয়ের নিজস্ব যাচাই-API (যেমন SSLCommerz validationserverAPI) দিয়ে অর্ডার-আইডি, পরিমাণ, মুদ্রা মিলিয়ে।
   শুধু রিডাইরেক্ট/IPN-এর `status=success` দেখে নয়। একই অর্ডার একবারই (ট্রানজেকশন)।
3. প্রিমিয়াম লেখে শুধু সার্ভার। অ্যাপের `PremiumBridge` শুধু পড়ে; ফোনের কপি = অফলাইন ক্যাশ (uid-বাঁধা, ৩০ দিন)।
   **প্রিমিয়াম-কন্টেন্ট যদি সত্যিই মূল্যবান হয় (যেমন ডাউনলোডযোগ্য ফাইল), সার্ভার যাচাই করে তবেই দেবে।**
4. সার্ভারের ডিবাগ/সেটআপ পাতা (যেমন `/check`) শুধু গোপন টোকেন দিয়ে; টোকেন ছাড়া 404। কোনো গোপন মানের অংশও দেখাবে না।
5. খোলা endpoint-এ রেট-লিমিট (`rateLimit()` — `server/payments/app.js`)। `x-powered-by` বন্ধ।

## ৪) WebView ও JS (assets/)

1. বাইরে থেকে আসা লেখা (এড, নোটিফিকেশন, সার্ভার JSON, ডাউনলোড করা ফাইল, ইউজারের ইনপুট) DOM-এ বসাতে:
   `textContent` ব্যবহার করুন; `innerHTML` লাগলে প্রতিটি মান `esc()` করে। কখনো `eval`, `new Function`, `document.write`
   বাইরের লেখা দিয়ে নয়।
2. বাইরে থেকে আসা URL (href/src) = শুধু `https://` (নমুনা: `ads/ads.js` → `safeHttps()`)। `javascript:`, `data:`, `file:`,
   `intent:`, `content:` কখনো নয়। সব পেজে `shared/link-guard.js` সবার আগে লোড থাকে — সরাবেন না; নতুন পেজেও যোগ করুন।
3. WebView-এ বাইরের ওয়েবসাইট লোড নয়। বাইরের লিংক ফোনের ব্রাউজারে খোলে (`MainActivity.shouldOverrideUrlLoading`) — এটা বদলাবেন না।
4. নতুন `@JavascriptInterface` মেথড: ইনপুট যাচাই (দৈর্ঘ্য, ফরম্যাট), ভারী কাজ ব্যাকগ্রাউন্ড থ্রেডে, ফাইল-পথ/URL/SQL সরাসরি JS থেকে নয়।
   ব্রিজ দিয়ে কখনো "যেকোনো URL খোলো/ডাউনলোড করো/যেকোনো ফাইল পড়ো" ধরনের খোলা ক্ষমতা নয়।
5. `evaluateJavascript`-এ বাইরের লেখা বসাতে হলে `JSONObject.quote()` দিয়ে (নমুনা: `PremiumBridge.emit`)। ডিপ-লিংকের মান রেজেক্সে যাচাই
   (নমুনা: `MainActivity.runGo`)।
6. এই সেটিংস বদলাবেন না: `setWebContentsDebuggingEnabled` (বন্ধ), `allowFileAccessFromFileURLs`/`allowUniversalAccessFromFileURLs`
   (বন্ধ), `mixedContentMode = NEVER_ALLOW`।

## ৫) Android

1. `AndroidManifest.xml`: `allowBackup="false"`, `usesCleartextTraffic="false"` — বদলাবেন না।
   নতুন activity/service/receiver = `exported="false"`, যদি না সিস্টেম/অন্য অ্যাপের সত্যিই লাগে; লাগলে intent-এর প্রতিটি মান যাচাই।
2. FileProvider `exported="false"`; শুধু নির্দিষ্ট ফোল্ডার (`res/xml/file_paths.xml`) — পুরো স্টোরেজ নয়।
3. ইউজারদের দেওয়া APK = **রিলিজ বিল্ড** (debuggable নয়, R8 চালু, আসল কী)। debug APK কখনো ইউজারদের নয়
   (debug APK-তে USB দিয়ে অ্যাপের সব ডেটা পড়া যায়)। GitHub workflow এটা নিশ্চিত করে — শর্তগুলো সরাবেন না।
4. রিলিজে আসল কী বাধ্যতামূলক (`app/build.gradle.kts` → `releaseSigningOk` ও preReleaseBuild-এর পরীক্ষা)। `-PallowDebugSignedRelease=true` শুধু নিজের পরীক্ষায়।
5. R8: নতুন কোডে রিফ্লেকশন/নাম ধরে ক্লাস খোঁজা যোগ করলে `proguard-rules.pro`-তে নিয়ম লিখুন। R8 বন্ধ করে "সমস্যা সমাধান" নয়।
6. ইন-অ্যাপ আপডেটের APK শুধু নিজেদের `https://` ঠিকানা থেকে; Android নিজেই একই সাইনিং-কী যাচাই করে।

## ৬) প্রতিটি পরিবর্তনের আগে-পরে চেকলিস্ট (AI-এর জন্য বাধ্যতামূলক)

- [ ] নতুন কোনো সার্ভার/ডাটাবেস অনুমতি anon-কে দিচ্ছি? → দিলে কেন, আর অপব্যবহার কীভাবে আটকানো — ব্যাখ্যা লিখুন।
- [ ] বাইরের ডেটা DOM/URL/SQL/ফাইল-পথে যাচ্ছে? → যাচাই/এস্কেপ করেছি।
- [ ] কোনো গোপন মান কোডে/জিপে/লগে? → না।
- [ ] টাকা/প্রিমিয়াম/অন্যের ডেটার সিদ্ধান্ত ক্লায়েন্টে? → না, সার্ভারে।
- [ ] নতুন exported কম্পোনেন্ট / নতুন JS ব্রিজ মেথড? → ইনপুট যাচাই আছে।
- [ ] এই ফাইলের কোনো নিয়মের সাথে সংঘাত? → থাকলে কাজ থামিয়ে মালিককে জিজ্ঞেস।
- [ ] রিলিজ নোটে (`docs/RELEASE_NOTE_vXXX.md`) নিরাপত্তা-প্রভাব লিখেছি; সার্ভার/SQL বদলালে চালানোর ক্রম লিখেছি।

## ৭) জানা গ্রহণযোগ্য ঝুঁকি (ইচ্ছে করে রাখা)

- রুট করা ফোনে কেউ নিজের ফোনেই প্রিমিয়াম ফিচার খুলতে পারে (সার্ভারে প্রিমিয়াম পায় না, অন্য কারো ক্ষতি নেই)।
- localStorage-এর আমল/বুকমার্ক এনক্রিপ্টেড নয় — ফোনের নিজের সুরক্ষার (লক-স্ক্রিন) ওপর নির্ভর; ফোন-ব্যাকআপে যায় না।
- anon কী পাবলিক — এটা Supabase-এর নকশা অনুযায়ী স্বাভাবিক; নিরাপত্তা আসে RLS/ফাংশন থেকে, কী লুকিয়ে নয়।
