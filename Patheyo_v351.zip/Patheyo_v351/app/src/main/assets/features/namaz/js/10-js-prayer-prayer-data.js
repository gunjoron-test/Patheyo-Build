/* js/prayer/prayer-data.js */
/* =============================================================================
   নামাজের সময়ের ডেটা আনা
   লোকেশন নেওয়া, নামাজের সময় ফেচ ও প্রসেস, নেটিভ আজান ব্রিজে সিঙ্ক,
   আবহাওয়া ও এলাকার নাম আনা।
   ============================================================================= */

/* ধাপ ৩: সময়ের উৎস — 'live' (aladhan থেকে আজকেরটা), 'offline' (ফোনেই হিসাব, shared/prayer-calc.js), 'cache' (পুরনো সংরক্ষিত) */
let nzSource = 'cache';
let lastRawTimings = null;       /* এপিআই/হিসাবের আসল সময় (মিনিট সমন্বয় ছাড়া) — ক্যাশে এটিই রাখা হয়, নইলে সমন্বয় দুবার যোগ হতো */
/* হিসাবের পদ্ধতি: ব্যবহারকারী নিজে বেছে নিলে সেটি (userPrayerMethodId), নইলে অ্যাডমিন/ফায়ারবেসের (prayerMethodId) */
function nzMethodId() {
    const u = parseInt(localStorage.getItem('userPrayerMethodId') || '0', 10);
    const adm = parseInt(window._nativeMethodId, 10) || 1;
    /* স্বয়ংক্রিয় = বাংলাদেশে থাকলে ইসলামিক ফাউন্ডেশন (১০০, সম্পূর্ণ অফলাইন); বাইরে হলে অ্যাডমিনের পদ্ধতি (shared/prayer-calc.js) */
    if (window.PtPrayer && typeof PtPrayer.effectiveMethod === 'function') return PtPrayer.effectiveMethod(u, adm, userLat, userLng);
    return u > 0 && u !== 100 ? u : adm;
}
/* ইসলামিক ফাউন্ডেশনের সূচীতে সময় চলছে কি না */
function nzIsIfbd() { return nzMethodId() === 100; }
/* মাযহাব/পদ্ধতি/মিনিট বদলালে: সাথে সাথে ফোনেই নতুন হিসাব দেখাও, তারপর অনলাইনে মিলিয়ে নাও */
function nzRecompute() {
    nzRenderOffline(new Date(), true);       /* অনলাইনের সময় থাকলে শুধু নতুন সমন্বয় বসে; নইলে ফোনের নতুন হিসাব */
    syncAlarmConfigsToNativeBridge();
    fetchCorePrayerData();
}

// নেটিভ ব্যাকগ্রাউন্ড আজান (AlarmManager) সিস্টেমকে প্রতিটা ওয়াক্তের চূড়ান্ত (কাস্টম/অটো) সময় জানানো হলো
function syncAlarmConfigsToNativeBridge() {
    if (!(window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.saveAlarmConfigs === 'function')) return;
    const resolved = {};
    for (const w in waqtConfigs) {
        const c = waqtConfigs[w];
        let timeStr = "";
        if (c.isCustom) {
            let h24 = parseInt(c.hour);
            if (c.ampm === "PM" && h24 < 12) h24 += 12;
            if (c.ampm === "AM" && h24 === 12) h24 = 0;
            timeStr = `${String(h24).padStart(2,'0')}:${String(c.minute).padStart(2,'0')}`;
        } else if (globalTimings && globalTimings[w]) {
            timeStr = globalTimings[w];
        }
        resolved[w] = { active: !!c.active, time: timeStr };
    }
    try { window.AndroidWidgetBridge.saveAlarmConfigs(JSON.stringify(resolved)); } catch(e) { console.error('alarm config sync failed', e); }
}

async function requestGeoLocationAndFetch() {
    if (navigator.geolocation) {
        // ২ সেকেন্ড ওয়েট করব লোকেশন পাওয়ার জন্য, না পেলে ডিফল্ট (ঢাকা) দিয়ে শুরু হবে
        const timeout = setTimeout(() => { fetchCorePrayerData(); }, 3000);
        navigator.geolocation.getCurrentPosition(p => {
            clearTimeout(timeout);
            userLat = p.coords.latitude; userLng = p.coords.longitude;
            if (nzSource !== 'live') { try { nzRenderOffline(new Date(), false); } catch (e) {} }   /* নতুন লোকেশনের সময় ইন্টারনেটের অপেক্ষা না করেই */
            fetchCorePrayerData();
        }, err => {
            clearTimeout(timeout);
            fetchCorePrayerData();
        }, { timeout: 3000 });
    } else { fetchCorePrayerData(); }
}

// মূল নামাজের সময়সূচি আনার ফাংশন — এখন টাইমআউট + স্বয়ংক্রিয় রিট্রাই সহ, যাতে সাময়িক নেট/সার্ভার
// সমস্যায় সাথে সাথে ভুলভাবে "নেট নেই" না দেখিয়ে, প্রকৃত সমস্যা অনুযায়ী সঠিক আচরণ করে।
let corePrayerFetchInProgress = false;
async function fetchCorePrayerData(attempt = 1) {
    if (corePrayerFetchInProgress && attempt === 1) return; // একই সাথে একাধিক ফেচ কল এড়ানো হলো
    corePrayerFetchInProgress = true;
    const now = new Date();
    try {
        // সরাসরি ফেচ করার চেষ্টা করব
        const adj = window._nativeHijriAdjustment !== undefined ? window._nativeHijriAdjustment : 0;
        const localDateStr = `${String(now.getDate()).padStart(2,'0')}-${String(now.getMonth()+1).padStart(2,'0')}-${now.getFullYear()}`;

        const apiRes = await fetchWithTimeout(`https://api.aladhan.com/v1/timings/${localDateStr}?latitude=${userLat}&longitude=${userLng}&method=${nzIsIfbd() ? 1 : nzMethodId()}&school=${currentMadhab}&adjustment=0`, 12000);
        if (!apiRes.ok) throw new Error('API Error: ' + apiRes.status);

        const d = await apiRes.json();
        lastRawTimings = d.data.timings;
        globalTimings = applyWaqtMinuteOffsets(d.data.timings);
        nzSource = 'live';
        /* ইসলামিক ফাউন্ডেশন: aladhan শুধু হিজরি তারিখের জন্য; ওয়াক্তের সময় সূচী থেকেই (ইন্টারনেট ছাড়াই একই) */
        if (nzIsIfbd()) {
            const ib = computeOfflineTimings(now);
            if (ib) { lastRawTimings = ib; globalTimings = applyWaqtMinuteOffsets(ib); nzSource = 'ifbd'; }
        }

        const currentYear = now.getFullYear();
        const gregorianStr = `${now.getDate()} ${gregorianMonthsBN[now.getMonth()]} ${currentYear}`;

        const hj = d.data.date.hijri;
        const hjMonthIndex = parseInt(hj.month.number) - 1;

        hijriApiAnchor = {
            day: parseInt(hj.day), month: hjMonthIndex, year: parseInt(hj.year),
            monthLength: hj.month && hj.month.days ? parseInt(hj.month.days) : null,
            fetchedForDateStr: toDateOnlyStr(now)
        };

        const bnDateStr = getBengaliCalendarCalculation(now, false);

        const hijriStr = getFinalHijriDisplayString(now);
        const baseHijriStr = getFinalHijriDisplayString(now, true, true);

        isRamadanNow = (getEffectiveHijriMonthIndex(now) === 8);
        nzPaintSun();

        nzPaintDates(now);


        notifyOfflineBannerState(false);
        cacheLastKnownData({
            timings: lastRawTimings || d.data.timings, isRamadan: isRamadanNow, lat: userLat, lng: userLng,
            locationName: (document.getElementById('top-location').innerText || '').trim(),
            temp: cacheTemperatureStr
        });

        if (window.AndroidWidgetBridge && typeof window.AndroidWidgetBridge.saveTimings === 'function') {
            try {
                window.AndroidWidgetBridge.saveTimings(JSON.stringify({
                    fajr: globalTimings.Fajr, sunrise: globalTimings.Sunrise, dhuhr: globalTimings.Dhuhr,
                    asr: globalTimings.Asr, maghrib: globalTimings.Maghrib, isha: globalTimings.Isha,
                    sunset: globalTimings.Sunset, gregorian: gregorianStr,
                    hijri: baseHijriStr, bangla: bnDateStr, isRamadan: isRamadanNow,
                    // ✅ FIX #NEW (v5): lat/lng/school/waqtMinuteOffsets এখন নেটিভ সাইডেও পাঠানো হচ্ছে —
                    // এতে অ্যাপ না খুললেও ব্যাকগ্রাউন্ডে (WidgetUpdateWorker থেকে) নামাজের সঠিক
                    // সময় প্রতিদিন সরাসরি Aladhan API থেকে re-fetch করা সম্ভব হবে (দেখুন
                    // NativePrayerTimesFetcher.kt)। এই মানগুলো শুধু ডেটা — কোনো UI/ডিজাইন
                    // পরিবর্তন নেই, শুধু আগে থেকেই মেমোরিতে থাকা userLat/userLng/currentMadhab/
                    // waqtMinuteOffsets ভেরিয়েবলগুলো নেটিভ ব্রিজে পাঠানো হচ্ছে।
                    lat: userLat, lng: userLng, school: currentMadhab,
                    waqtMinuteOffsets: waqtMinuteOffsets,
                    method: nzMethodId()      /* ধাপ ৩: নেটিভ ব্যাকগ্রাউন্ড ফেচ একই পদ্ধতিতে (NativePrayerTimesFetcher.kt) */
                }));
            } catch(e) { console.error("Bridge saveTimings failed", e); }
        }
        syncAlarmConfigsToNativeBridge();
        if (typeof nzAfterData === 'function') nzAfterData();
        processDashboardTimelineUpdates(new Date());
        fetchAtmosphereAndLocationName();

    } catch(e) {
        console.error("Fetch failed (attempt " + attempt + "):", e);
        // প্রথম চেষ্টা ব্যর্থ হলে সাথে সাথে "নেট নেই" না দেখিয়ে, দ্রুত একবার আবার চেষ্টা করা হয় —
        // অনেক ক্ষেত্রেই এটি কেবল একটি সাময়িক নেটওয়ার্ক ব্লিপ, প্রকৃত সংযোগহীনতা নয়।
        if (attempt < 2) {
            corePrayerFetchInProgress = false;
            setTimeout(() => { fetchCorePrayerData(attempt + 1); }, 2500);
            return;
        }
        loadFromOfflineCache(now);
        if (nzIsIfbd()) notifyOfflineBannerState(false);     /* ফাউন্ডেশনের সময় ইন্টারনেট ছাড়াই নির্ভুল — "অফলাইন" সতর্কবার্তা দরকার নেই */
    } finally {
        corePrayerFetchInProgress = false;
    }
}

// ✅ FIX #12: বাংলা সংখ্যাকে ইংরেজি সংখ্যায় রূপান্তর — শুধু সংখ্যা অংশ বদলায়, বাকি
// (মাসের নাম ইত্যাদি) বাংলাতেই থাকে। উইজেট প্রিভিউ/হোমস্ক্রিন উইজেটে সবসময় ইংরেজি সংখ্যা
// ব্যবহার হয় (মূল ড্যাশবোর্ডের হিজরি তারিখ অপরিবর্তিত থাকে, শুধু উইজেটের জন্য এই রূপান্তর)।
const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
function bnDigitsToEn(str) {
    if (!str) return str;
    return String(str).replace(/[০-৯]/g, ch => String(BN_DIGITS.indexOf(ch)));
}

async function fetchAtmosphereAndLocationName() {
    if (!isActuallyOnline()) return; // অফলাইনে থাকলে আগের ক্যাশ করা লোকেশন/তাপমাত্রাই দেখানো থাকবে, ভুল করে "ঢাকা" বসাবে না
    try {
        const locRes = await fetchWithTimeout(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${userLat}&longitude=${userLng}&localityLanguage=bn`, 8000);
        const locData = await locRes.json();
        const resolvedCity = locData.city || locData.locality || locData.principalSubdivision || "ঢাকা";
        nzSetPlace(resolvedCity);

        const w = await fetchWithTimeout(`https://api.open-meteo.com/v1/forecast?latitude=${userLat}&longitude=${userLng}&current_weather=true`, 8000);
        const wd = await w.json();
        cacheTemperatureStr = `${Math.round(wd.current_weather.temperature)}°C`;


        // লোকেশন/তাপমাত্রা সবশেষে পাওয়া গেলে ক্যাশ আবার রিফ্রেশ করে রাখা হলো (অফলাইন ফলব্যাকের জন্য)
        if (globalTimings) {
            cacheLastKnownData({
                timings: lastRawTimings || globalTimings, isRamadan: isRamadanNow, lat: userLat, lng: userLng,
                locationName: resolvedCity, temp: cacheTemperatureStr
            });
        }
    } catch(e) {
        // নেট ব্লিপ/এপিআই সমস্যা হলে আগে যা লোকেশন দেখানো ছিল সেটিই থাকবে, জোর করে "ঢাকা" বসানো হবে না
    }
}

