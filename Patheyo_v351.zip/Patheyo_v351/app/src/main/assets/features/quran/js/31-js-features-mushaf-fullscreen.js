
/*!
 * js/features/mushaf-fullscreen.js -- Fullscreen Mushaf pager: 3-slot swipe navigation, page info, Para toast
 *
 * Provides : App.bindDragNav, App.closeFullscreenPage, App.getPfSlots, App.openFullscreenPage, App.pf
 * Needs    : core/dom, core/quran-meta, core/utils, data/para-meta, features/bookmark-fab, features/last-read,
               features/mushaf-viewer, features/navigation, features/pinch-zoom, services/pdf-service
 */
(function (App) {
  "use strict";

  // ---- Fullscreen page-by-page swipeable viewer ----
  // Slot layout is fixed by position (left=-100%, center=0, right=+100%). Since this is a
  // right-to-left (Arabic) reading direction: dragging right-to-left reveals the RIGHT slot
  // and goes to the PREVIOUS page (backward, like physically turning a Mushaf page); dragging
  // left-to-right reveals the LEFT slot and goes to the NEXT page (forward).
  var pf = { current:1, dragging:false, startX:0, startY:0, dragX:0, locked:null, animating:false, turning:false };
  App.pf = pf;

  var pfSlots = null;

 // {prev, current, next} DOM elements (left/center/right), set once on first open

  function getPfSlots(){
    if (!pfSlots || !pfSlots.current || !pfSlots.current.parentNode){
      pfSlots = {
        prev: App.els.pageTrack.querySelector('[data-slot="prev"] canvas'),
        current: App.els.pageTrack.querySelector('[data-slot="current"] canvas'),
        next: App.els.pageTrack.querySelector('[data-slot="next"] canvas')
      };
    }
    return pfSlots;
  }
  App.getPfSlots = getPfSlots;

  // v290: থিম পিক্সেলে "বেক" — এবার কাগজের রং বাদ দিয়ে শুধু কালি/লেখা রাখা হয় (কাগজ = স্বচ্ছ)।
  // তাই পেজের পেছনে স্লটের ব্যাকগ্রাউন্ড রং-ই দেখা যায়: লাইট/ডার্ক/সেপিয়া — প্রতি মোডে পেজ আর ব্যাকগ্রাউন্ড হুবহু এক রং,
  // পেজের কিনারা বোঝা যায় না। (আগে কাগজে রং এঁকে দেওয়ায় ১-২ ধাপ রঙের গরমিল থেকে কিনারার রেখা দেখা যেত।)
  var PF_INK = { light:[10,12,18], sepia:[44,32,20], dark:[243,246,252] };   // R,G,B
  // শুরুর দুই পেজের (সূরা ফাতিহা, বাকারার শুরু) চওড়া নকশার বর্ডার: [বাইরের x0,y0,x1,y1 ; ভেতরের x0,y0,x1,y1] — পেজের ভগ্নাংশে
  var PF_ORN = {
    1: [0.0675,0.0600,0.9075,0.9235, 0.1930,0.1400,0.7860,0.8490],
    2: [0.0990,0.0775,0.9340,0.9350, 0.2230,0.1530,0.8160,0.8610]
  };
  function pfBake(ctx, w, h, n){
    var fs = App.els.pageFullscreen;
    var mode = fs.getAttribute('data-pf-mode') || 'light';
    if (!PF_INK[mode]) mode = 'light';
    var dark = (mode === 'dark');
    ctx.save();
    ctx.setTransform(1,0,0,1,0,0);
    ctx.globalCompositeOperation = 'destination-over';   // স্বচ্ছ অংশে সাদা কাগজ ধরা
    ctx.fillStyle = '#fff'; ctx.fillRect(0,0,w,h);
    if (dark){
      ctx.globalCompositeOperation = 'difference';       // সাদা-কালো উল্টানো: লেখা = উজ্জ্বল
      ctx.fillStyle = '#fff'; ctx.fillRect(0,0,w,h);
      var o = PF_ORN[n];
      if (o){                                            // ডার্ক মোডে চওড়া নকশা: চিকন ও ম্লান — দূর থেকে হিজিবিজি লাগে না
        var ox0=o[0]*w, oy0=o[1]*h, ox1=o[2]*w, oy1=o[3]*h, ix0=o[4]*w, iy0=o[5]*h, ix1=o[6]*w, iy1=o[7]*h;
        var tmp = document.createElement('canvas'); tmp.width = w; tmp.height = h;
        tmp.getContext('2d').drawImage(ctx.canvas, 0, 0);
        ctx.beginPath();                                  // শুধু বর্ডারের রিং (ভেতরের লেখার ফ্রেম বাদে)
        ctx.rect(ox0, oy0, ox1-ox0, oy1-oy0);
        ctx.rect(ix0, iy0, ix1-ix0, iy1-iy0);
        ctx.clip('evenodd');
        var r = Math.max(1, Math.round(w / 700));
        ctx.globalCompositeOperation = 'darken';          // সাদা দাগ/নকশা সরু করা (erode)
        var offs = [[r,0],[-r,0],[0,r],[0,-r],[r,r],[-r,-r],[r,-r],[-r,r]];
        for (var k = 0; k < offs.length; k++) ctx.drawImage(tmp, offs[k][0], offs[k][1]);
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = 'rgba(0,0,0,0.42)';               // আর উজ্জ্বলতা কমানো
        ctx.fillRect(ox0-2, oy0-2, (ox1-ox0)+4, (oy1-oy0)+4);
      }
    }
    ctx.restore();
    var lut = pfLut(mode);
    var img = ctx.getImageData(0, 0, w, h);
    var px = new Uint32Array(img.data.buffer);
    for (var i = 0, len = px.length; i < len; i++){ px[i] = lut[px[i] & 255]; }
    ctx.putImageData(img, 0, 0);
  }
  // গ্রে-লেভেল → স্বচ্ছতা: ডার্কে যত উজ্জ্বল তত অস্বচ্ছ, লাইট/সেপিয়ায় যত কালো তত অস্বচ্ছ
  var lutCache = {};
  function pfLut(mode){
    if (lutCache[mode]) return lutCache[mode];
    var dark = (mode === 'dark');
    var ink = PF_INK[mode];
    var rgb = (ink[0]) | (ink[1] << 8) | (ink[2] << 16);
    var g;
    // হালকা ধূসর কাগজ/স্ক্যানের দাগ (≤১৪ ধাপ) পুরো স্বচ্ছ — তাই কাগজ আর ব্যাকগ্রাউন্ড হুবহু এক রং থাকে
    var lut = new Uint32Array(256), v;
    for (g = 0; g < 256; g++){
      v = dark ? g : 255 - g;
      v = v <= 14 ? 0 : Math.round((v - 14) * 255 / 241);
      lut[g] = ((v << 24) | rgb) >>> 0;
    }
    lutCache[mode] = lut;
    return lut;
  }
  App.pfBake = pfBake;

  // v342: দ্রুত বেক — পিক্সেল পড়া/লেখা (getImageData/putImageData, প্রতি পেজে ~৯MB কপি) ছাড়াই, শুধু ক্যানভাসের ব্লেন্ড-মোড দিয়ে।
  // লাইট/সেপিয়া: screen(কালি-রং) → কালো লেখা = কালি-রং, সাদা কাগজ সাদাই থাকে; তারপর multiply(ব্যাকগ্রাউন্ড) → কাগজ = হুবহু ব্যাকগ্রাউন্ড।
  // ডার্ক: difference(সাদা) → উল্টানো; multiply(কালি-রং) → লেখা = কালি-রং; screen(ব্যাকগ্রাউন্ড) → কালো কাগজ = হুবহু ব্যাকগ্রাউন্ড।
  // ফলে কাগজ আর পেছনের রং এক — কিনারা দেখা যায় না (আগের মতোই), কিন্তু খরচ ২০-৯০ms থেকে ১-৩ms।
  var bgCache = {};
  function pfBg(mode){
    if (bgCache[mode]) return bgCache[mode];
    var col = '';
    try{
      var slot = App.els.pageTrack.querySelector('.page-slot');
      col = getComputedStyle(slot).backgroundColor || '';
    }catch(e){}
    var m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+))?/.exec(col);
    if (!m || (m[4] !== undefined && +m[4] < 1)) return null;   // স্বচ্ছ/অজানা হলে পুরোনো পদ্ধতি
    return (bgCache[mode] = 'rgb(' + m[1] + ',' + m[2] + ',' + m[3] + ')');
  }
  function pfBakeFast(ctx, w, h, n){
    var mode = App.els.pageFullscreen.getAttribute('data-pf-mode') || 'light';
    if (!PF_INK[mode]) mode = 'light';
    var dark = (mode === 'dark');
    var bg = pfBg(mode);
    var gco = ctx.globalCompositeOperation;
    if (!bg || (dark && PF_ORN[n])){ pfBake(ctx, w, h, n); return; }   // প্রথম দুই পেজের ডার্ক-নকশা: বিরল, পুরোনো পদ্ধতি
    var ink = PF_INK[mode], inkCol = 'rgb(' + ink[0] + ',' + ink[1] + ',' + ink[2] + ')';
    ctx.save();
    ctx.setTransform(1,0,0,1,0,0);
    ctx.globalCompositeOperation = 'destination-over'; ctx.fillStyle = '#fff'; ctx.fillRect(0,0,w,h);   // স্বচ্ছ অংশ = সাদা কাগজ
    if (ctx.globalCompositeOperation !== 'destination-over'){ ctx.restore(); pfBake(ctx, w, h, n); return; }
    if (dark){
      ctx.globalCompositeOperation = 'difference'; ctx.fillStyle = '#fff'; ctx.fillRect(0,0,w,h);
      ctx.globalCompositeOperation = 'multiply';   ctx.fillStyle = inkCol; ctx.fillRect(0,0,w,h);
      ctx.globalCompositeOperation = 'screen';     ctx.fillStyle = bg;     ctx.fillRect(0,0,w,h);
    } else {
      ctx.globalCompositeOperation = 'screen';     ctx.fillStyle = inkCol; ctx.fillRect(0,0,w,h);
      ctx.globalCompositeOperation = 'multiply';   ctx.fillStyle = bg;     ctx.fillRect(0,0,w,h);
    }
    ctx.restore();
    ctx.globalCompositeOperation = gco;
  }
  App.pfBakeFast = pfBakeFast;

  // ===== v342: সুপার-ফাস্ট পেজ ইঞ্জিন =====
  // আগে: প্রতি পেজ-উল্টানোয় নতুন পেজ মূল থ্রেডে আঁকা হতো (PDF রেন্ডার + পিক্সেল-বেক), কোনো ক্যাশ ছিল না, আর
  // অ্যানিমেশন শেষ না হওয়া পর্যন্ত পরের সোয়াইপ নেওয়া হতো না — তাই দ্রুত উল্টানো যেত না, মাঝে মাঝে আটকে যেত।
  // এখন: (১) প্রতিটি পেজের নিজস্ব ক্যানভাস একটি ছোট ক্যাশে থাকে — পেজ বদলালে শুধু ক্যানভাসটা স্লটে সরানো হয় (কপি নেই, শূন্য খরচ)।
  //       (২) পড়ার দিকে সামনের ৩টি ও পেছনের ১-২টি পেজ আগেভাগে একে একে আঁকা হয় (প্রিফেচ)।
  //       (৩) থিমের রং বসে ব্লেন্ড-মোডে (pfBakeFast) — পিক্সেল কপি নেই, প্রতি পেজে ১-৩ms।
  //       (৪) দূরের পেজের অসমাপ্ত রেন্ডার বাতিল হয়, আর ক্যাশ থেকে বাদ পড়া পেজের PDF-মেমরিও ছেড়ে দেওয়া হয়।
  var CACHE_MAX = (function(){
    var m = 4; try{ m = navigator.deviceMemory || 4; }catch(e){}
    return m <= 2 ? 5 : (m <= 4 ? 7 : 9);
  })();
  var cache = {};          // n -> { n, c:canvas, state:'idle'|'rendering'|'done', mode, w, task, cancelled }
  var cacheList = [];      // ক্যাশে থাকা পেজ নম্বর
  var renderingEntry = null;
  var wantList = [];
  var lastDir = 1;
  var scratch = null, scratchCtx = null;
  var blanks = null;       // প্রতি স্লটের নিজস্ব ফাঁকা ক্যানভাস (রেঞ্জের বাইরের পেজের জন্য)

  function pfBaseW(){ return Math.min(Math.round((window.innerWidth || 400) * (window.devicePixelRatio || 1)), 1600); }
  App.pfBaseW = pfBaseW;
  function curMode(){ var m = App.els.pageFullscreen.getAttribute('data-pf-mode') || 'light'; return PF_INK[m] ? m : 'light'; }

  function getScratch(w, h){
    if (!scratch){
      scratch = document.createElement('canvas');
      scratchCtx = scratch.getContext('2d');
    }
    if (scratch.width !== w || scratch.height !== h){ scratch.width = w; scratch.height = h; }
    else { scratchCtx.setTransform(1,0,0,1,0,0); scratchCtx.globalCompositeOperation = 'source-over'; scratchCtx.clearRect(0, 0, w, h); }
    return scratchCtx;
  }

  function entryFor(n){
    var e = cache[n];
    if (!e){
      var c = document.createElement('canvas');
      c.setAttribute('data-page', n);
      e = cache[n] = { n:n, c:c, state:'idle', mode:null, w:0, task:null, cancelled:false };
      cacheList.push(n);
    }
    return e;
  }
  function needsRender(e){
    return e.state !== 'rendering' && (e.state !== 'done' || e.mode !== curMode() || e.w !== pfBaseW() || !e.c.width);
  }
  function dropEntry(n){
    var e = cache[n]; if (!e) return;
    e.cancelled = true;
    if (e.task){ try{ e.task.cancel(); }catch(err){} e.task = null; }
    if (e.c.parentNode) return;                 // স্লটে দেখানো পেজ বাদ দেওয়া হয় না
    e.c.width = 0; e.c.height = 0;              // বিটম্যাপ মেমরি সাথে সাথে ছেড়ে দেওয়া
    delete cache[n];
    cacheList = cacheList.filter(function(x){ return x !== n; });
    App.ensurePdfLoaded().then(function(doc){ return doc.getPage(n); }).then(function(pg){ try{ pg.cleanup(); }catch(err){} }).catch(function(){});
  }
  function trimCache(keep){
    if (cacheList.length <= keep) return;
    var cur = pf.current;
    var sorted = cacheList.slice().sort(function(a, b){ return Math.abs(b - cur) - Math.abs(a - cur); });   // দূরেরটা আগে
    for (var i = 0; i < sorted.length && cacheList.length > keep; i++){
      var e = cache[sorted[i]];
      if (e && !e.c.parentNode && wantList.indexOf(sorted[i]) < 0) dropEntry(sorted[i]);
    }
  }

  function renderEntry(e){
    e.state = 'rendering'; e.cancelled = false;
    renderingEntry = e;
    var mode = curMode(), w = pfBaseW(), n = e.n;
    function fin(){ if (renderingEntry === e) renderingEntry = null; if (e.state === 'rendering') e.state = 'idle'; e.task = null; setTimeout(pump, 0); }
    App.ensurePdfLoaded().then(function(doc){
      if (e.cancelled) return null;
      return doc.getPage(n);
    }).then(function(page){
      if (!page || e.cancelled) return;
      var native = page.getViewport({ scale: 1 });
      var vp = page.getViewport({ scale: w / native.width });
      var W = Math.floor(vp.width), H = Math.floor(vp.height);
      // নতুন (ফাঁকা) পেজ: সরাসরি নিজের ক্যানভাসে আঁকা — বাড়তি কপি নেই। আঁকা শেষ না হওয়া পর্যন্ত লুকানো, তাই আধা-আঁকা দেখা যায় না।
      // আগে-আঁকা পেজ (থিম/মাপ বদল): স্ক্র্যাচে এঁকে একবারে বদল — পুরোনো ছবি ততক্ষণ দেখা যায়, ফাঁকা ঝিলিক নেই।
      var direct = (e.mode === null);
      var ctx;
      if (direct){
        e.c.style.visibility = 'hidden';
        if (e.c.width !== W || e.c.height !== H){ e.c.width = W; e.c.height = H; }
        ctx = e.c.getContext('2d');
        ctx.setTransform(1,0,0,1,0,0); ctx.globalCompositeOperation = 'source-over'; ctx.clearRect(0, 0, W, H);
      } else {
        ctx = getScratch(W, H);
      }
      var task = page.render({ canvasContext: ctx, viewport: vp });
      e.task = task;
      return task.promise.then(function(){
        e.task = null;
        if (e.cancelled) return;
        pfBakeFast(ctx, W, H, n);
        if (!direct){
          var big = e.c.width > w * 1.15 && n === pf.current && App.pzIsZoomed && App.pzIsZoomed();
          if (e.c.width !== W || e.c.height !== H){ e.c.width = W; e.c.height = H; }
          e.c.getContext('2d').drawImage(scratch, 0, 0);
          if (big && App.pzRefresh) App.pzRefresh();        // জুম অবস্থায় থিম বদলালে আবার ধারালো করা
        }
        e.c.style.visibility = '';
        e.mode = mode; e.w = w; e.state = 'done';
      });
    }).then(fin, fin);
  }

  var pumpT = 0;
  function pump(){
    if (renderingEntry) return;
    if (App.els.pageFullscreen.classList.contains('hidden')) return;
    // আঙুল টানার সময় নতুন পেজ আঁকা শুরু নয় (বর্তমান পেজ ফাঁকা থাকলে ছাড়া) — টানা একদম মসৃণ থাকে
    if ((pf.dragging || pendingCommit || (App.pzBusy && App.pzBusy())) && entryFor(pf.current).state === 'done'){
      clearTimeout(pumpT); pumpT = setTimeout(pump, 60); return;
    }
    for (var i = 0; i < wantList.length; i++){
      var e = entryFor(wantList[i]);
      if (needsRender(e)){ renderEntry(e); return; }
    }
  }

  function setWant(n){
    var d = lastDir >= 0 ? 1 : -1;
    var list = [n, n + d, n - d, n + 2*d, n + 3*d, n - 2*d];
    wantList = list.filter(function(x){ return x >= 1 && x <= App.TOTAL_PAGES; }).slice(0, Math.max(3, CACHE_MAX - 1));
    // যে পেজটা এখন আর দরকার নেই, তার অসমাপ্ত রেন্ডার বাতিল — যাতে বর্তমান পেজ আগে আসে
    if (renderingEntry && wantList.indexOf(renderingEntry.n) < 0){
      var r = renderingEntry; r.cancelled = true;
      if (r.task){ try{ r.task.cancel(); }catch(err){} }
    } else if (renderingEntry && renderingEntry.n !== n && needsRender(entryFor(n)) && wantList.indexOf(renderingEntry.n) > 1){
      var r2 = renderingEntry; r2.cancelled = true;          // অনেক সামনের প্রিফেচ চললে, বর্তমান পেজকে জায়গা দেওয়া
      if (r2.task){ try{ r2.task.cancel(); }catch(err){} }
    }
  }

  function slotEl(name){ return App.els.pageTrack.querySelector('[data-slot="' + name + '"]'); }
  function putIn(name, n){
    var slot = slotEl(name);
    if (!blanks){ blanks = {}; }
    if (!blanks[name]){ var b0 = slot.querySelector('canvas'); blanks[name] = (b0 && !b0.hasAttribute('data-page')) ? b0 : document.createElement('canvas'); }
    var c = (n >= 1 && n <= App.TOTAL_PAGES) ? entryFor(n).c : blanks[name];
    if (slot.firstElementChild !== c || slot.children.length !== 1){
      while (slot.firstChild) slot.removeChild(slot.firstChild);
      slot.appendChild(c);
    }
    c.style.transform = '';
    return c;
  }

  // বাম স্লট = সামনের পেজ, ডান স্লট = আগের পেজ (আরবি পড়ার দিক)
  function layout(n){
    var cur = putIn('current', n), pv = putIn('prev', n + 1), nx = putIn('next', n - 1);
    pfSlots = { prev: pv, current: cur, next: nx };
    setWant(n);
    trimCache(CACHE_MAX);
    pump();
  }

  function renderSlots(n){ layout(n); }

  function rotateSlots(delta){
    lastDir = delta > 0 ? 1 : -1;
    pf.current += (delta > 0 ? 1 : -1);
    layout(pf.current);
  }

  App.pfClearCache = function(){
    if (renderingEntry){ renderingEntry.cancelled = true; if (renderingEntry.task){ try{ renderingEntry.task.cancel(); }catch(e){} } renderingEntry = null; }
    Object.keys(cache).forEach(function(k){ var e = cache[k]; e.cancelled = true; e.c.width = 0; e.c.height = 0; if (e.c.parentNode) e.c.parentNode.removeChild(e.c); });
    cache = {}; cacheList = []; wantList = []; pfSlots = null;
    if (blanks){ ['prev','current','next'].forEach(function(nm){ var s = slotEl(nm); if (s && blanks[nm] && !s.firstChild) s.appendChild(blanks[nm]); }); }
  };
  App.pfIsRendering = function(c){ return !!(renderingEntry && renderingEntry.c === c); };
  // জুম থেকে বেরোলে বড় (ধারালো) বিটম্যাপ ছেড়ে সাধারণ মাপে ফেরা
  App.pfReleaseSharp = function(c){
    var n = +c.getAttribute('data-page'); var e = cache[n];
    if (!e || c.width <= pfBaseW() * 1.15) return;
    e.state = 'idle';
    if (App.els.pageFullscreen.classList.contains('hidden')){ c.width = 0; c.height = 0; return; }   // বন্ধ: মেমরি ছেড়ে দেওয়া
    pump();
  };

  function updatePageInfo(n){
    var paraIdx = App.paraForPage(n);
    var pageInPara = n - App.PARA_PAGE_RANGE[paraIdx-1][0] + 1;
    App.els.pfPageInfo.textContent = 'পারা-' + App.bn(paraIdx) + ' . পৃষ্ঠা-' + App.bn(pageInPara);
    App.updateLastReadMushaf(n);
  }

  function showParaToast(paraIdx){
    App.els.ptNum.textContent = App.bn(paraIdx);
    App.els.paraToast.classList.add('show');
    clearTimeout(App.els.paraToast.__t);
    App.els.paraToast.__t = setTimeout(function(){ App.els.paraToast.classList.remove('show'); }, 1600);
  }


  // ---- বাটন (ক্রস / বুকমার্ক / মোড): ৫ সেকেন্ড পর নিজে লুকায়, পেজে ট্যাপ করলে আসে/যায় ----
  var pfUi = { t:null, tapT:null, inited:false, on:true, lastTap:0 };
  var PF_MODES = ['light','dark','sepia'];
  function pfMode(){
    var m = null;
    try{ m = localStorage.getItem('quran-pf-theme'); }catch(e){}
    if (PF_MODES.indexOf(m) < 0) m = document.documentElement.getAttribute('data-theme') || 'light';
    return PF_MODES.indexOf(m) < 0 ? 'light' : m;
  }
  function pfApplyMode(m){
    var fs = App.els.pageFullscreen;
    fs.setAttribute('data-theme', m);       // শুধু এই পেজের মোড — অ্যাপের বাকি অংশ বদলায় না
    fs.setAttribute('data-pf-mode', m);
  }
  function pfUiShow(){
    var fs = App.els.pageFullscreen;
    pfUi.on = true; fs.classList.remove('pf-ui-off');
    clearTimeout(pfUi.t);
    pfUi.t = setTimeout(pfUiHide, 5000);
  }
  function pfUiHide(){
    clearTimeout(pfUi.t);
    pfUi.on = false; App.els.pageFullscreen.classList.add('pf-ui-off');
  }
  function pfUiInit(){
    pfApplyMode(pfMode());
    if (pfUi.inited) return;
    pfUi.inited = true;
    var fs = App.els.pageFullscreen, stage = App.els.pageStage;
    var themeBtn = document.getElementById('pf-theme-btn');
    if (themeBtn) themeBtn.addEventListener('click', function(e){
      e.stopPropagation();
      var cur = fs.getAttribute('data-pf-mode') || 'light';
      var next = PF_MODES[(PF_MODES.indexOf(cur) + 1) % PF_MODES.length];
      pfApplyMode(next);
      try{ localStorage.setItem('quran-pf-theme', next); }catch(err){}
      renderSlots(pf.current);                  // v342: নতুন মোডে আগের ছবি দেখা যায় যতক্ষণ না নতুন রঙে আঁকা শেষ — ফাঁকা ঝিলিক নেই
      if (App.pzRefresh) App.pzRefresh();
      pfUiShow();                               // মোড বদলালে আরও ৫ সেকেন্ড থাকবে
    });
    // বাটনে চাপলে টাইমার আবার শুরু
    ['pf-close-btn','pf-bookmark-btn'].forEach(function(id){
      var b = document.getElementById(id);
      if (b) b.addEventListener('click', function(){ if (pfUi.on) pfUiShow(); });
    });
    // পেজে একটি ট্যাপ: বাটন থাকলে লুকাবে, না থাকলে আসবে (ডাবল-ট্যাপ জুমে সংঘাত এড়াতে একটু অপেক্ষা)
    var sx = 0, sy = 0, st = 0, multi = false, ptrs = 0;
    stage.addEventListener('pointerdown', function(e){ ptrs++; if (ptrs > 1) multi = true; if (ptrs === 1){ multi = false; sx = e.clientX; sy = e.clientY; st = Date.now(); } });
    function up(e){
      ptrs = Math.max(0, ptrs - 1);
      if (ptrs > 0 || multi || e.type === 'pointercancel') return;
      if (Math.abs(e.clientX - sx) > 8 || Math.abs(e.clientY - sy) > 8 || Date.now() - st > 450) return;
      if (App.pzBlocksSwipe && App.pzBlocksSwipe()) return;   // জুম করা অবস্থায় ট্যাপে কিছু হবে না
      var now = Date.now();
      if (now - pfUi.lastTap < 320){ clearTimeout(pfUi.tapT); pfUi.lastTap = 0; return; }   // ডাবল-ট্যাপ = জুম, বাটন বদলাবে না
      pfUi.lastTap = now;
      clearTimeout(pfUi.tapT);
      pfUi.tapT = setTimeout(function(){ pfUi.lastTap = 0; if (pfUi.on) pfUiHide(); else pfUiShow(); }, 320);
    }
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', up);
  }

  function openFullscreenPage(n){
    finishPending();
    pf.current = n;
    App.updateBmFabIcon();
    pf.dragging = false;
    pf.animating = false;
    pf.turning = false;
    App.els.pageTrack.classList.remove('dragging');
    App.els.pageTrack.style.transform = 'translate3d(0,0,0)';
    App.els.pageFullscreen.classList.remove('hidden');   // আগে দেখানো, তারপর আঁকা (pump লুকানো অবস্থায় আঁকে না)
    pfUiInit();
    App.pzReset();
    renderSlots(n);
    updatePageInfo(n);
    pfUiShow();
    App.pushHistory('para-fullscreen');
  }
  App.openFullscreenPage = openFullscreenPage;

  function closeFullscreenPage(){
    clearTimeout(pfUi.t); clearTimeout(pfUi.tapT);
    finishPending();
    App.els.pageFullscreen.classList.add('hidden');
    App.pzReset(true);
    if (renderingEntry){ renderingEntry.cancelled = true; if (renderingEntry.task){ try{ renderingEntry.task.cancel(); }catch(e){} } }
    wantList = [pf.current - 1, pf.current, pf.current + 1];
    trimCache(3);                                         // বন্ধ করলে বেশিরভাগ মেমরি ছেড়ে দেওয়া
    App.showPreviewPage(pf.current);
  }
  App.closeFullscreenPage = closeFullscreenPage;

  // v342: ২২০ms-এর ছোট্ট স্লাইড; আর স্লাইড চলাকালীন নতুন সোয়াইপ এলে আগেরটা সাথে সাথে শেষ করে নতুনটা শুরু —
  // তাই এক সেকেন্ডে কয়েক পেজ উল্টানো যায়।
  var SETTLE_MS = 220;   // CSS ট্রানজিশনের (.22s) সাথে মেলানো
  var turnTimer = 0, pendingCommit = null, pendingBack = false;

  function finishPending(){
    if (!pendingCommit) return false;
    clearTimeout(turnTimer); turnTimer = 0;
    var f = pendingCommit; pendingCommit = null;
    f();
    return true;
  }
  App.pfFinishTurn = finishPending;

  function settlePage(delta){
    var stageW = App.els.pageStage.clientWidth;
    var track = App.els.pageTrack;
    finishPending();
    track.classList.remove('dragging');
    pf.animating = true;
    if (delta === 0){
      pendingBack = true;
      track.style.transform = 'translate3d(0,0,0)';
      pendingCommit = function(){ pendingBack = false; pf.animating = false; };
      turnTimer = setTimeout(finishPending, SETTLE_MS);
      return;
    }
    pendingBack = false;
    var prevPara = App.paraForPage(pf.current);
    // delta>0 (forward) reveals the LEFT slot -> track moves right (+stageW).
    // delta<0 (backward) reveals the RIGHT slot -> track moves left (-stageW).
    track.style.transform = 'translate3d(' + (delta > 0 ? stageW : -stageW) + 'px,0,0)';
    pf.turning = true;
    pendingCommit = function(){
      track.classList.add('dragging');           // ট্রানজিশন বন্ধ রেখে চুপচাপ জায়গা বদল
      rotateSlots(delta);
      track.style.transform = 'translate3d(0,0,0)';
      App.updateBmFabIcon();
      updatePageInfo(pf.current);
      var newPara = App.paraForPage(pf.current);
      if (newPara !== prevPara){ showParaToast(newPara); }
      pf.animating = false;
      pf.turning = false;
      requestAnimationFrame(function(){ if (!pf.dragging && !pendingCommit) track.classList.remove('dragging'); });
    };
    turnTimer = setTimeout(finishPending, SETTLE_MS);
  }

  function bindDragNav(){
    var activePointer = null;
    var baseX = 0;
    var dragRaf = 0, vx = 0, lastMoveX = 0, lastMoveT = 0;   // v289: ফ্রেম-প্রতি একবার আঁকা + আঙুলের গতি (ফ্লিং)
    function paintDrag(){ dragRaf = 0; App.els.pageTrack.style.transform = 'translate3d(' + (baseX + pf.dragX) + 'px,0,0)'; }

    // v342: ক্যাপচার-ধাপে (জুম মডিউলের আগেই) — চলমান স্লাইড থাকলে তা এখনই শেষ, যাতে নতুন ছোঁয়া হারিয়ে না যায়
    App.els.pageStage.addEventListener('pointerdown', function(e){
      baseX = 0;
      if (!pendingCommit) return;
      if (pendingBack){
        // ফেরত-স্লাইডের মাঝপথে ধরলে: যেখানে আছে সেখান থেকেই টানা চলবে (ঝাঁকুনি নেই)
        var m = 0;
        try{ var t = getComputedStyle(App.els.pageTrack).transform; if (t && t !== 'none'){ m = new DOMMatrixReadOnly(t).m41 || 0; } }catch(err){}
        baseX = m;
        App.els.pageTrack.classList.add('dragging');
        App.els.pageTrack.style.transform = 'translate3d(' + m + 'px,0,0)';
      }
      finishPending();
    }, true);

    App.els.pageStage.addEventListener('pointerdown', function(e){
      if (activePointer !== null) return;
      if (App.pzBlocksSwipe()) return; // zoomed in (finger pans) or pinching -> no page swipe
      if (e.button !== undefined && e.button !== 0) return; // left mouse button / touch / pen only
      activePointer = e.pointerId;
      pf.startX = e.clientX;
      pf.startY = e.clientY;
      pf.dragX = 0;
      pf.dragging = true;
      pf.locked = null;
      vx = 0; lastMoveX = e.clientX; lastMoveT = e.timeStamp || Date.now();
      App.els.pageTrack.classList.add('dragging');
      try{ App.els.pageStage.setPointerCapture(e.pointerId); }catch(err){}
    });

    App.els.pageStage.addEventListener('pointermove', function(e){
      if (!pf.dragging || e.pointerId !== activePointer) return;
      var dx = e.clientX - pf.startX;
      var dy = e.clientY - pf.startY;
      if (pf.locked === null){
        if (Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
        pf.locked = Math.abs(dx) > Math.abs(dy) * 0.8 ? 'x' : 'y';
      }
      if (pf.locked !== 'x') return;
      e.preventDefault();
      // dx>0 (left-to-right, forward) resists at the last page; dx<0 (right-to-left, backward) resists at page 1.
      if ((dx > 0 && pf.current >= App.TOTAL_PAGES) || (dx < 0 && pf.current <= 1)){
        dx = dx * 0.35; // resistance at the very start/end of the Quran
      }
      pf.dragX = dx;
      var tNow = e.timeStamp || Date.now(), dt = tNow - lastMoveT;
      if (dt > 0){ vx = 0.6 * vx + 0.4 * ((e.clientX - lastMoveX) / dt); }   // px/ms, মসৃণ গড়
      lastMoveX = e.clientX; lastMoveT = tNow;
      if (!dragRaf) dragRaf = requestAnimationFrame(paintDrag);
    });

    function endDrag(e){
      if (!pf.dragging || e.pointerId !== activePointer) return;
      pf.dragging = false;
      activePointer = null;
      if (dragRaf){ cancelAnimationFrame(dragRaf); dragRaf = 0; }
      if (pf.locked !== 'x'){
        if (baseX){ baseX = 0; settlePage(0); } else App.els.pageTrack.classList.remove('dragging');
        return;
      }
      var stageW = App.els.pageStage.clientWidth || 1;
      var ratio = (baseX + pf.dragX) / stageW;
      baseX = 0;
      var THRESH = 0.15;
      // ছোট কিন্তু দ্রুত টান (ফ্লিং) হলেও পেজ উল্টাবে — দ্রুত উল্টানোর জন্য সীমা কম
      var fling = (e.type === 'pointerup') && Math.abs(vx) > 0.3 && Math.abs(pf.dragX) > 18;
      var dir = 0;
      if (ratio <= -THRESH || (fling && vx < 0 && pf.dragX < 0)) dir = -1;
      else if (ratio >= THRESH || (fling && vx > 0 && pf.dragX > 0)) dir = 1;
      if (dir === -1 && pf.current > 1){ settlePage(-1); }
      else if (dir === 1 && pf.current < App.TOTAL_PAGES){ settlePage(1); }
      else { settlePage(0); }
    }
    App.els.pageStage.addEventListener('pointerup', endDrag);
    App.els.pageStage.addEventListener('pointercancel', endDrag);

    // Used by the zoom module when a second finger lands mid-swipe: snap the page back.
    pf.abortSwipe = function(){
      if (!pf.dragging && activePointer === null) return;
      var wasX = (pf.locked === 'x') || baseX;
      if (dragRaf){ cancelAnimationFrame(dragRaf); dragRaf = 0; }
      pf.dragging = false;
      activePointer = null;
      pf.locked = null;
      baseX = 0;
      if (wasX){ settlePage(0); } else { App.els.pageTrack.classList.remove('dragging'); }
    };

    // পর্দার মাপ/ঘূর্ণন বদলালে নতুন মাপে আঁকা
    var rzT = 0;
    window.addEventListener('resize', function(){
      clearTimeout(rzT);
      rzT = setTimeout(function(){ if (!App.els.pageFullscreen.classList.contains('hidden')) layout(pf.current); }, 250);
    });
  }
  App.bindDragNav = bindDragNav;

})(window.QuranApp = window.QuranApp || {});

