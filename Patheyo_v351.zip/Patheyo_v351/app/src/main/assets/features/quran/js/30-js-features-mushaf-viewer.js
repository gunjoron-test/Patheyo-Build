
/*!
 * js/features/mushaf-viewer.js -- Mushaf page preview inside a Para
 *
 * Provides : App.closeParaPages, App.openParaPages, App.pageState, App.showPreviewPage
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/para-meta, features/bookmark-fab,
               features/bookmark-modal, features/last-read, features/navigation, features/pdf-download-ui, services/pdf-download, services/pdf-service
 */
(function (App) {
  "use strict";

  // ---- Para page viewer (renders pages on-demand from the downloaded "Hafezi-Quran.pdf", see services/pdf-download.js) ----
  var pageState = { current:1 };
  App.pageState = pageState;

  function showPreviewPage(n){
    pageState.current = n;
    if (typeof App.updateBmFabIcon === 'function') App.updateBmFabIcon();
    if (typeof App.updateLastReadMushaf === 'function') App.updateLastReadMushaf(n);
    App.els.pagePreviewMissing.classList.add('hidden');
    App.els.pagePreviewCanvas.classList.remove('hidden');
    App.els.paraPagesBadge.textContent = 'পারা ' + App.bn(App.paraForPage(n));
    // Android app: the Mushaf PDF is downloaded on demand -> show the download card straight away.
    if (App.pdfDownload && App.pdfDownload.needsDownload()){ showPdfMissing(); return; }
    var targetW = Math.min((App.els.pagePreviewWrap.clientWidth || 320) * 0.8, 560) * (window.devicePixelRatio || 1);
    App.renderPageToCanvas(n, App.els.pagePreviewCanvas, targetW).then(function(){ setTools(true); }, showPdfMissing);
  }

  // ---- v342: মুসহাফের ফাইল ফোন থেকে মুছে ফেলা (হাদিসের কিতাব মোছার মতো) ----
  function $(id){ return document.getElementById(id); }
  function setTools(on){ var t = $('mushaf-tools'); if (t) t.classList.toggle('hidden', !on); }
  function sizeText(b){ return b > 0 ? (b / 1048576).toFixed(1) + ' MB' : ''; }
  (function bindRemove(){
    var btn = $('mushaf-remove-btn'), ov = $('mushaf-remove-overlay');
    if (!btn || !ov) return;
    function close(){ ov.classList.add('hidden'); }
    btn.addEventListener('click', function(){
      var sz = App.pdfDownload && App.pdfDownload.sizeOnPhone ? sizeText(App.pdfDownload.sizeOnPhone()) : '';
      $('mushaf-remove-context').innerHTML = '<strong style="color:var(--text)">হাফেজি মুসহাফ' + (sz ? ' (' + sz + ')' : '') + '</strong><br>' +
        'ফোনে এতটুকু জায়গা খালি হবে। বুকমার্ক, শেষ পড়ার জায়গা ও খতমের হিসাব থাকবে; আবার ডাউনলোড করে পড়তে পারবেন।';
      ov.classList.remove('hidden');
    });
    $('mushaf-remove-cancel-btn').addEventListener('click', close);
    ov.addEventListener('click', function(e){ if (e.target === ov) close(); });
    $('mushaf-remove-confirm-btn').addEventListener('click', function(){
      close();
      if (App.pdfDownload && App.pdfDownload.remove) App.pdfDownload.remove();
      else if (App.unloadPdf) App.unloadPdf(true);
      App.clearCanvas(App.els.pagePreviewCanvas);
      showPdfMissing();
      if (App.showSnackbar) App.showSnackbar('মুসহাফের ফাইলটি ফোন থেকে মুছে ফেলা হয়েছে');
    });
  })();

  function showPdfMissing(){
    setTools(false);
    App.els.pagePreviewCanvas.classList.add('hidden');
    App.els.pagePreviewMissing.classList.remove('hidden');
    if (App.syncPdfPanel) App.syncPdfPanel();
  }
  App.showPreviewPage = showPreviewPage;

  function openParaPages(idx){
    App.returnTab = App.state.tab;
    App.activeBookmarkId = null; App.activeBookmarkPos = null; App.updateBmFabIcon();
    App.els.paraPanel.classList.add('hidden');
    App.els.suraPanel.classList.add('hidden');       /* সূরা ট্যাব থেকে খুললে তালিকা আগে লুকাতো না — পেজ তালিকার নিচে দেখাতো */
    App.els.bookmarksPanel.classList.add('hidden');
    App.els.searchWrap.classList.add('hidden');
    App.els.readerPanel.classList.add('hidden');
    var kc = document.getElementById('khatm-card'); if (kc) kc.classList.add('hidden');
    App.els.continueCard.classList.add('hidden');
    App.els.paraPagesPanel.classList.remove('hidden');
    window.scrollTo(0,0);
    var range = App.PARA_PAGE_RANGE[idx-1];
    App.els.paraPagesMeta.textContent = 'পৃষ্ঠা ' + App.bn(range[0]) + '–' + App.bn(range[1]);
    showPreviewPage(range[0]);
    App.saveLastRead('para-page', idx, 'পারা ' + App.bn(idx), { pageNum: range[0], mode:'mushaf' });
    App.pushHistory('para-pages');
  }
  App.openParaPages = openParaPages;

  function closeParaPages(){
    App.els.paraPagesPanel.classList.add('hidden');
    App.switchTab(App.returnTab);
  }
  App.closeParaPages = closeParaPages;

})(window.QuranApp = window.QuranApp || {});

