
/*!
 * js/features/tarjama-reader.js -- তরজমা পড়ুন: সূরা খোলা, তিন রকম পড়ার ধরন, ব্যাখ্যার লাল ছোট নম্বর
 *
 * Provides : App.showTarjamaHome, App.openTarjamaReader, App.closeTarjamaReader, App.setTrMode,
 *            App.setTrShowArabic, App.renderOpenTarjama, App.isTarjamaReaderOpen, App.bindTarjamaReader
 * Needs    : core/dom, core/quran-meta, core/state, core/utils, data/surah-meta,
 *            services/tarjama-data, services/tarjama-download, features/navigation, features/footnote-popup,
 *            features/tarjama-download-ui
 *
 * আরবি আয়াত (মূল অ্যাপে অফলাইন) + বাংলা তরজমা/উচ্চারণ/ব্যাখ্যা (ডাউনলোড করা ফাইল থেকে) একসাথে সাজানো হয়।
 * ডাউনলোড করা না থাকলে সূরা খুললে ডাউনলোড কার্ড দেখায়।
 */
(function (App) {
  "use strict";

  var openSura = 0;                         // এখন কোন সূরা খোলা (০ = কোনোটি না)
  var KEY_MODE = 'quran-tr-mode', KEY_AR = 'quran-tr-show-arabic';

  function esc(s){ return App.escapeHtml(s); }
  function showArabic(){ var m = App.state.trMode; return m === 'ar-bn' || (m === 'ar-bn-tr' && App.state.trShowArabic); }
  function showTranslit(){ return App.state.trMode === 'ar-bn-tr'; }
  function readerOpen(){ return openSura > 0 && !App.els.trReaderPanel.classList.contains('hidden'); }
  App.isTarjamaReaderOpen = readerOpen;

  // ------------------------------------------------------------------ তালিকা (হোম)
  function showTarjamaHome(){
    openSura = 0;
    if (!App.els.trList.firstChild) App.renderTarjamaList();      // drawn on first visit only (keeps app start-up light)
    App.els.trReaderPanel.classList.add('hidden');
    App.els.trPanel.classList.remove('hidden');
    App.els.searchWrap.classList.remove('hidden');
    App.els.searchInput.value = '';
    App.els.searchInput.placeholder = 'সূরা নম্বর বা নাম লিখুন';
    App.filterActiveList('');
    App.els.continueCard.classList.add('hidden');
    syncTrTools();
  }
  App.showTarjamaHome = showTarjamaHome;

  // ---- v344: তরজমার ফাইল ফোন থেকে মুছে ফেলা (মুসহাফ ও হাদিসের কিতাবের মতো) ----
  function $(id){ return document.getElementById(id); }
  function syncTrTools(){
    var t = $('tarjama-tools'), dl = App.tarjamaDownload; if (!t) return;
    t.classList.toggle('hidden', !(dl && dl.isReady() && dl.getState().phase !== 'downloading'));
  }
  App.syncTarjamaTools = syncTrTools;
  (function bindTrRemove(){
    var btn = $('tarjama-remove-btn'), ov = $('tarjama-remove-overlay'), dl = App.tarjamaDownload;
    if (!btn || !ov || !dl) return;
    function close(){ ov.classList.add('hidden'); }
    btn.addEventListener('click', function(){
      var b = dl.sizeOnPhone ? dl.sizeOnPhone() : 0;
      var sz = b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : b > 0 ? Math.round(b / 1024) + ' KB' : '';
      $('tarjama-remove-context').innerHTML = '<strong style="color:var(--text)">কুরআনের তরজমা' + (sz ? ' (' + sz + ')' : '') + '</strong><br>' +
        'ফোনে এতটুকু জায়গা খালি হবে। বুকমার্ক ও শেষ পড়ার জায়গা থাকবে; আবার ডাউনলোড করে পড়তে পারবেন।';
      ov.classList.remove('hidden');
    });
    $('tarjama-remove-cancel-btn').addEventListener('click', close);
    ov.addEventListener('click', function(e){ if (e.target === ov) close(); });
    $('tarjama-remove-confirm-btn').addEventListener('click', function(){
      close();
      dl.remove();
      syncTrTools();
      if (App.showSnackbar) App.showSnackbar('তরজমার ফাইলটি ফোন থেকে মুছে ফেলা হয়েছে');
    });
    dl.subscribe(function(){ syncTrTools(); });     // ডাউনলোড শেষ / মোছা হলে বোতাম দেখানো/লুকানো
  })();

  // ------------------------------------------------------------------ HTML তৈরি
  function bismillahRow(){
    return '<div class="bismillah-row"><span class="bl-line"></span>' + App.bismillahSvg() + '<span class="bl-line"></span></div>';
  }

  // তরজমার লেখায় [[N]] চিহ্নকে ছোট লাল ব্যাজে বদলায় (ক্লিক করলে ব্যাখ্যা খোলে)।
  // ব্যাখ্যার লেখা ফাইলে না থাকলে ওই জায়গায় কিছুই দেখানো হয় না; লেখা যোগ হলে (ফাইল নতুন করে ডাউনলোড হলে) নিজে থেকে দেখা দেয়।
  function withNotes(text, suraIdx, ayahIdx, notes){
    return esc(text).replace(/\[\[(\d+)\]\]/g, function(_, n){
      if (!notes || !notes[n]) return '';
      return '<sup class="fn-ref" role="button" tabindex="0" data-sura="' + suraIdx + '" data-ayah="' + ayahIdx +
             '" data-fn="' + n + '" aria-label="ব্যাখ্যা ' + App.bn(n) + '">' + App.bn(n) + '</sup>';
    });
  }

  // Every ayah card holds ALL its parts (Arabic / transliteration / Bangla). Which parts are visible is decided by CSS
  // from data-mode / data-ar on #tr-verses, so switching the reading mode is instant -- no re-render, no re-shaping.
  function buildVerses(idx){
    var sura = App.quranModel[idx - 1];
    var tr = App.tarjamaData.getSura(idx);
    var html = [];
    if (idx === 1 || (sura.ayahs[0] && sura.ayahs[0].bismillah)) html.push(bismillahRow());
    var n = Math.min(sura.ayahs.length, tr.a.length);
    for (var i = 0; i < n; i++){
      var a = sura.ayahs[i], t = tr.a[i];
      html.push(
        '<article class="tr-ayah" id="trayah-' + a.index + '" data-ayah="' + a.index + '" data-sura="' + idx + '">' + (window.PtShareCard ? window.PtShareCard.btnHtml() : '') + (window.QuranAudio ? window.QuranAudio.ayahBtnHtml() : '') +
          '<div class="tr-arabic" dir="rtl" lang="ar">' + App.formatArabic(a.text) + ' <span class="tr-end">' + App.ar(a.index) + '</span></div>' +
          (t.u ? '<div class="tr-translit">' + esc(t.u) + '</div>' : '') +
          '<div class="tr-bn"><span class="tr-num">' + App.bn(a.index) + '</span>' + withNotes(t.t, idx, a.index, tr.f) + '</div>' +
        '</article>'
      );
    }
    return html.join('');
  }

  function applyMode(){
    App.els.trVerses.setAttribute('data-mode', App.state.trMode);
    App.els.trVerses.setAttribute('data-ar', App.state.trShowArabic ? 'on' : 'off');
  }

  // ------------------------------------------------------------------ অবস্থা: loading / verses / download
  function showState(which){
    App.els.trVerses.classList.toggle('hidden', which === 'download');
    App.els.trDlPanel.classList.toggle('hidden', which !== 'download');
    App.els.trToolbar.classList.toggle('hidden', !(which === 'verses' && App.state.trMode === 'ar-bn-tr'));
    App.els.trReaderCredit.classList.toggle('hidden', which !== 'verses');
    App.els.trReaderPanel.classList.toggle('tr-dl-mode', which === 'download');
    if (which !== 'verses') App.els.trReaderHint.classList.add('hidden');
    if (which === 'download' && App.syncTarjamaPanel) App.syncTarjamaPanel();
  }

  function syncToolbar(){
    var on = !!App.state.trShowArabic;
    App.els.trArToggle.setAttribute('aria-checked', on ? 'true' : 'false');
    App.els.trArToggle.classList.toggle('on', on);
    App.els.trArToggleLabel.textContent = on ? 'আরবি লেখা দেখানো হচ্ছে' : 'আরবি লেখা লুকানো আছে';
  }

  // হেডার-বার স্ক্রলে লুকায়/ফেরে (header-autohide.js); লুকানো থাকলে তার নিচের কিনারা পর্দার বাইরে -- তাই নেগেটিভ মান ০ ধরা হয়
  function headerBottom(){
    var h = document.querySelector('.app-header');
    return h ? Math.max(0, h.getBoundingClientRect().bottom) : 0;
  }

  function visibleAyah(){
    var list = App.els.trVerses.querySelectorAll('.tr-ayah');
    var edge = headerBottom() + 4;
    for (var i = 0; i < list.length; i++){
      if (list[i].getBoundingClientRect().bottom > edge) return parseInt(list[i].getAttribute('data-ayah'), 10) || 1;
    }
    return 1;
  }

  function renderVerses(idx){
    var html;
    try { html = buildVerses(idx); }
    catch(e){                                    // damaged file: discard it so the user can download again
      App.els.trVerses.innerHTML = '';
      App.tarjamaData.unload();
      App.tarjamaDownload.discard();
      App.tarjamaDownload.setError('corrupt');
      showState('download');
      return;
    }
    var trAuthor = App.tarjamaData.getAuthor();
    App.els.trReaderCredit.innerHTML = trAuthor ? '<span class="trc-l">তরজমা ও ব্যাখ্যা</span><span class="trc-n">' + App.escapeHtml(trAuthor) + '</span>' : '';
    syncToolbar();
    applyMode();
    App.els.trVerses.innerHTML = html;
    showState('verses');
    showHintIfNeeded();
    if (pendingAyah){ var pa = pendingAyah; pendingAyah = 0; scrollToAyah(pa); }
  }

  // ছোট লাল নম্বরে ট্যাপ করলে ব্যাখ্যা খোলে -- প্রথম কয়েকবার একটি ছোট ইঙ্গিত দেখানো হয়, প্রথম ব্যাখ্যা খুললে আর দেখানো হয় না
  var KEY_HINT = 'quran-fn-hint-seen';
  function hintSeen(){ try { return localStorage.getItem(KEY_HINT) === '1'; } catch(e){ return false; } }
  function showHintIfNeeded(){
    var has = App.els.trVerses.querySelector('.fn-ref') !== null;
    App.els.trReaderHint.classList.toggle('hidden', !(has && !hintSeen()));
  }
  App.markFootnoteHintSeen = function(){ try { localStorage.setItem(KEY_HINT, '1'); } catch(e){} App.els.trReaderHint.classList.add('hidden'); };

  // পড়ার ধরন / আরবি দেখানো বদলালে: শুধু CSS বদলায়, আর এখন যে আয়াত পর্দার ওপরে সেটি একই জায়গায় থাকে
  function renderOpenTarjama(keepPosition){
    if (!readerOpen() || !App.tarjamaData.isLoaded()) return;
    var pos = keepPosition ? visibleAyah() : 1;
    var el = document.getElementById('trayah-' + pos);
    var before = el ? el.getBoundingClientRect().top : 0;
    applyMode();
    showState('verses');
    if (el && keepPosition){
      var d = el.getBoundingClientRect().top - before;
      if (d) window.scrollBy(0, d);
    }
  }
  App.renderOpenTarjama = renderOpenTarjama;

  function loadAndRender(idx, keepPosition){
    if (App.tarjamaData.isLoaded()){ renderVerses(idx); return; }
    App.els.trVerses.innerHTML = '<div class="tr-loading"><span class="tr-spinner"></span>তরজমা লোড হচ্ছে…</div>';
    showState('verses');
    App.els.trReaderCredit.classList.add('hidden');
    App.els.trToolbar.classList.add('hidden');
    App.tarjamaData.load().then(function(){
      if (openSura !== idx || !readerOpen()) return;
      renderVerses(idx);
    }).catch(function(e){
      if (openSura !== idx || !readerOpen()) return;
      App.els.trVerses.innerHTML = '';
      if (e && e.code === 'corrupt'){
        App.tarjamaDownload.discard();
        App.tarjamaDownload.setError('corrupt');
      }
      showState('download');
    });
  }

  // ------------------------------------------------------------------ খোলা / বন্ধ
  var pendingAyah = 0;                       // সার্চ থেকে এলে: খোলার পর যে আয়াতে যেতে হবে
  function scrollToAyah(n){
    var el = document.getElementById('trayah-' + n);
    if (!el) return;
    function fix(){
      var e2 = document.getElementById('trayah-' + n);
      if (!e2) return;
      var y = e2.getBoundingClientRect().top + window.pageYOffset - (headerBottom() + 10);
      if (Math.abs(e2.getBoundingClientRect().top - (headerBottom() + 10)) < 3) return;
      try { window.scrollTo({ top: Math.max(0, y), behavior: 'instant' }); } catch(e){ window.scrollTo(0, Math.max(0, y)); }
    }
    fix();
    // আরবি ফন্ট/লেআউট বসার পর উচ্চতা বদলায় -- তাই কয়েকবার ঠিক করে নিই
    [80, 250, 600].forEach(function(ms){ setTimeout(function(){ if (document.getElementById('trayah-' + n)) fix(); }, ms); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fix);
    el.classList.remove('hs-hit'); void el.offsetWidth; el.classList.add('hs-hit');
    setTimeout(function(){ el.classList.remove('hs-hit'); }, 2300);
  }
  App.scrollToTarjamaAyah = scrollToAyah;

  function openTarjamaReader(idx, ayah){
    var alreadyOpen = readerOpen();
    pendingAyah = ayah || 0;
    openSura = idx;
    var sura = App.quranModel[idx - 1];
    App.els.trPanel.classList.add('hidden');
    App.els.trReaderPanel.classList.remove('hidden');
    App.els.trReaderBadge.textContent = 'সূরা ' + App.bn(idx);
    App.els.trReaderArabicName.innerHTML = App.surahGlyph(sura.index, 'sg-header');
    App.els.trReaderNameCaption.innerHTML = '<span class="rn-en">' + (App.SURAH_EN[sura.index - 1] || '') + '</span><span class="rn-dot">·</span>' + (App.SURAH_BN[sura.index - 1] || '');
    App.els.trReaderMeta.innerHTML = App.heroStatsHtml(sura);
    App.els.trReaderMeta.setAttribute('aria-label', 'আয়াত সংখ্যা: ' + App.bn(sura.ayahs.length));
    App.els.trVerses.innerHTML = '';
    window.scrollTo(0, 0);
    if (!alreadyOpen) App.pushHistory('tr-reader');
    loadAndRender(idx, false);
  }
  App.openTarjamaReader = openTarjamaReader;

  function closeTarjamaReader(){
    openSura = 0;
    App.els.trReaderPanel.classList.add('hidden');
    App.els.trPanel.classList.remove('hidden');
    App.els.trVerses.innerHTML = '';
  }
  App.closeTarjamaReader = closeTarjamaReader;

  // ডাউনলোড শেষ হলে (বা ফাইল পাওয়া গেলে) খোলা সূরাটি দেখানো
  App.onTarjamaDownloaded = function(){
    if (readerOpen()) loadAndRender(openSura, false);
  };

  // ------------------------------------------------------------------ সেটিংস
  function setTrMode(mode){
    if (mode !== 'ar-bn' && mode !== 'bn' && mode !== 'ar-bn-tr') return;
    App.state.trMode = mode;
    try { localStorage.setItem(KEY_MODE, mode); } catch(e){}
    App.els.trModeBtns.forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-tr-mode') === mode); });
    if (readerOpen() && App.tarjamaData.isLoaded()) renderOpenTarjama(true);
    else if (readerOpen()) showState(App.els.trDlPanel.classList.contains('hidden') ? 'verses' : 'download');
  }
  App.setTrMode = setTrMode;

  function setTrShowArabic(on){
    App.state.trShowArabic = !!on;
    try { localStorage.setItem(KEY_AR, on ? '1' : '0'); } catch(e){}
    syncToolbar();
    if (readerOpen() && App.tarjamaData.isLoaded()) renderOpenTarjama(true);
  }
  App.setTrShowArabic = setTrShowArabic;

  // ------------------------------------------------------------------ events
  function bindTarjamaReader(){
    try {
      var m = localStorage.getItem(KEY_MODE);
      if (m === 'ar-bn' || m === 'bn' || m === 'ar-bn-tr') App.state.trMode = m;
      App.state.trShowArabic = localStorage.getItem(KEY_AR) !== '0';
    } catch(e){}
    App.els.trModeBtns.forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-tr-mode') === App.state.trMode); });
    syncToolbar();

    App.els.trModeBtns.forEach(function(btn){
      btn.addEventListener('click', function(){ setTrMode(btn.getAttribute('data-tr-mode')); });
    });
    App.els.trBackBtn.addEventListener('click', App.goBackOneLevel);
    App.els.trArToggle.addEventListener('click', function(){ setTrShowArabic(!App.state.trShowArabic); });

    function openNote(el){
      var sura = parseInt(el.getAttribute('data-sura'), 10), fn = parseInt(el.getAttribute('data-fn'), 10), ayah = parseInt(el.getAttribute('data-ayah'), 10);
      if (sura && fn) App.openFootnote(sura, fn, ayah);
    }
    // ---- শেয়ার কার্ড: আয়াতের ছবি বানিয়ে WhatsApp/Facebook-এ শেয়ার (shared/share-card.js) ----
    App.els.trVerses.addEventListener('click', function(e){
      var sb = e.target.closest ? e.target.closest('[data-pt-share]') : null;
      if (!sb || !window.PtShareCard) return;
      var card = sb.closest('.tr-ayah'); if (!card) return;
      var sIdx = parseInt(card.getAttribute('data-sura'), 10), aIdx = parseInt(card.getAttribute('data-ayah'), 10);
      var sura = App.quranModel[sIdx - 1], tr = App.tarjamaData.getSura(sIdx), ay = null, tx = null, i;
      for (i = 0; i < sura.ayahs.length; i++){ if (sura.ayahs[i].index === aIdx){ ay = sura.ayahs[i]; tx = tr.a[i]; break; } }
      if (!ay) return;
      window.PtShareCard.open({
        kind: 'ayah',
        title: 'সূরা ' + (App.SURAH_BN[sIdx - 1] || ''),
        ar: ay.text,
        tr: tx && tx.u ? tx.u : '',
        bn: tx && tx.t ? String(tx.t).replace(/\[\[\d+\]\]/g, '').replace(/\s+/g, ' ').trim() : '',
        ref: 'সূরা ' + (App.SURAH_BN[sIdx - 1] || '') + ' · আয়াত ' + App.bn(aIdx)
      });
    });
    App.els.trVerses.addEventListener('click', function(e){
      var t = e.target;
      while (t && t !== App.els.trVerses && !(t.classList && t.classList.contains('fn-ref'))){ t = t.parentNode; }
      if (t && t !== App.els.trVerses) openNote(t);
    });
    App.els.trVerses.addEventListener('keydown', function(e){
      if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('fn-ref')){
        e.preventDefault(); openNote(e.target);
      }
    });
  }
  App.bindTarjamaReader = bindTarjamaReader;

})(window.QuranApp = window.QuranApp || {});

