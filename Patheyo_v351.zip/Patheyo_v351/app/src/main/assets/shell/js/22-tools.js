/* =============================================================================
   v347: টুল-পেজের কাঠামো — সব নতুন টুল (জামাত, সফর/মাজুর, রোজা …) একটিই পেজে (#tool-overlay) খোলে,
   তাই হেডার, খোলা/বন্ধের অ্যানিমেশন, ব্যাক-বোতাম, ফুটার ও থিম — সব হুবহু যাকাত/সেটিংস পেজের মতো।

   নতুন টুল যোগ করা:
     PTTools.register('id', { title, sub, icon, group, order, hub:{t, s}, render: function (body, ui, arg) {…} });
     খোলা:  __ptGo('tool:id')  ·  <button data-go="tool:id">  ·  PTTools.open('id')
   group = হাবে কোন ভাগে দেখাবে ('prayer' | 'fasting' | 'learn' | 'calc' | 'premium')।
   ui = ছোট সহায়ক: ui.bn, ui.esc, ui.ic, ui.card, ui.row, ui.sw, ui.chips, ui.seg, ui.notice, ui.toast, ui.t12 …
   নিরাপত্তা (SECURITY_RULES.md §৪): ইউজারের লেখা/বাইরের ডেটা DOM-এ বসাতে সবসময় ui.esc() — innerHTML-এ কাঁচা লেখা নয়।
   ============================================================================= */
(function () {
  'use strict';
  var D = document, W = window;
  function $(id) { return D.getElementById(id); }
  var body = $('tool-body'); if (!body) return;
  var BN = '০১২৩৪৫৬৭৮৯';
  function bn(s) { return String(s).replace(/\d/g, function (d) { return BN[d]; }); }
  function en(s) { return String(s == null ? '' : s).replace(/[০-৯]/g, function (d) { return BN.indexOf(d); }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ic(n, c) { return W.PT && PT.icon ? PT.icon(n, c || '') : ''; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dkey(d) { d = d || new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseKey(k) { var a = String(k).split('-'); return new Date(+a[0], +a[1] - 1, +a[2]); }
  /* "HH:MM" বা মিনিট → "দুপুর ১:৩০" */
  function t12(v) {
    var min = typeof v === 'number' ? v : (function () { var p = String(v || '').split(':'); return (+p[0]) * 60 + (+p[1] || 0); })();
    min = ((Math.round(min) % 1440) + 1440) % 1440;
    var h = Math.floor(min / 60), m = min % 60;
    var part = h < 4 ? 'রাত' : h < 6 ? 'ভোর' : h < 12 ? 'সকাল' : h < 15 ? 'দুপুর' : h < 18 ? 'বিকাল' : h < 20 ? 'সন্ধ্যা' : 'রাত';
    return part + ' ' + bn((h % 12 || 12) + ':' + pad(m));
  }
  function hhmm(min) { min = ((Math.round(min) % 1440) + 1440) % 1440; return pad(Math.floor(min / 60)) + ':' + pad(min % 60); }
  function toMin(s) { var p = String(s || '').split(':'); return p.length >= 2 && !isNaN(+p[0]) ? (+p[0]) * 60 + (+p[1]) : null; }
  var MONTH_BN = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  function dateBn(d) { d = typeof d === 'string' ? parseKey(d) : d; return bn(d.getDate()) + ' ' + MONTH_BN[d.getMonth()]; }
  function lsGet(k, def) { try { var v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? def : v; } catch (e) { return def; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function toast(t, o) { if (W.PT && PT.toast) PT.toast(t, o || {}); }
  function haptic(k) { try { if (W.PT && PT.haptic) PT.haptic(k || 'light'); } catch (e) {} }

  /* ---------- ছোট UI-টুকরো (ডিজাইন সিস্টেমের ক্লাস — অ্যাপের বাকি অংশের সাথে একই ছন্দ) ---------- */
  var ui = {
    bn: bn, en: en, esc: esc, ic: ic, pad: pad, dkey: dkey, parseKey: parseKey, t12: t12, hhmm: hhmm, toMin: toMin, dateBn: dateBn,
    get: lsGet, set: lsSet, toast: toast, haptic: haptic,
    /* কার্ড: আইকন-পদক + শিরোনাম + এক লাইনের ব্যাখ্যা + ভেতর */
    card: function (o) {
      return '<section class="tk-card pt-card' + (o.cls ? ' ' + o.cls : '') + '"' + (o.id ? ' id="' + o.id + '"' : '') + '>' +
        (o.title ? '<header class="tk-ch"><span class="pt-medal tk-cm">' + ic(o.icon || 'sparkle') + '</span><span class="tk-ct"><b>' + o.title + '</b>' +
          (o.sub ? '<small>' + o.sub + '</small>' : '') + '</span>' + (o.right || '') + '</header>' : '') +
        (o.body || '') + '</section>';
    },
    /* সারি: বাঁয়ে লেখা, ডানে যা খুশি (সুইচ, মান, বোতাম) */
    row: function (title, sub, right, attrs) {
      return '<div class="tk-row"' + (attrs || '') + '><span class="tk-rt"><b>' + title + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</span>' + (right || '') + '</div>';
    },
    sw: function (name, on, label) {
      return '<label class="pt-switch" aria-label="' + esc(label || '') + '"><input type="checkbox" data-sw="' + name + '"' + (on ? ' checked' : '') + '><span class="pt-switch__track"></span></label>';
    },
    /* চিপ-সারি: [[মান, লেখা], …] — একটিই বাছাই */
    chips: function (name, list, cur) {
      return '<div class="tk-chips" role="radiogroup">' + list.map(function (x) {
        var v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : bn(x);
        return '<button type="button" class="pt-chip tk-chip' + (String(v) === String(cur) ? ' is-on' : '') + '" role="radio" aria-checked="' + (String(v) === String(cur)) + '" data-chip="' + name + '" data-v="' + esc(v) + '">' + l + '</button>';
      }).join('') + '</div>';
    },
    seg: function (name, list, cur) {
      return '<div class="pt-seg tk-seg" role="tablist">' + list.map(function (x) {
        return '<button class="pt-seg__btn" type="button" role="tab" data-seg="' + name + '" data-v="' + esc(x[0]) + '" aria-selected="' + (String(x[0]) === String(cur)) + '">' + x[1] + '</button>';
      }).join('') + '</div>';
    },
    notice: function (kind, title, text, btn) {
      return '<div class="pt-notice tk-notice' + (kind ? ' pt-notice--' + kind : '') + '">' + ic(kind === 'warning' ? 'alert' : kind === 'success' ? 'check-circle' : 'info') +
        '<div class="pt-grow">' + (title ? '<div class="pt-notice__title">' + title + '</div>' : '') + '<div>' + text + '</div>' + (btn || '') + '</div></div>';
    },
    /* ফোনের নিজের সময়-বাছাই খোলা (input[type=time]) */
    pickTime: function (cur, cb) {
      var i = D.createElement('input'); i.type = 'time'; i.value = cur || '13:30'; i.className = 'tk-time-in'; i.setAttribute('aria-hidden', 'true'); i.tabIndex = -1;
      D.body.appendChild(i);
      var done = false;
      function fin() { if (done) return; done = true; var v = i.value; try { D.body.removeChild(i); } catch (e) {} if (/^\d{2}:\d{2}$/.test(v)) cb(v); }
      i.addEventListener('change', fin); i.addEventListener('blur', function () { setTimeout(fin, 50); });
      try { if (i.showPicker) i.showPicker(); else { i.focus(); i.click(); } } catch (e) { i.focus(); i.click(); }
    },
    rerender: function () { if (curId) render(curId, curArg); },
    /* v350: arg (যেমন "2:255") একবার ব্যবহারের পর মুছে ফেলা — পরের rerender-এ আবার সেখানে ফিরে না যায় */
    consumeArg: function () { curArg = ''; },
    /* v349: দোয়া ফিচারের দোয়া id দিয়ে (একই যাচাই-করা লেখা) */
    duaById: function (id) { return (W.DUA_ITEMS || []).filter(function (d) { return d.id === id; })[0] || null; },
    /* দোয়ার ব্লক: আরবি + উচ্চারণ + অর্থ + সূত্র। আরবি কমা (،) অ্যাপের কুরআনি ফন্টে আয়াত-চিহ্নের মতো দেখায় — তাই বাদ */
    dua: function (d, o) {
      if (!d) return '';
      o = o || {};
      var ar = String(d.ar || '').replace(/\s*،\s*/g, ' ');
      return '<div class="tk-dua">' + (o.title || d.t ? '<b class="tk-dua-t">' + esc(o.title || d.t) + (o.times ? ' <span class="pt-chip ak-times">' + o.times + '</span>' : '') + '</b>' : '') +
        '<p class="pt-ar ak-ar" dir="rtl" lang="ar">' + esc(ar) + '</p>' +
        (d.tr && o.tr !== false ? '<p class="ak-tr2">' + esc(d.tr) + '</p>' : '') + (d.bn ? '<p class="ak-bn">' + esc(d.bn) + '</p>' : '') +
        (o.note || d.note ? '<p class="ak-f">' + ic('info') + '<span>' + esc(o.note || d.note) + '</span></p>' : '') +
        (d.ref ? '<p class="ak-ref">সূত্র: ' + esc(d.ref) + '</p>' : '') + '</div>';
    },
    /* ভাঁজ-করা অংশ (একবারে একটি খোলা) */
    acc: function (id, open, icon, title, sub, inner) {
      return '<section class="tk-card pt-card tk-acc' + (open ? ' is-open' : '') + '">' +
        '<button type="button" class="tk-acch" data-act="acc" data-v="' + id + '" aria-expanded="' + !!open + '"><span class="pt-medal tk-cm">' + ic(icon) + '</span>' +
        '<span class="tk-ct"><b>' + title + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</span>' + ic(open ? 'chev-up' : 'chev-down', 'tk-chev') + '</button>' +
        (open ? '<div class="tk-accb">' + inner + '</div>' : '') + '</section>';
    },
    steps: function (arr) {
      return '<ol class="tk-steps">' + arr.map(function (x, i) {
        return '<li><span class="pt-numbadge">' + bn(i + 1) + '</span><div>' + (Array.isArray(x) ? '<b>' + x[0] + '</b>' + (x[1] ? '<small>' + x[1] + '</small>' : '') : x) + '</div></li>';
      }).join('') + '</ol>';
    }
  };

  /* ---------- নিবন্ধন ও খোলা ---------- */
  var REG = {}, curId = '', curArg = '';
  var GROUPS = [
    ['prayer', 'নামাজ', 'mosque'], ['fasting', 'রোজা', 'iftar'], ['dhikr', 'জিকির ও দোয়া', 'beads'],
    ['calc', 'হিসাব', 'zakat'], ['learn', 'শিখুন ও জানুন', 'book'], ['premium', 'প্রিমিয়াম', 'crown']
  ];
  function register(id, def) { def.id = id; REG[id] = def; }
  function open(id, src, arg) {
    if (!REG[id]) id = 'hub';
    curArg = arg || '';
    if (W.__ptPages) W.__ptPages.open('tool:' + id, src || null);
    if (curId === id) render(id, curArg);        /* একই টুল আবার খুললে (যেমন নোটিফিকেশন থেকে) নতুন করে আঁকা */
  }
  function render(id, arg) {
    var def = REG[id] || REG.hub; if (!def) return;
    if (arg !== undefined) curArg = arg;
    curId = def.id;
    $('tool-title').textContent = def.title;
    $('tool-sub').textContent = def.sub || '';
    $('tool-ico').innerHTML = ic(def.icon || 'tools');
    body.setAttribute('data-tool', def.id);
    try { def.render(body, ui, curArg); } catch (e) { body.innerHTML = ui.notice('warning', 'পেজটি খোলা যায়নি', 'আবার চেষ্টা করুন।'); }
    if (W.PT && PT.hydrateIcons) PT.hydrateIcons(body);
    if (W.PT && PT.seg) [].forEach.call(body.querySelectorAll('.pt-seg'), function (sg) { try { PT.seg(sg); } catch (e) {} });   /* চলমান নির্দেশক */
  }
  W.PTTools = { register: register, open: open, render: function (id) { render(id); body.scrollTop = 0; }, ui: ui, list: function () { return REG; }, current: function () { return curId; } };

  /* টুলের ভেতরের সাধারণ ঘটনা: সুইচ/চিপ/সেগমেন্ট → টুলের নিজের onEvent */
  function dispatch(kind, name, value, el, e) {
    var def = REG[curId]; if (!def || typeof def.onEvent !== 'function') return;
    try { def.onEvent(kind, name, value, el, ui, e); } catch (er) {}
  }
  body.addEventListener('change', function (e) {
    var t = e.target; if (!t || !t.getAttribute) return;
    if (t.hasAttribute('data-sw')) { haptic('light'); dispatch('sw', t.getAttribute('data-sw'), !!t.checked, t, e); }
    else if (t.hasAttribute('data-in')) dispatch('in', t.getAttribute('data-in'), t.value, t, e);
  });
  body.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target : null; if (!t) return;
    var c = t.closest('[data-chip]');
    if (c) { haptic('light'); dispatch('chip', c.getAttribute('data-chip'), c.getAttribute('data-v'), c, e); return; }
    var s = t.closest('[data-seg]');
    if (s) { haptic('light'); dispatch('seg', s.getAttribute('data-seg'), s.getAttribute('data-v'), s, e); return; }
    var a = t.closest('[data-act]');
    if (a) { dispatch('act', a.getAttribute('data-act'), a.getAttribute('data-v'), a, e); return; }
    var g = t.closest('[data-tool-open]');
    if (g) { open(g.getAttribute('data-tool-open')); }
  });

  /* ---------- হাব: সব টুল এক জায়গায় (নতুন ব্যাচগুলো এখানে নিজে থেকেই যোগ হয়) ---------- */
  register('hub', {
    title: 'সব টুল', sub: 'নামাজ, রোজা, শেখা ও হিসাবের সহায়ক', icon: 'tools',
    render: function (el, ui) {
      var all = Object.keys(REG).map(function (k) { return REG[k]; }).filter(function (d) { return d.hub; });
      el.innerHTML = '<div class="tk-wrap">' + GROUPS.map(function (g) {
        var items = all.filter(function (d) { return d.group === g[0]; }).sort(function (a, b) { return (a.order || 50) - (b.order || 50); });
        if (!items.length) return '';
        return '<div class="pt-section tk-sec-h"><span class="pt-section__title">' + g[1] + '</span><span class="pt-section__line"></span></div>' +
          '<div class="tk-hub pt-card">' + items.map(function (d) {
            return '<button class="tk-hub-i" type="button" data-tool-open="' + d.id + '"><span class="pt-medal tk-hm">' + ic(d.icon) + '</span>' +
              '<span class="tk-ht"><b>' + d.hub.t + '</b><small>' + d.hub.s + '</small></span>' + (d.premium ? '<span class="pt-chip pt-chip--gold tk-pr">' + ic('crown') + 'প্রিমিয়াম</span>' : '') + ic('forward', 'tk-hc') + '</button>';
          }).join('') + '</div>';
      }).join('') + '</div>';
    }
  });
})();
