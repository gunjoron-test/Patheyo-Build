/* =============================================================================
   v350 (প্রিমিয়াম): নিজের পছন্দের আজানের কণ্ঠ (tool:azanvoice)
   নেটিভ: PatheyoAzanVoice (app/.../alarm/AzanVoice.kt) — ফাইল বাছা, যাচাই (অডিও কিনা, ৫ সে.–৮ মি., ≤১৫ MB), কপি, শুনে দেখা, মুছে ফেলা।
   প্রিমিয়ামের সিদ্ধান্ত নেটিভে (PremiumBridge.isActive) — এখানে শুধু দেখানো। প্রিমিয়াম শেষ হলে অ্যাপের নিজের আজান বাজে।
   কেন ডাউনলোড-করা "কণ্ঠের তালিকা" নয়: আজানের রেকর্ডিংগুলোর ব্যবহারের অনুমতি নিশ্চিত করা যায়নি; নিজের বাছা ফাইলে সে সমস্যা নেই।
   ============================================================================= */
(function () {
  'use strict';
  var W = window, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic, esc = ui.esc;
  function N() { return W.PatheyoAzanVoice || null; }
  function premium() { try { return !!(W.ptIsPremium && W.ptIsPremium()); } catch (e) { return false; } }
  function state() { try { var n = N(); if (n) return JSON.parse(n.state()) || {}; } catch (e) {} return { custom: false }; }
  var S = { busy: false, playing: '' };
  var seq = 0, wait = {};
  W.__ptAzanCb = function (id, json) { var f = wait[id]; if (!f) return; delete wait[id]; var r; try { r = JSON.parse(json); } catch (e) { r = { ok: false }; } f(r); };
  W.__ptAzanStopped = function () { S.playing = ''; if (T.current() === 'azanvoice') ui.rerender(); };
  var ERR = { premium: 'এটি প্রিমিয়াম সুবিধা।', big: 'ফাইলটি অনেক বড় — ১৫ MB-এর ছোট ফাইল বাছুন।', type: 'এটি চালানো যায় এমন অডিও ফাইল নয়।', short: 'অডিওটি খুব ছোট (৫ সেকেন্ডের কম)।', long: 'অডিওটি অনেক লম্বা — ৮ মিনিটের কম হতে হবে।', read: 'ফাইলটি পড়া যায়নি, আবার চেষ্টা করুন।' };
  function mmss(s) { s = Math.round(+s || 0); return bn(Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2)); }

  function render(el) {
    var st = state(), n = N(), pr = premium();
    var cur = st.custom ? '<div class="av-cur"><span class="pt-medal tk-cm">' + ic('volume') + '</span><span class="tk-ct"><b>' + esc(st.name || 'আমার আজান') + '</b><small>' + mmss(st.sec) + ' মিনিট · ' + (st.active ? 'ওয়াক্তের আজানে এটিই বাজবে' : 'প্রিমিয়াম চালু হলে বাজবে') + '</small></span>' +
        '<button type="button" class="pt-iconbtn" data-act="play" data-v="custom" aria-label="শুনুন">' + ic(S.playing === 'custom' ? 'pause' : 'play') + '</button></div>' : '';
    el.innerHTML = '<div class="tk-wrap">' +
      ui.card({ icon: 'volume', title: 'আজানের কণ্ঠ', sub: 'ওয়াক্তের আজানে কোন কণ্ঠ বাজবে', body:
        '<div class="av-opt' + (!st.active ? ' is-on' : '') + '"><span class="tk-ct"><b>অ্যাপের নিজের আজান</b><small>' + (!st.active ? 'এখন এটিই বাজে' : 'ডিফল্ট') + '</small></span>' +
          '<button type="button" class="pt-iconbtn" data-act="play" data-v="default" aria-label="শুনুন">' + ic(S.playing === 'default' ? 'pause' : 'play') + '</button></div>' + cur }) +
      (pr ? ui.card({ icon: 'upload', title: st.custom ? 'অন্য আজান বাছুন' : 'নিজের পছন্দের আজান যোগ করুন', sub: 'ফোনে রাখা যেকোনো আজানের অডিও (MP3, M4A, OGG…)', body:
          '<button type="button" class="pt-btn pt-btn--primary av-pick" data-act="pick"' + (S.busy || !n ? ' disabled' : '') + '>' + (S.busy ? '<span class="pt-spinner"></span>যাচাই হচ্ছে…' : ic('upload') + 'ফোন থেকে বাছুন') + '</button>' +
          (st.custom ? '<button type="button" class="pt-btn pt-btn--ghost av-reset" data-act="reset">' + ic('undo') + 'অ্যাপের নিজের আজানে ফিরুন</button>' : '') +
          '<ul class="tk-ul tk-ul--sm"><li>৫ সেকেন্ড থেকে ৮ মিনিট, ১৫ MB পর্যন্ত।</li><li>ফাইলটি অ্যাপের নিজের জায়গায় কপি হয় — মূল ফাইল মুছলেও আজান থাকবে।</li><li>পছন্দের মুয়াজ্জিনের আজান নির্ভরযোগ্য জায়গা থেকে নামিয়ে রাখুন; ফজরের জন্য "আস-সালাতু খাইরুম মিনান নাওম"-সহ আজান হলে উত্তম।</li></ul>' })
        : '<div class="tk-card pt-card rp-lock"><span class="pt-medal tk-cm">' + ic('crown') + '</span><b>নিজের পছন্দের আজান — প্রিমিয়াম সুবিধা</b><p class="tk-p">মক্কা, মদিনা বা আপনার প্রিয় যেকোনো মুয়াজ্জিনের আজান ফোন থেকে বেছে নিন — ওয়াক্তের আজানে সেটিই বাজবে।</p>' +
          '<button type="button" class="pt-btn pt-btn--primary" data-act="premium">' + ic('crown') + 'প্রিমিয়াম দেখুন</button></div>') +
      (!n ? ui.notice('', '', 'এই সুবিধা শুধু অ্যাপের ভেতরে কাজ করে।') : '') +
      '<p class="tk-fine">' + ic('info') + 'শুনে দেখা মিডিয়া ভলিউমে বাজে (৩০ সেকেন্ড)। ওয়াক্তের আজান আগের মতোই অ্যালার্ম ভলিউমে বাজবে।</p></div>';
  }

  W.addEventListener('pt:premium', function () { if (T.current() === 'azanvoice') ui.rerender(); });

  T.register('azanvoice', {
    title: 'আজানের কণ্ঠ', sub: 'ওয়াক্তের আজানে নিজের পছন্দের কণ্ঠ', icon: 'volume', group: 'premium', order: 20, premium: true,
    hub: { t: 'নিজের পছন্দের আজান', s: 'প্রিয় মুয়াজ্জিনের আজান বেছে নিন — ওয়াক্তে সেটিই বাজবে' },
    render: function (el) { render(el); },
    onEvent: function (kind, name, v) {
      var n = N();
      if (kind !== 'act') return;
      if (name === 'premium') { if (W.ptOpenPremium) W.ptOpenPremium('azan'); return; }
      if (!n) return;
      if (name === 'play') {
        if (S.playing === v) { try { n.stopPreview(); } catch (e) {} S.playing = ''; }
        else { try { n.preview(v); S.playing = v; } catch (e) {} }
        ui.rerender();
      } else if (name === 'pick' && !S.busy) {
        var id = 'a' + (++seq); S.busy = true; ui.rerender();
        wait[id] = function (r) {
          S.busy = false;
          if (r.ok) { ui.haptic('success'); ui.toast('নতুন আজান যোগ হয়েছে — ওয়াক্তে এটিই বাজবে', { type: 'success' }); }
          else if (r.code !== 'cancel') ui.toast(ERR[r.code] || ERR.read, { type: 'danger' });
          if (T.current() === 'azanvoice') ui.rerender();
        };
        try { n.pick(id); } catch (e) { delete wait[id]; S.busy = false; ui.rerender(); }
      } else if (name === 'reset') {
        try { n.reset(); } catch (e) {}
        S.playing = ''; ui.toast('অ্যাপের নিজের আজানে ফেরানো হয়েছে', {}); ui.rerender();
      }
    }
  });
})();
