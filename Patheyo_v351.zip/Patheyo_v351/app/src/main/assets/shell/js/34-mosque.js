/* =============================================================================
   v350: কাছের মসজিদ (tool:mosque)
   • অবস্থান: ফোনের GPS (চাইলে) — না পেলে নামাজের সময়ের জন্য রাখা শহর/অবস্থান (lastKnownPrayerData)।
   • মসজিদের তালিকা: OpenStreetMap (amenity=place_of_worship + religion=muslim) — Overpass API, দুটি সার্ভার (একটি না পেলে অন্যটি)।
     ডেটা © OpenStreetMap contributors (ODbL) — পেজে উল্লেখ আছে।
   • মানচিত্র: নিজস্ব হালকা "রাডার" (SVG) — কোনো ম্যাপ-লাইব্রেরি/টাইল নয়, তাই দ্রুত ও সব ফোনে মসৃণ। উত্তর উপরে।
     "পথ দেখুন" চাপলে ফোনের ম্যাপ অ্যাপে (Google Maps) হাঁটার পথ খোলে।
   গোপনীয়তা: অবস্থান শুধু "খুঁজুন" চাপলে, ~১০০ মিটার পর্যন্ত গোল করে (৩ দশমিক) পাঠানো হয়; অ্যাপ কোথাও জমা রাখে না।
     শেষ ফল ফোনেই থাকে (pt_mosque_last — "ptu_" নয়, তাই ক্লাউডে যায় না)।
   নিরাপত্তা: মসজিদের নাম/ঠিকানা বাইরের লেখা → esc()। লিংক শুধু https://www.google.com/maps/… (সংখ্যা যাচাই করে)।
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic, esc = ui.esc;
  var EP = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter'];
  var PREF = 'ptu_mosque_pref', LAST = 'pt_mosque_last';
  var S = { busy: false, err: '', sel: -1 };

  function pref() { var o = ui.get(PREF, null) || {}; return { r: [1000, 2000, 5000].indexOf(+o.r) >= 0 ? +o.r : 2000 }; }
  function last() { var o = ui.get(LAST, null); return o && o.v === 1 && Array.isArray(o.list) ? o : null; }
  function savedPlace() {
    try { var c = JSON.parse(localStorage.getItem('lastKnownPrayerData') || 'null'); if (c && isFinite(+c.lat) && isFinite(+c.lng) && (c.lat || c.lng)) return { lat: +c.lat, lng: +c.lng, name: String(c.locationName || '').replace(/<[^>]*>/g, '').trim().slice(0, 60) || 'সংরক্ষিত অবস্থান', gps: false }; } catch (e) {}
    return null;
  }
  function r3(x) { return Math.round(x * 1000) / 1000; }
  function dist(a, b, c, d) {
    var R = 6371000, t = Math.PI / 180, dl = (c - a) * t, dn = (d - b) * t;
    var h = Math.sin(dl / 2) * Math.sin(dl / 2) + Math.cos(a * t) * Math.cos(c * t) * Math.sin(dn / 2) * Math.sin(dn / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }
  function bearing(a, b, c, d) {
    var t = Math.PI / 180, y = Math.sin((d - b) * t) * Math.cos(c * t), x = Math.cos(a * t) * Math.sin(c * t) - Math.sin(a * t) * Math.cos(c * t) * Math.cos((d - b) * t);
    return (Math.atan2(y, x) / t + 360) % 360;
  }
  var DIRS = ['উত্তর', 'উত্তর-পূর্ব', 'পূর্ব', 'দক্ষিণ-পূর্ব', 'দক্ষিণ', 'দক্ষিণ-পশ্চিম', 'পশ্চিম', 'উত্তর-পশ্চিম'];
  function dirName(b) { return DIRS[Math.round(b / 45) % 8]; }
  function fmtD(m) { return m < 1000 ? bn(Math.round(m / 10) * 10) + ' মিটার' : bn((m / 1000).toFixed(m < 10000 ? 1 : 0)) + ' কিমি'; }
  function walk(m) { var min = Math.max(1, Math.round(m * 1.3 / 80)); return min < 60 ? 'হেঁটে ~' + bn(min) + ' মিনিট' : ''; }

  function query(lat, lng, r) {
    var q = '[out:json][timeout:25];(node["amenity"="place_of_worship"]["religion"="muslim"](around:' + r + ',' + lat + ',' + lng + ');' +
      'way["amenity"="place_of_worship"]["religion"="muslim"](around:' + r + ',' + lat + ',' + lng + ');' +
      'relation["amenity"="place_of_worship"]["religion"="muslim"](around:' + r + ',' + lat + ',' + lng + '););out center tags 150;';
    function one(i) {
      var ctl = W.AbortController ? new AbortController() : null, to = setTimeout(function () { try { ctl && ctl.abort(); } catch (e) {} }, 20000);
      return fetch(EP[i], { method: 'POST', body: 'data=' + encodeURIComponent(q), headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, credentials: 'omit', referrerPolicy: 'no-referrer', signal: ctl ? ctl.signal : undefined })
        .then(function (res) { clearTimeout(to); if (!res.ok) throw new Error('http ' + res.status); return res.json(); })
        .catch(function (e) { clearTimeout(to); if (i + 1 < EP.length) return one(i + 1); throw e; });
    }
    return one(0).then(function (j) {
      var seen = {};
      return ((j && j.elements) || []).map(function (e) {
        var la = +(e.lat != null ? e.lat : e.center && e.center.lat), lo = +(e.lon != null ? e.lon : e.center && e.center.lon);
        if (!isFinite(la) || !isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) return null;
        var t = e.tags || {};
        var name = String(t['name:bn'] || t.name || t['name:en'] || '').trim().slice(0, 80);
        var addr = [t['addr:housenumber'], t['addr:street'], t['addr:suburb'] || t['addr:city']].filter(Boolean).join(', ').slice(0, 100);
        var d = dist(lat, lng, la, lo);
        return { n: name, a: addr, la: la, lo: lo, d: d, b: bearing(lat, lng, la, lo), j: /^(yes|true)$/i.test(t['friday_prayer'] || '') || /jame|jami|জামে/i.test(name) };
      }).filter(function (x) {
        if (!x) return false;
        var k = x.la.toFixed(4) + ',' + x.lo.toFixed(4); if (seen[k]) return false; seen[k] = 1; return true;
      }).sort(function (a, b) { return a.d - b.d; }).slice(0, 80);
    });
  }

  function search(useGps) {
    if (S.busy) return;
    var r = pref().r;
    function go(p) {
      var lat = r3(p.lat), lng = r3(p.lng);
      S.busy = true; S.err = ''; S.sel = -1; ui.rerender();
      query(lat, lng, r).then(function (list) {
        ui.set(LAST, { v: 1, at: Date.now(), lat: lat, lng: lng, name: p.name, gps: !!p.gps, r: r, list: list });
        S.busy = false; if (T.current() === 'mosque') ui.rerender();
        if (!list.length) ui.toast('এই দূরত্বে কোনো মসজিদ পাওয়া যায়নি — দূরত্ব বাড়িয়ে দেখুন', {});
      }, function () {
        S.busy = false; S.err = navigator.onLine === false ? 'ইন্টারনেট সংযোগ নেই।' : 'মানচিত্রের সার্ভারে পৌঁছানো যায়নি। একটু পরে আবার চেষ্টা করুন।';
        if (T.current() === 'mosque') ui.rerender();
      });
    }
    if (useGps && navigator.geolocation) {
      S.busy = true; S.err = ''; ui.rerender();
      navigator.geolocation.getCurrentPosition(function (p) {
        S.busy = false; go({ lat: p.coords.latitude, lng: p.coords.longitude, name: 'আপনার এখনকার অবস্থান', gps: true });
      }, function () {
        S.busy = false;
        var sp = savedPlace();
        ui.toast(sp ? 'ফোনের লোকেশন পাওয়া যায়নি — সংরক্ষিত অবস্থান থেকে খোঁজা হচ্ছে' : 'ফোনের লোকেশন পাওয়া যায়নি — লোকেশন চালু করে আবার চেষ্টা করুন', {});
        try { var b = W.AndroidWidgetBridge; if (b && b.requestLocationPermission && !sp) b.requestLocationPermission(); } catch (e) {}
        if (sp) go(sp); else ui.rerender();
      }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 120000 });
      return;
    }
    var sp = savedPlace();
    if (sp) go(sp); else search(true);
  }

  function mapsLink(m) {
    var la = +m.la, lo = +m.lo; if (!isFinite(la) || !isFinite(lo)) return '#';
    return 'https://www.google.com/maps/dir/?api=1&travelmode=walking&destination=' + la.toFixed(6) + ',' + lo.toFixed(6);
  }

  function radar(L) {
    var R = L.r, list = L.list, sz = 300, c = sz / 2, k = (c - 16) / R;
    var rings = [0.25, 0.5, 0.75, 1].map(function (f) { return '<circle cx="' + c + '" cy="' + c + '" r="' + ((c - 16) * f).toFixed(1) + '" class="ms-ring"/>'; }).join('');
    var lbl = '<text x="' + (c + 4) + '" y="' + (16 + 12) + '" class="ms-rl">' + fmtD(R) + '</text><text x="' + (c + 4) + '" y="' + (c - (c - 16) / 2 + 12) + '" class="ms-rl">' + fmtD(R / 2) + '</text>';
    var dots = list.map(function (m, i) {
      var rr = Math.min(m.d, R) * k, a = m.b * Math.PI / 180, x = c + rr * Math.sin(a), y = c - rr * Math.cos(a);
      return '<g class="ms-dot' + (i === S.sel ? ' is-on' : '') + (i === 0 ? ' is-near' : '') + '" data-act="sel" data-v="' + i + '" transform="translate(' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"><circle r="14" class="ms-hit"/><circle r="' + (i === S.sel ? 8 : 6) + '"/></g>';
    }).reverse().join('');
    return '<svg class="ms-radar" viewBox="0 0 ' + sz + ' ' + sz + '" role="img" aria-label="আশেপাশের মসজিদের মানচিত্র">' + rings +
      '<line x1="' + c + '" y1="10" x2="' + c + '" y2="' + (sz - 10) + '" class="ms-ax"/><line x1="10" y1="' + c + '" x2="' + (sz - 10) + '" y2="' + c + '" class="ms-ax"/>' +
      '<text x="' + c + '" y="11" class="ms-n">উ</text>' + lbl + dots +
      '<g transform="translate(' + c + ' ' + c + ')" class="ms-me"><circle r="16" class="ms-pulse"/><circle r="7"/></g></svg>';
  }

  function render(el) {
    var p = pref(), L = last(), sp = savedPlace();
    var head = ui.card({ icon: 'mosque', title: 'আশেপাশের মসজিদ', sub: L ? esc(L.name) + ' থেকে · ' + bn(L.list.length) + 'টি পাওয়া গেছে' : 'আপনার অবস্থান থেকে কাছের মসজিদ ও দূরত্ব',
      body: '<div class="tk-lbl tk-lbl--sm">কত দূর পর্যন্ত?</div>' + ui.chips('r', [[1000, '১ কিমি'], [2000, '২ কিমি'], [5000, '৫ কিমি']], p.r) +
        '<div class="ms-btns"><button type="button" class="pt-btn pt-btn--primary" data-act="gps"' + (S.busy ? ' disabled' : '') + '>' + ic('location') + 'এখনকার অবস্থান থেকে খুঁজুন</button>' +
        (sp ? '<button type="button" class="pt-btn pt-btn--ghost" data-act="saved"' + (S.busy ? ' disabled' : '') + '>' + ic('home') + esc(sp.name) + ' থেকে</button>' : '') + '</div>' });
    var mid = '';
    if (S.busy) mid = '<div class="tk-card pt-card hz-load"><span class="pt-spinner"></span><p class="tk-p">মসজিদ খোঁজা হচ্ছে…</p></div>';
    else if (S.err) mid = ui.notice('warning', 'খোঁজা যায়নি', esc(S.err), '<button type="button" class="pt-btn pt-btn--ghost pt-btn--sm" data-act="' + (L && L.gps ? 'gps' : 'saved') + '">' + ic('refresh') + 'আবার চেষ্টা</button>');
    if (!S.busy && L && L.list.length) {
      mid += '<section class="tk-card pt-card ms-map">' + radar(L) + '<div class="ms-leg"><span><i class="ms-k ms-k--me"></i>আপনি</span><span><i class="ms-k ms-k--near"></i>সবচেয়ে কাছে</span><span><i class="ms-k"></i>মসজিদ</span></div></section>' +
        '<div class="ms-list">' + L.list.map(function (m, i) {
          return '<div class="tk-card pt-card ms-item' + (i === S.sel ? ' is-on' : '') + '" data-i="' + i + '"><span class="pt-numbadge">' + bn(i + 1) + '</span>' +
            '<div class="ms-tx" data-act="sel" data-v="' + i + '"><b>' + (m.n ? esc(m.n) : 'মসজিদ (নাম উল্লেখ নেই)') + (m.j ? ' <span class="pt-chip ms-j">জামে</span>' : '') + '</b>' +
            '<small>' + fmtD(m.d) + ' · ' + dirName(m.b) + ' দিকে' + (walk(m.d) ? ' · ' + walk(m.d) : '') + '</small>' + (m.a ? '<small class="ms-ad">' + esc(m.a) + '</small>' : '') + '</div>' +
            '<a class="pt-btn pt-btn--tonal pt-btn--sm ms-go" href="' + mapsLink(m) + '" rel="noopener noreferrer" target="_blank">' + ic('external') + 'পথ</a></div>';
        }).join('') + '</div>';
    } else if (!S.busy && !S.err && L && !L.list.length) {
      mid += ui.notice('', 'কোনো মসজিদ পাওয়া যায়নি', 'এই দূরত্বের মধ্যে মানচিত্রে কোনো মসজিদ চিহ্নিত নেই। দূরত্ব বাড়িয়ে আবার খুঁজুন।');
    } else if (!S.busy && !S.err && !L) {
      mid += '<div class="tk-card pt-card ms-empty">' + ic('mosque') + '<p class="tk-p">উপরের বোতাম চাপুন — আপনার আশেপাশের মসজিদ দূরত্বসহ এখানে দেখাবে।</p></div>';
    }
    el.innerHTML = '<div class="tk-wrap">' + head + mid +
      '<p class="tk-fine">' + ic('info') + 'মসজিদের তথ্য: © OpenStreetMap contributors (স্বেচ্ছাসেবীদের তৈরি মানচিত্র) — কিছু মসজিদ বাদ পড়তে পারে বা নাম না থাকতে পারে। খুঁজতে আপনার আনুমানিক অবস্থান (প্রায় ১০০ মিটার পর্যন্ত গোল করে) শুধু ঐ সার্ভারে যায়; অ্যাপ কোথাও জমা রাখে না।' +
      (L ? ' শেষ খোঁজা: ' + ui.dateBn(new Date(L.at)) + '।' : '') + '</p></div>';
  }

  T.register('mosque', {
    title: 'কাছের মসজিদ', sub: 'দূরত্ব, দিক ও হেঁটে যাওয়ার পথ', icon: 'mosque', group: 'prayer', order: 30,
    hub: { t: 'কাছের মসজিদ', s: 'আশেপাশের মসজিদ মানচিত্রে, দূরত্ব ও পথসহ' },
    render: function (el) { render(el); },
    onEvent: function (kind, name, v) {
      if (kind === 'chip' && name === 'r') { ui.set(PREF, { r: +v }); var L = last(); if (L) search(L.gps); else ui.rerender(); }
      else if (kind === 'act' && name === 'gps') search(true);
      else if (kind === 'act' && name === 'saved') search(false);
      else if (kind === 'act' && name === 'sel') {
        S.sel = +v; ui.rerender();
        var it = D.querySelector('#tool-body .ms-item[data-i="' + (+v) + '"]');
        if (it) it.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  });
})();
