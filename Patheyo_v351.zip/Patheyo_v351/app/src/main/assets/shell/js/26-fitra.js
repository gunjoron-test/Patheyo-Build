/* =============================================================================
   v348: সদকাতুল ফিতর ক্যালকুলেটর (tool:fitra)
   পরিমাণ (হানাফি মত, বাংলাদেশে প্রচলিত — ইসলামিক ফাউন্ডেশনের হিসাবের একই ভিত্তি):
     গম/আটা = অর্ধ সা’ ≈ ১ কেজি ৬৫০ গ্রাম · যব, খেজুর, কিসমিস, পনির = এক সা’ ≈ ৩ কেজি ৩০০ গ্রাম (জনপ্রতি)
   দাম ইন্টারনেট থেকে আনা হয় না (অফলাইন ও নির্ভুল থাকার জন্য) — ব্যবহারকারী আজকের বাজারদর বসান, মনে থাকে।
   ডেটা: ptu_fitra = { item, price:{wheat:…}, people } (ক্লাউডে যায়)
   ============================================================================= */
(function () {
  'use strict';
  var W = window, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic;
  var ITEMS = [
    { k: 'wheat', n: 'গম / আটা', kg: 1.65, w: 'অর্ধ সা’ — ১ কেজি ৬৫০ গ্রাম' },
    { k: 'barley', n: 'যব', kg: 3.3, w: 'এক সা’ — ৩ কেজি ৩০০ গ্রাম' },
    { k: 'dates', n: 'খেজুর', kg: 3.3, w: 'এক সা’ — ৩ কেজি ৩০০ গ্রাম' },
    { k: 'raisin', n: 'কিসমিস', kg: 3.3, w: 'এক সা’ — ৩ কেজি ৩০০ গ্রাম' },
    { k: 'cheese', n: 'পনির', kg: 3.3, w: 'এক সা’ — ৩ কেজি ৩০০ গ্রাম' }
  ];
  function load() { var o = ui.get('ptu_fitra', null) || {}; return { item: o.item || 'wheat', price: o.price || {}, people: +o.people || 1 }; }
  function save(o) { ui.set('ptu_fitra', o); }
  function num(v) { var n = parseFloat(ui.en(String(v || '')).replace(/[,\s৳]/g, '')); return isFinite(n) && n > 0 ? n : 0; }
  function taka(n) {
    n = Math.round(n || 0); var s = String(n), last = s.slice(-3), rest = s.slice(0, -3);
    if (rest) last = ',' + last; rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    return '৳' + bn(rest + last);
  }
  function itemOf(k) { return ITEMS.filter(function (x) { return x.k === k; })[0] || ITEMS[0]; }

  function render(el) {
    var o = load(), it = itemOf(o.item), price = num(o.price[it.k]);
    var per = price * it.kg, total = per * o.people;
    el.innerHTML = '<div class="tk-wrap">' +
      '<div class="tk-card pt-card ft-res">' +
        '<span class="ft-l">মোট ফিতরা</span><b class="ft-t" id="ft-total">' + (price ? taka(total) : '—') + '</b>' +
        '<span class="ft-s" id="ft-per">' + (price ? 'জনপ্রতি ' + taka(per) + ' × ' + bn(o.people) + ' জন' : 'নিচে আজকের দাম বসান') + '</span></div>' +
      ui.card({ icon: 'iftar', title: 'কোন খাদ্য দিয়ে হিসাব?', sub: it.w + ' জনপ্রতি',
        body: ui.chips('item', ITEMS.map(function (x) { return [x.k, x.n]; }), it.k) +
          '<label class="ft-in"><span>' + it.n + '-এর আজকের দাম (প্রতি কেজি)</span><span class="ft-box"><i>৳</i><input inputmode="decimal" autocomplete="off" data-in="price" placeholder="যেমন ' + (it.k === 'wheat' ? '৬০' : '৫০০') + '" value="' + (o.price[it.k] ? ui.esc(bn(o.price[it.k])) : '') + '"><em>/কেজি</em></span></label>' }) +
      ui.card({ icon: 'users', title: 'কতজনের ফিতরা?', sub: 'নিজের এবং যাদের দায়িত্ব আপনার (যেমন নাবালেগ সন্তান)',
        body: '<div class="ft-ppl"><button type="button" class="pt-iconbtn" data-act="ppl" data-v="-1" aria-label="কমান">' + ic('minus') + '</button><b>' + bn(o.people) + ' জন</b><button type="button" class="pt-iconbtn" data-act="ppl" data-v="1" aria-label="বাড়ান">' + ic('plus') + '</button></div>' }) +
      '<div class="pt-card tk-card"><ul class="tk-ul">' +
        '<li>ঈদের দিন সুবহে সাদিকের সময় যার কাছে নিসাব পরিমাণ সম্পদ (প্রয়োজনের অতিরিক্ত) থাকে, তার ওপর ফিতরা ওয়াজিব (হানাফি মত)।</li>' +
        '<li>নিজের ও নাবালেগ সন্তানের পক্ষ থেকে আদায় করতে হয়।</li>' +
        '<li>ঈদের নামাজের আগে আদায় করা সুন্নত; রমজানের মধ্যেই দিয়ে দেওয়া উত্তম, যাতে গরিবরা ঈদের আগে পায়।</li>' +
        '<li>সামর্থ্য থাকলে খেজুর বা কিসমিসের হিসাবে (বেশি মূল্যে) দেওয়া উত্তম।</li>' +
        '<li>ফিতরা পাবেন যাকাত পাওয়ার যোগ্য গরিব-মিসকিন।</li></ul>' +
        '<p class="tk-fine">' + ic('info') + 'প্রতি বছর ইসলামিক ফাউন্ডেশন বাজারদর দেখে ফিতরার হার ঘোষণা করে — সেটির সাথে মিলিয়ে নিতে পারেন।</p></div></div>';
  }
  function paintResult() {
    var o = load(), it = itemOf(o.item), price = num(o.price[it.k]), per = price * it.kg;
    var t = document.getElementById('ft-total'), p = document.getElementById('ft-per');
    if (t) t.textContent = price ? taka(per * o.people) : '—';
    if (p) p.textContent = price ? 'জনপ্রতি ' + taka(per) + ' × ' + bn(o.people) + ' জন' : 'নিচে আজকের দাম বসান';
  }

  T.register('fitra', {
    title: 'ফিতরা ক্যালকুলেটর', sub: 'সদকাতুল ফিতরের হিসাব', icon: 'zakat', group: 'calc', order: 10,
    hub: { t: 'ফিতরা ক্যালকুলেটর', s: 'খাদ্য বাছাই, আজকের দাম ও পরিবারের সদস্য' },
    render: function (el) {
      render(el);
      var inp = el.querySelector('input[data-in="price"]');
      if (inp) inp.addEventListener('input', function () {                 /* লিখতে লিখতেই ফল — পুরো পেজ নতুন করে নয় (কীবোর্ড বন্ধ হয় না) */
        var o = load(); o.price[o.item] = num(inp.value) || ''; save(o); paintResult();
      });
    },
    onEvent: function (kind, name, v) {
      var o = load();
      if (kind === 'chip' && name === 'item') { o.item = v; save(o); ui.rerender(); }
      else if (kind === 'act' && name === 'ppl') { o.people = Math.max(1, Math.min(99, o.people + (+v))); save(o); ui.rerender(); }
    }
  });
})();
