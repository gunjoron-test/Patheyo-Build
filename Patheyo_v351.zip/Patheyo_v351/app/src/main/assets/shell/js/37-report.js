/* =============================================================================
   v350 (প্রিমিয়াম): বার্ষিক আমল রিপোর্ট (tool:report)
   বছরের পুরো ছবি এক পাতায় — শুধু ফোনে থাকা ইউজারের নিজের ডেটা থেকে (কিছুই কোথাও পাঠানো হয় না):
     নামাজ  — amol_report_state.days["YYYY-MM-DD"].{fajr,midday,asr,maghrib,isha} = jamaat|alone|qaza|missed
     কুরআন  — quran-khatm.{log:{date:page}, done:[{end}]}      তাসবিহ — tz3_hist["Y-M-D"].t
     রোজা   — ptu_fasting.{ram:{hijri:{day:'k'}}, nafl:{date:1}}  সকাল-সন্ধ্যার জিকির — ptu_adhkar_hist[date] = 'a'|'p'|'ap'
     হিফজ   — ptu_hifz.sura
   প্রিমিয়াম: নেটিভের যাচাই-করা অবস্থা (window.ptIsPremium() — PremiumBridge, সার্ভারের লেখা)। না থাকলে ছোট ঝলক + প্রিমিয়ামের বোতাম।
     (এটি শুধু ইউজারের নিজের পরিসংখ্যান দেখানো; কোনো ধর্মীয় বিষয় এর পেছনে আটকানো নয়।)
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic, esc = ui.esc;
  var FARD = [['fajr', 'ফজর'], ['midday', 'যোহর'], ['asr', 'আসর'], ['maghrib', 'মাগরিব'], ['isha', 'এশা']];
  var MON = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রি', 'মে', 'জুন', 'জুলা', 'আগ', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'];
  var year = 0;

  function J(k, def) { try { var v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? def : v; } catch (e) { return def; } }
  function premium() { try { return !!(W.ptIsPremium && W.ptIsPremium()); } catch (e) { return false; } }
  function pct(a, b) { return b ? Math.round(a / b * 100) : 0; }

  function years() {
    var ys = {}, now = new Date().getFullYear(); ys[now] = 1;
    var days = (J('amol_report_state', {}) || {}).days || {};
    Object.keys(days).forEach(function (k) { var y = +k.slice(0, 4); if (y > 2000 && y <= now) ys[y] = 1; });
    Object.keys(J('tz3_hist', {}) || {}).forEach(function (k) { var y = +String(k).slice(0, 4); if (y > 2000 && y <= now) ys[y] = 1; });
    return Object.keys(ys).map(Number).sort(function (a, b) { return b - a; });
  }

  function compute(Y) {
    var R = { pr: { jamaat: 0, alone: 0, qaza: 0, missed: 0 }, mon: [], waqt: {}, streak: 0, best: 0, fullDays: 0, activeDays: 0,
      khatm: 0, qDays: 0, tz: 0, tzDays: 0, ram: 0, nafl: 0, adh: 0, adhBoth: 0, hifz: 0 };
    for (var m = 0; m < 12; m++) R.mon.push({ jamaat: 0, alone: 0, qaza: 0, missed: 0 });
    FARD.forEach(function (f) { R.waqt[f[0]] = { ok: 0, all: 0 }; });
    var days = (J('amol_report_state', {}) || {}).days || {}, pre = Y + '-';
    var keys = Object.keys(days).filter(function (k) { return k.indexOf(pre) === 0; }).sort();
    var run = 0, prev = null;
    keys.forEach(function (k) {
      var r = days[k] || {}, mo = +k.slice(5, 7) - 1, full = true, any = false;
      FARD.forEach(function (f) {
        var v = r[f[0]];
        if (v === 'jamaat' || v === 'alone' || v === 'qaza' || v === 'missed') { R.pr[v]++; if (mo >= 0 && mo < 12) R.mon[mo][v]++; R.waqt[f[0]].all++; any = true; }
        if (v === 'jamaat' || v === 'alone') R.waqt[f[0]].ok++; else full = false;
      });
      if (any) R.activeDays++;
      var d = new Date(+k.slice(0, 4), mo, +k.slice(8, 10));
      if (full) { R.fullDays++; run = prev && (d - prev) <= 86400000 * 1.5 ? run + 1 : 1; prev = d; if (run > R.best) R.best = run; }
      else { run = 0; prev = null; }
    });
    R.streak = run;
    var kh = J('quran-khatm', null) || {};
    R.khatm = (kh.done || []).filter(function (x) { return x && String(x.end || '').indexOf(pre) === 0; }).length;
    R.qDays = Object.keys(kh.log || {}).filter(function (k) { return k.indexOf(pre) === 0; }).length;
    var tz = J('tz3_hist', {}) || {};
    Object.keys(tz).forEach(function (k) { if (String(k).indexOf(pre) === 0 && tz[k]) { R.tz += +tz[k].t || 0; if (+tz[k].t) R.tzDays++; } });
    var fs = J('ptu_fasting', {}) || {};
    Object.keys(fs.ram || {}).forEach(function (h) {      /* হিজরি বছরের রমজান কোন ইংরেজি বছরে পড়ে */
      var g = Math.floor(0.970224 * (+h) + 621.5643 + 0.69); if (g !== Y) return;
      var r = fs.ram[h] || {}; Object.keys(r).forEach(function (d) { if (r[d] === 'k') R.ram++; });
    });
    R.nafl = Object.keys(fs.nafl || {}).filter(function (k) { return k.indexOf(pre) === 0; }).length;
    var ah = J('ptu_adhkar_hist', {}) || {};
    Object.keys(ah).forEach(function (k) { if (k.indexOf(pre) === 0 && ah[k]) { R.adh++; if (String(ah[k]).indexOf('a') >= 0 && String(ah[k]).indexOf('p') >= 0) R.adhBoth++; } });
    var hz = (J('ptu_hifz', {}) || {}).sura || {};
    Object.keys(hz).forEach(function (s) { R.hifz += (hz[s] || []).length; });
    return R;
  }

  function bars(R) {
    var max = 1; R.mon.forEach(function (m) { max = Math.max(max, m.jamaat + m.alone + m.qaza + m.missed); });
    var w = 320, h = 150, bw = 18, gap = (w - 12 * bw) / 12, base = h - 22;
    var cols = R.mon.map(function (m, i) {
      var x = gap / 2 + i * (bw + gap), y = base, out = '';
      [['jamaat', 'rp-j'], ['alone', 'rp-a'], ['qaza', 'rp-q'], ['missed', 'rp-m']].forEach(function (s) {
        var v = m[s[0]]; if (!v) return; var hh = v / max * (base - 8); y -= hh;
        out += '<rect class="' + s[1] + '" x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + bw + '" height="' + Math.max(1, hh).toFixed(1) + '" rx="3"/>';
      });
      return out + '<text class="rp-ml" x="' + (x + bw / 2).toFixed(1) + '" y="' + (h - 6) + '">' + MON[i] + '</text>';
    }).join('');
    return '<svg class="rp-chart" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="মাসভিত্তিক নামাজ">' +
      '<line x1="0" x2="' + w + '" y1="' + base + '" y2="' + base + '" class="rp-base"/>' + cols + '</svg>' +
      '<div class="rp-leg"><span><i class="rp-j"></i>জামাতে</span><span><i class="rp-a"></i>একা</span><span><i class="rp-q"></i>কাজা</span><span><i class="rp-m"></i>পড়া হয়নি</span></div>';
  }

  function shareTxt(Y, R) {
    var on = R.pr.jamaat + R.pr.alone;
    return 'আমার ' + bn(Y) + ' সালের আমল — পাথেয়\n' +
      '• সময়মতো নামাজ: ' + bn(on) + ' ওয়াক্ত (জামাতে ' + bn(R.pr.jamaat) + ')\n' +
      '• পাঁচ ওয়াক্তই পূর্ণ: ' + bn(R.fullDays) + ' দিন · সেরা ধারাবাহিকতা ' + bn(R.best) + ' দিন\n' +
      (R.khatm ? '• কুরআন খতম: ' + bn(R.khatm) + ' বার\n' : '') + (R.tz ? '• তাসবিহ: ' + bn(R.tz) + ' বার\n' : '') +
      (R.ram + R.nafl ? '• রোজা: রমজানে ' + bn(R.ram) + ', নফল ' + bn(R.nafl) + '\n' : '') + 'আলহামদুলিল্লাহ। আল্লাহ কবুল করুন।';
  }

  function render(el) {
    var ys = years(); if (ys.indexOf(year) < 0) year = ys[0];
    var R = compute(year), on = R.pr.jamaat + R.pr.alone, all = on + R.pr.qaza + R.pr.missed;
    var hero = '<div class="tk-card pt-card rp-hero"><span class="rp-y">' + bn(year) + '</span><b>সালের আমল</b>' +
      '<div class="rp-big"><b>' + bn(pct(on, all)) + '%</b><small>নামাজ সময়মতো আদায়</small></div></div>';
    var chips = ys.length > 1 ? ui.chips('y', ys.map(function (y) { return [y, bn(y)]; }), year) : '';
    if (!premium()) {
      el.innerHTML = '<div class="tk-wrap">' + hero +
        '<div class="rp-lock-wrap"><div class="rp-blur" aria-hidden="true">' + ui.card({ icon: 'chart', title: 'মাসভিত্তিক নামাজ', body: bars(R) }) +
          '<div class="pt-stats tk-stats"><div class="pt-stat"><div class="pt-stat__value">' + bn(R.best) + '</div><div class="pt-stat__label">সেরা ধারাবাহিকতা</div></div><div class="pt-stat"><div class="pt-stat__value">' + bn(R.khatm) + '</div><div class="pt-stat__label">খতম</div></div><div class="pt-stat"><div class="pt-stat__value">' + bn(R.tz) + '</div><div class="pt-stat__label">তাসবিহ</div></div></div></div>' +
          '<div class="tk-card pt-card rp-lock"><span class="pt-medal tk-cm">' + ic('crown') + '</span><b>পুরো রিপোর্ট প্রিমিয়ামে</b>' +
            '<p class="tk-p">মাসভিত্তিক চার্ট, ওয়াক্তভিত্তিক হিসাব, ধারাবাহিকতা, কুরআন-খতম, তাসবিহ, রোজা ও জিকিরের বছরের পুরো ছবি — আর শেয়ার করার সুবিধা।</p>' +
            '<button type="button" class="pt-btn pt-btn--primary" data-act="premium">' + ic('crown') + 'প্রিমিয়াম দেখুন</button></div></div>' +
        '<p class="tk-fine">' + ic('lock') + 'রিপোর্ট তৈরি হয় শুধু আপনার ফোনের ডেটা থেকে — কোথাও পাঠানো হয় না।</p></div>';
      return;
    }
    var waqtRows = FARD.map(function (f) {
      var w = R.waqt[f[0]], p = pct(w.ok, w.all);
      return '<div class="rp-wr"><span>' + f[1] + '</span><div class="pt-progress"><div class="pt-progress__bar" style="width:' + p + '%"></div></div><b>' + bn(p) + '%</b></div>';
    }).join('');
    function stat(v, l) { return '<div class="pt-stat"><div class="pt-stat__value">' + v + '</div><div class="pt-stat__label">' + l + '</div></div>'; }
    el.innerHTML = '<div class="tk-wrap">' + chips + hero +
      '<div class="pt-stats tk-stats">' + stat(bn(R.pr.jamaat), 'জামাতে') + stat(bn(R.pr.alone), 'একা') + stat(bn(R.pr.qaza + R.pr.missed), 'কাজা/বাকি') + '</div>' +
      ui.card({ icon: 'chart', title: 'মাসভিত্তিক নামাজ', sub: 'কোন মাসে কেমন গেল', body: all ? bars(R) : ui.notice('', '', 'এই বছরে নামাজের কোনো হিসাব নেই। হোমের "আজকের নামাজ" থেকে প্রতিদিন চিহ্ন দিন।') }) +
      ui.card({ icon: 'mosque', title: 'ওয়াক্তভিত্তিক', sub: 'যে ওয়াক্তগুলোর হিসাব রাখা হয়েছে, তার কত ভাগ সময়মতো', body: '<div class="rp-waqt">' + waqtRows + '</div>' }) +
      ui.card({ icon: 'fire', title: 'ধারাবাহিকতা', body: '<div class="pt-stats tk-stats">' + stat(bn(R.fullDays), 'পাঁচ ওয়াক্ত পূর্ণ দিন') + stat(bn(R.best), 'সেরা টানা দিন') + stat(bn(R.streak), 'এখনকার টানা') + '</div>' }) +
      ui.card({ icon: 'quran', title: 'কুরআন ও জিকির', body: '<div class="pt-stats tk-stats rp-s4">' + stat(bn(R.khatm), 'কুরআন খতম') + stat(bn(R.qDays), 'খতম-প্ল্যানে পড়ার দিন') +
        stat(bn(R.tz), 'তাসবিহ গণনা') + stat(bn(R.adh), 'সকাল/সন্ধ্যার জিকিরের দিন') + stat(bn(R.ram), 'রমজানের রোজা') + stat(bn(R.nafl), 'নফল রোজা') + '</div>' +
        (R.hifz ? '<p class="tk-p">' + ic('star') + ' মোট মুখস্থ আয়াত (হিফজ মোড): <b>' + bn(R.hifz) + '</b></p>' : '') }) +
      '<button type="button" class="pt-btn pt-btn--tonal rp-share" data-act="share">' + ic('share') + 'রিপোর্ট শেয়ার করুন</button>' +
      '<p class="tk-fine">' + ic('lock') + 'রিপোর্ট তৈরি হয় শুধু আপনার ফোনের ডেটা থেকে — কোথাও পাঠানো হয় না। আমল আল্লাহর জন্য; এই হিসাব শুধু নিজেকে উৎসাহ দিতে, অহংকার বা দেখানোর জন্য নয়।</p></div>';
  }

  W.addEventListener('pt:premium', function () { if (T.current() === 'report') ui.rerender(); });

  T.register('report', {
    title: 'বার্ষিক আমল রিপোর্ট', sub: 'বছরের নামাজ, কুরআন, জিকির ও রোজার পুরো ছবি', icon: 'chart', group: 'premium', order: 10, premium: true,
    hub: { t: 'বার্ষিক আমল রিপোর্ট', s: 'মাসভিত্তিক চার্ট, ধারাবাহিকতা, খতম, তাসবিহ ও রোজা' },
    render: function (el) { render(el); },
    onEvent: function (kind, name, v) {
      if (kind === 'chip' && name === 'y') { year = +v; ui.rerender(); }
      else if (kind === 'act' && name === 'premium') { if (W.ptOpenPremium) W.ptOpenPremium('report'); }
      else if (kind === 'act' && name === 'share') {
        if (!premium()) return;
        var t = shareTxt(year, compute(year));
        try { if (W.PatheyoShare && W.PatheyoShare.shareText) { W.PatheyoShare.shareText(t); return; } } catch (e) {}
        try { if (navigator.share) navigator.share({ text: t }); else if (navigator.clipboard) navigator.clipboard.writeText(t).then(function () { ui.toast('কপি হয়েছে', { type: 'success' }); }); } catch (e) {}
      }
    }
  });
})();
