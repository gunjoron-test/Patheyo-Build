/* =============================================================================
   v348: মিরাস (উত্তরাধিকার / ফারায়েজ) ক্যালকুলেটর — tool:mirath · হানাফি মত
   যাদের ধরা হয়: স্বামী, স্ত্রী (১–৪), ছেলে, মেয়ে, বাবা, মা, আপন ভাই, আপন বোন।
   (দাদা-দাদি, নাতি-নাতনি, বৈমাত্রেয়/বৈপিত্রেয় ভাই-বোন, চাচা ইত্যাদি থাকলে হিসাব বদলায় — তখন মুফতির পরামর্শ, পেজেই বলা আছে।)
   নিয়ম (কুরআন: সূরা নিসা ১১, ১২, ১৭৬):
     স্বামী ১/২ (সন্তান নেই) · ১/৪ (সন্তান আছে) ║ স্ত্রী(রা) মিলে ১/৪ · ১/৮
     মেয়ে: ছেলে না থাকলে ১ জন ১/২, ২+ জন ২/৩; ছেলে থাকলে ছেলে:মেয়ে = ২:১ (আসাবা)
     মা: সন্তান বা ২+ ভাই-বোন থাকলে ১/৬, নইলে ১/৩; "উমারিয়্যাতান" (স্বামী/স্ত্রী + বাবা + মা, আর কেউ নয়) → বাকির ১/৩
     বাবা: ছেলে থাকলে ১/৬; শুধু মেয়ে থাকলে ১/৬ + বাকি; সন্তান না থাকলে বাকি (আসাবা)
     ভাই-বোন: ছেলে বা বাবা থাকলে বঞ্চিত। ভাই থাকলে ভাই:বোন = ২:১ (আসাবা)।
       শুধু বোন: মেয়ে না থাকলে ১ জন ১/২, ২+ জন ২/৩; মেয়ে থাকলে বোন বাকিটা পায় (আসাবা মা‘আল গাইর)
     আউল: নির্ধারিত অংশের যোগফল ১-এর বেশি হলে সবার অংশ আনুপাতিক কমে।
     রদ্দ: আসাবা না থাকলে বেঁচে যাওয়া অংশ স্বামী/স্ত্রী ছাড়া বাকি অংশীদারদের মাঝে অনুপাতে ফেরত;
           শুধু স্বামী/স্ত্রী থাকলে (আর কেউ নেই) পরবর্তী হানাফি ফকিহদের মতে তাকেই।
   সব হিসাব ভগ্নাংশে (পূর্ণসংখ্যা লব/হর) — দশমিকের ভুল নেই। window.PtMirath.compute() আলাদা করে পরীক্ষা করা যায়।
   ============================================================================= */
(function () {
  'use strict';
  var W = window;

  /* ---------- ভগ্নাংশ ---------- */
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = b; b = a % b; a = t; } return a || 1; }
  function F(n, d) { if (d < 0) { n = -n; d = -d; } var g = gcd(n, d); return { n: n / g, d: d / g }; }
  function add(a, b) { return F(a.n * b.d + b.n * a.d, a.d * b.d); }
  function sub(a, b) { return F(a.n * b.d - b.n * a.d, a.d * b.d); }
  function mul(a, b) { return F(a.n * b.n, a.d * b.d); }
  function div(a, b) { return F(a.n * b.d, a.d * b.n); }
  function cmp(a, b) { return a.n * b.d - b.n * a.d; }
  var ZERO = F(0, 1), ONE = F(1, 1);

  /* h = { husband:0|1, wives:0-4, sons, daughters, father:0|1, mother:0|1, brothers, sisters }
     ফেরত: { shares:[{key, label, count, frac(মোট), each(প্রত্যেকে), basis}], notes:[], residue:frac } */
  function compute(h) {
    h = h || {};
    var husband = h.husband ? 1 : 0, wives = Math.max(0, Math.min(4, h.wives | 0));
    if (husband) wives = 0;
    var sons = Math.max(0, h.sons | 0), daughters = Math.max(0, h.daughters | 0);
    var father = h.father ? 1 : 0, mother = h.mother ? 1 : 0;
    var brothers = Math.max(0, h.brothers | 0), sisters = Math.max(0, h.sisters | 0);
    var children = sons + daughters > 0, siblingsAll = brothers + sisters;
    var notes = [];
    var fixed = [];      /* {key, count, frac, basis} — নির্ধারিত অংশ (ফরজ) */
    var asaba = null;    /* {parts:[{key,count,weight}], basis} — বাকির দাবিদার */

    /* স্বামী/স্ত্রী */
    if (husband) fixed.push({ key: 'husband', count: 1, frac: children ? F(1, 4) : F(1, 2), basis: children ? 'সন্তান থাকায় ১/৪' : 'সন্তান না থাকায় ১/২', spouse: true });
    if (wives) fixed.push({ key: 'wife', count: wives, frac: children ? F(1, 8) : F(1, 4), basis: (children ? 'সন্তান থাকায় ১/৮' : 'সন্তান না থাকায় ১/৪') + (wives > 1 ? ' — সব স্ত্রী সমান ভাগে' : ''), spouse: true });

    /* মেয়ে / ছেলে */
    if (sons) asaba = { parts: [{ key: 'son', count: sons, weight: 2 }].concat(daughters ? [{ key: 'daughter', count: daughters, weight: 1 }] : []), basis: daughters ? 'ছেলে মেয়ের দ্বিগুণ (আসাবা)' : 'বাকি সবটা (আসাবা)' };
    else if (daughters) fixed.push({ key: 'daughter', count: daughters, frac: daughters === 1 ? F(1, 2) : F(2, 3), basis: daughters === 1 ? 'একমাত্র মেয়ে ১/২' : 'দুই বা বেশি মেয়ে মিলে ২/৩' });

    /* বাবা */
    var fatherResidue = false;
    if (father) {
      if (sons) fixed.push({ key: 'father', count: 1, frac: F(1, 6), basis: 'ছেলে থাকায় ১/৬' });
      else if (daughters) { fixed.push({ key: 'father', count: 1, frac: F(1, 6), basis: 'মেয়ে থাকায় ১/৬ + বাকি অংশ' }); fatherResidue = true; }
      else fatherResidue = true;
    }

    /* মা */
    var umariyya = mother && father && (husband || wives) && !children && siblingsAll < 2;
    if (mother && !umariyya) fixed.push({ key: 'mother', count: 1, frac: (children || siblingsAll >= 2) ? F(1, 6) : F(1, 3), basis: children ? 'সন্তান থাকায় ১/৬' : siblingsAll >= 2 ? 'দুই বা বেশি ভাই-বোন থাকায় ১/৬' : 'সন্তান ও একাধিক ভাই-বোন না থাকায় ১/৩' });

    /* ভাই-বোন */
    var sibBlocked = sons > 0 || father > 0;
    if (siblingsAll && sibBlocked) notes.push('ভাই-বোন ' + (sons ? 'ছেলে' : 'বাবা') + ' থাকায় এ ক্ষেত্রে অংশ পান না' + (mother && siblingsAll >= 2 ? ' — তবে তাঁদের কারণে মায়ের অংশ ১/৬ হয়েছে।' : '।'));
    var sisterAsaba = false;
    if (!sibBlocked && siblingsAll) {
      if (brothers) { if (!asaba) asaba = { parts: [{ key: 'brother', count: brothers, weight: 2 }].concat(sisters ? [{ key: 'sister', count: sisters, weight: 1 }] : []), basis: sisters ? 'ভাই বোনের দ্বিগুণ (আসাবা)' : 'বাকি সবটা (আসাবা)' }; }
      else if (daughters) sisterAsaba = true;                         /* মেয়ের সাথে বোন = আসাবা মা‘আল গাইর */
      else fixed.push({ key: 'sister', count: sisters, frac: sisters === 1 ? F(1, 2) : F(2, 3), basis: sisters === 1 ? 'একমাত্র বোন ১/২' : 'দুই বা বেশি বোন মিলে ২/৩' });
    }

    /* ---- নির্ধারিত অংশের যোগফল, উমারিয়্যা ---- */
    var sum = fixed.reduce(function (s, x) { return add(s, x.frac); }, ZERO);
    if (umariyya) {
      var rest = sub(ONE, sum), mf = mul(rest, F(1, 3));
      fixed.push({ key: 'mother', count: 1, frac: mf, basis: 'স্বামী/স্ত্রীর অংশ দেওয়ার পর বাকির ১/৩ (উমারিয়্যাতান)' });
      sum = add(sum, mf);
    }
    var shares = fixed.map(function (x) { return { key: x.key, count: x.count, frac: x.frac, basis: x.basis, spouse: !!x.spouse }; });

    /* ---- আউল ---- */
    if (cmp(sum, ONE) > 0) {
      notes.push('নির্ধারিত অংশের যোগফল ১-এর বেশি (' + sum.n + '/' + sum.d + ') — আউল: সবার অংশ আনুপাতিক হারে কমানো হয়েছে।');
      shares.forEach(function (s) { s.frac = div(s.frac, sum); });
      sum = ONE;
    }
    var residue = sub(ONE, sum);

    /* ---- বাকি অংশ: আসাবা → বাবা → বোন(মেয়ের সাথে) → রদ্দ ---- */
    if (cmp(residue, ZERO) > 0) {
      if (asaba) {
        var w = asaba.parts.reduce(function (s, p) { return s + p.count * p.weight; }, 0);
        asaba.parts.forEach(function (p) { shares.push({ key: p.key, count: p.count, frac: mul(residue, F(p.count * p.weight, w)), basis: asaba.basis }); });
        residue = ZERO;
      } else if (fatherResidue) {
        var fs = shares.filter(function (s) { return s.key === 'father'; })[0];
        if (fs) { fs.frac = add(fs.frac, residue); } else shares.push({ key: 'father', count: 1, frac: residue, basis: 'সন্তান না থাকায় বাকি সবটা (আসাবা)' });
        residue = ZERO;
      } else if (sisterAsaba) {
        shares.push({ key: 'sister', count: sisters, frac: residue, basis: 'মেয়ের সাথে বোন বাকিটা পান (আসাবা মা‘আল গাইর)' });
        residue = ZERO;
      } else {
        var nonSp = shares.filter(function (s) { return !s.spouse; });
        if (nonSp.length) {
          var spSum = shares.filter(function (s) { return s.spouse; }).reduce(function (a, s) { return add(a, s.frac); }, ZERO);
          var nsSum = nonSp.reduce(function (a, s) { return add(a, s.frac); }, ZERO);
          var pool = sub(ONE, spSum);
          nonSp.forEach(function (s) { s.frac = mul(pool, div(s.frac, nsSum)); });
          notes.push('আসাবা (বাকির দাবিদার) না থাকায় বেঁচে যাওয়া অংশ স্বামী/স্ত্রী ছাড়া অন্যদের মাঝে অনুপাতে ফেরত দেওয়া হয়েছে (রদ্দ)।');
          residue = ZERO;
        } else if (shares.length) {
          var sp = shares[0]; sp.frac = add(sp.frac, residue);
          notes.push('স্বামী/স্ত্রী ছাড়া আর কোনো ওয়ারিস না থাকায় বাকিটাও তাঁকে দেওয়া হয়েছে (পরবর্তী হানাফি ফকিহদের মত; বায়তুল মাল না থাকা অবস্থায়)।');
          residue = ZERO;
        }
      }
    }
    if (cmp(residue, ZERO) > 0 && !shares.length) notes.push('এখানে বাছাই করা কোনো ওয়ারিস নেই — দূরের আত্মীয়দের হিসাবের জন্য মুফতির পরামর্শ নিন।');

    /* একই key একত্র (যেমন বাবা = ১/৬ + বাকি) ও প্রত্যেকের অংশ */
    var merged = [];
    shares.forEach(function (s) {
      var m = merged.filter(function (x) { return x.key === s.key; })[0];
      if (m) { m.frac = add(m.frac, s.frac); m.basis = m.basis + '; ' + s.basis; } else merged.push({ key: s.key, count: s.count, frac: s.frac, basis: s.basis });
    });
    merged.forEach(function (s) { s.each = F(s.frac.n, s.frac.d * s.count); });
    return { shares: merged, notes: notes, residue: residue };
  }
  W.PtMirath = { compute: compute, F: F };

  /* ================================================================= UI */
  var T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic;
  var LABEL = { husband: 'স্বামী', wife: 'স্ত্রী', son: 'ছেলে', daughter: 'মেয়ে', father: 'বাবা', mother: 'মা', brother: 'আপন ভাই', sister: 'আপন বোন' };
  var KEY = 'ptu_mirath';
  function load() {
    var o = ui.get(KEY, null) || {};
    return { dec: o.dec === 'f' ? 'f' : 'm', wives: +o.wives || 1, husband: o.husband ? 1 : 0, sons: +o.sons || 0, daughters: +o.daughters || 0,
      father: o.father ? 1 : 0, mother: o.mother ? 1 : 0, brothers: +o.brothers || 0, sisters: +o.sisters || 0, spouse: o.spouse !== false, estate: o.estate || '', debt: o.debt || '', will: o.will || '' };
  }
  function save(o) { ui.set(KEY, o); }
  function num(v) { var n = parseFloat(ui.en(String(v || '')).replace(/[,\s৳]/g, '')); return isFinite(n) && n > 0 ? n : 0; }
  function taka(n) {
    var neg = n < 0; n = Math.round(Math.abs(n || 0)); var s = String(n), last = s.slice(-3), rest = s.slice(0, -3);
    if (rest) last = ',' + last; rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    return (neg ? '−' : '') + '৳' + bn(rest + last);
  }
  function fr(f) { return f.n === 0 ? '০' : f.d === 1 ? bn(f.n) : bn(f.n) + '/' + bn(f.d); }
  function pct(f) { return bn((Math.round(f.n / f.d * 10000) / 100).toString()); }
  function heirs(o) {
    return { husband: o.dec === 'f' && o.spouse ? 1 : 0, wives: o.dec === 'm' && o.spouse ? o.wives : 0, sons: o.sons, daughters: o.daughters,
      father: o.father, mother: o.mother, brothers: o.brothers, sisters: o.sisters };
  }
  function stepper(k, v, max, label, sub) {
    return ui.row(label, sub || '', '<span class="tk-step"><button type="button" class="pt-iconbtn" data-act="st" data-v="' + k + ':-1" aria-label="কমান">' + ic('minus') + '</button><b>' + bn(v) + '</b>' +
      '<button type="button" class="pt-iconbtn" data-act="st" data-v="' + k + ':1" aria-label="বাড়ান"' + (v >= max ? ' disabled' : '') + '>' + ic('plus') + '</button></span>');
  }
  function netEstate(o) { var e = num(o.estate) - num(o.debt); var wl = Math.min(num(o.will), Math.max(0, e) / 3); return { net: Math.max(0, e - wl), will: wl, over: num(o.will) > Math.max(0, e) / 3 }; }

  function resultHtml(o) {
    var r = compute(heirs(o)), est = netEstate(o);
    if (!r.shares.length) return ui.notice('', '', 'ওপরে ওয়ারিসদের বাছাই করুন — সাথে সাথে ভাগ দেখাবে।');
    return '<div class="mr-res">' + r.shares.map(function (s) {
      return '<div class="mr-r"><div class="mr-rh"><b>' + LABEL[s.key] + (s.count > 1 ? ' (' + bn(s.count) + ' জন)' : '') + '</b><span class="mr-f">' + fr(s.frac) + '<small>' + pct(s.frac) + '%</small></span></div>' +
        '<div class="pt-progress mr-pg"><div class="pt-progress__fill" style="width:' + (s.frac.n / s.frac.d * 100) + '%"></div></div>' +
        '<small class="mr-b">' + s.basis + (s.count > 1 ? ' · প্রত্যেকে ' + fr(s.each) : '') + '</small>' +
        (est.net ? '<div class="mr-amt"><b>' + taka(est.net * s.frac.n / s.frac.d) + '</b>' + (s.count > 1 ? '<span>প্রত্যেকে ' + taka(est.net * s.each.n / s.each.d) + '</span>' : '') + '</div>' : '') + '</div>';
    }).join('') + '</div>' + r.notes.map(function (n) { return ui.notice('', '', n); }).join('');
  }

  function render(el) {
    var o = load(), est = netEstate(o);
    el.innerHTML = '<div class="tk-wrap">' +
      ui.card({ icon: 'user', title: 'মৃত ব্যক্তি', body: ui.seg('dec', [['m', 'পুরুষ'], ['f', 'নারী']], o.dec) +
        ui.row(o.dec === 'm' ? 'স্ত্রী জীবিত আছেন' : 'স্বামী জীবিত আছেন', '', ui.sw('spouse', o.spouse, 'স্বামী/স্ত্রী')) +
        (o.dec === 'm' && o.spouse ? stepper('wives', o.wives, 4, 'কতজন স্ত্রী', 'সবাই মিলে একই অংশ সমান ভাগে') : '') }) +
      ui.card({ icon: 'users', title: 'জীবিত ওয়ারিস', sub: 'মৃত্যুর সময় যাঁরা জীবিত ছিলেন',
        body: stepper('sons', o.sons, 20, 'ছেলে') + stepper('daughters', o.daughters, 20, 'মেয়ে') +
          ui.row('বাবা', '', ui.sw('father', !!o.father, 'বাবা')) + ui.row('মা', '', ui.sw('mother', !!o.mother, 'মা')) +
          stepper('brothers', o.brothers, 20, 'আপন ভাই', 'একই বাবা-মা') + stepper('sisters', o.sisters, 20, 'আপন বোন', 'একই বাবা-মা') }) +
      ui.card({ icon: 'wallet', title: 'সম্পদ (ঐচ্ছিক)', sub: 'দিলে টাকার অঙ্কেও ভাগ দেখাবে',
        body: '<label class="ft-in"><span>মোট সম্পদ</span><span class="ft-box"><i>৳</i><input inputmode="decimal" data-in="estate" placeholder="০" value="' + ui.esc(o.estate ? bn(o.estate) : '') + '"></span></label>' +
          '<label class="ft-in"><span>ঋণ ও দাফন-কাফনের খরচ</span><span class="ft-box"><i>৳</i><input inputmode="decimal" data-in="debt" placeholder="০" value="' + ui.esc(o.debt ? bn(o.debt) : '') + '"></span></label>' +
          '<label class="ft-in"><span>অসিয়ত (ওয়ারিস নন এমন কাউকে — সর্বোচ্চ ১/৩)</span><span class="ft-box"><i>৳</i><input inputmode="decimal" data-in="will" placeholder="০" value="' + ui.esc(o.will ? bn(o.will) : '') + '"></span></label>' +
          '<div class="mr-net" id="mr-net">' + (est.net ? 'ভাগ হবে: <b>' + taka(est.net) + '</b>' + (est.over ? ' · অসিয়ত ১/৩-এ সীমিত' : '') : '') + '</div>' }) +
      '<div class="pt-section tk-sec-h"><span class="pt-section__title">কে কত পাবেন</span><span class="pt-section__line"></span></div>' +
      '<div class="tk-card pt-card" id="mr-out">' + resultHtml(o) + '</div>' +
      ui.notice('warning', 'গুরুত্বপূর্ণ', 'এটি সাধারণ ক্ষেত্রের হিসাব (হানাফি মত)। দাদা-দাদি, নাতি-নাতনি, সৎ ভাই-বোন, চাচা ইত্যাদি থাকলে, বা কোনো ওয়ারিস হত্যাকারী/ভিন্ন ধর্মের হলে হিসাব বদলায় — চূড়ান্ত বণ্টনের আগে মুফতির কাছে যাচাই করুন।') +
      '<p class="tk-fine">' + ic('book') + 'ভিত্তি: সূরা নিসা ১১, ১২ ও ১৭৬। ভাগের আগে: দাফন-কাফন → ঋণ → অসিয়ত (১/৩ পর্যন্ত) → বাকিটা ওয়ারিসদের।</p></div>';
  }
  function paint() {
    var o = load(), est = netEstate(o), out = document.getElementById('mr-out'), nt = document.getElementById('mr-net');
    if (out) { out.innerHTML = resultHtml(o); if (W.PT && PT.hydrateIcons) PT.hydrateIcons(out); }
    if (nt) nt.innerHTML = est.net ? 'ভাগ হবে: <b>' + taka(est.net) + '</b>' + (est.over ? ' · অসিয়ত ১/৩-এ সীমিত' : '') : '';
  }

  T.register('mirath', {
    title: 'মিরাস ক্যালকুলেটর', sub: 'উত্তরাধিকার (ফারায়েজ) — হানাফি মত', icon: 'scroll', group: 'calc', order: 20,
    hub: { t: 'মিরাস ক্যালকুলেটর', s: 'কে কত অংশ পাবেন — ভগ্নাংশ ও টাকায়' },
    render: function (el) {
      render(el);
      [].forEach.call(el.querySelectorAll('input[data-in]'), function (inp) {
        inp.addEventListener('input', function () { var o = load(); o[inp.getAttribute('data-in')] = num(inp.value) || ''; save(o); paint(); });
      });
    },
    onEvent: function (kind, name, v) {
      var o = load();
      if (kind === 'seg' && name === 'dec') { o.dec = v; save(o); ui.rerender(); }
      else if (kind === 'sw') { o[name] = name === 'spouse' ? v : (v ? 1 : 0); save(o); ui.rerender(); }
      else if (kind === 'act' && name === 'st') {
        var p = String(v).split(':'), k = p[0], max = k === 'wives' ? 4 : 20, min = k === 'wives' ? 1 : 0;
        o[k] = Math.max(min, Math.min(max, (+o[k] || 0) + (+p[1]))); save(o); ui.rerender();
      }
    }
  });
})();
