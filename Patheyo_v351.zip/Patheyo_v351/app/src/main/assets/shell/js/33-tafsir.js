/* =============================================================================
   v350: তাফসির ও শব্দে শব্দে অর্থ (tool:tafsir)
   • আয়াতের আরবি লেখা: অ্যাপের নিজের কুরআন (QuranApp.quranModel) — হিফজ মোডের একই উৎস।
   • শব্দে শব্দে বাংলা অর্থ ও উচ্চারণ, আর বাংলা তাফসির: Quran.com-এর পাবলিক API (Quran Foundation)।
       তাফসির: আহসানুল বায়ান (id 165) · ড. আবু বকর জাকারিয়া (166, বাদশাহ ফাহাদ কুরআন মুদ্রণ কমপ্লেক্স) ·
               ইবনে কাসীর (164, তাওহীদ পাবলিকেশন্স) · ফাতহুল মাজীদ (381)
     যতটুকু পড়া হয় শুধু ততটুকুই নামে; শব্দার্থ ফোনে ছোট ক্যাশে থাকে (pt_tf_wbw — ক্লাউডে যায় না)।
   • খোলা: __ptGo('tool:tafsir') · arg "সূরা:আয়াত" দিলে সরাসরি সেই আয়াত (যেমন PTTools.open('tafsir', null, '2:255'))।
   নিরাপত্তা (SECURITY_RULES.md §৪): তাফসিরের HTML কখনো সরাসরি innerHTML নয় — DOMParser-এ (নিষ্ক্রিয় ডকুমেন্ট) পড়ে
   শুধু অনুমোদিত ট্যাগ (p, br, b, i, h4, ul/ol/li, sup, blockquote) নতুন করে বানানো হয়, কোনো অ্যাট্রিবিউট/লিংক/স্ক্রিপ্ট নয়;
   লেখা যায় textContent দিয়ে। শব্দার্থও esc() দিয়ে। URL সবসময় https://।
   ডেটা: ptu_tafsir = { s, a, tab, book } (শেষ জায়গা — ক্লাউডে যায়)
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic, esc = ui.esc;
  var API = 'https://api.quran.com/api/v4/';
  var KEY = 'ptu_tafsir', WBW_KEY = 'pt_tf_wbw', WBW_MAX = 160;
  var BOOKS = [
    [165, 'আহসানুল বায়ান', 'তাফসীর আহসানুল বায়ান — হাফেয সালাহুদ্দীন ইউসুফ'],
    [166, 'আবু বকর জাকারিয়া', 'তাফসীর — ড. আবু বকর মুহাম্মাদ যাকারিয়া (বাদশাহ ফাহাদ কুরআন মুদ্রণ কমপ্লেক্স)'],
    [164, 'ইবনে কাসীর', 'তাফসীর ইবনে কাসীর (সংক্ষেপিত) — তাওহীদ পাবলিকেশন্স'],
    [381, 'ফাতহুল মাজীদ', 'তাফসীর ফাতহুল মাজীদ']
  ];
  function bookOf(id) { return BOOKS.filter(function (b) { return b[0] === +id; })[0] || BOOKS[0]; }

  function Q() { try { var w = W.__ptPages && W.__ptPages.frameWin('f1'); var A = w && w.QuranApp; return A && A.quranModel && A.quranModel.length === 114 ? A : null; } catch (e) { return null; } }
  function data() { var o = ui.get(KEY, null) || {}; return { s: +o.s || 1, a: +o.a || 1, tab: o.tab === 'tf' ? 'tf' : 'wbw', book: bookOf(o.book)[0] }; }
  function save(o) { ui.set(KEY, o); }

  /* ---------- নেটওয়ার্ক + ক্যাশ ---------- */
  var mem = {}, inflight = {};
  function getJSON(url) {
    if (mem[url]) return Promise.resolve(mem[url]);
    if (inflight[url]) return inflight[url];
    var ctl = W.AbortController ? new AbortController() : null, to = setTimeout(function () { try { ctl && ctl.abort(); } catch (e) {} }, 15000);
    var p = fetch(url, { signal: ctl ? ctl.signal : undefined, credentials: 'omit', referrerPolicy: 'no-referrer' }).then(function (r) {
      if (!r.ok) throw new Error('http ' + r.status);
      return r.json();
    }).then(function (j) { clearTimeout(to); delete inflight[url]; mem[url] = j; return j; }, function (e) { clearTimeout(to); delete inflight[url]; throw e; });
    inflight[url] = p; return p;
  }
  function wbwCache() { var c = ui.get(WBW_KEY, null); return c && typeof c === 'object' && c.v === 1 ? c : { v: 1, k: [], d: {} }; }
  /* সূরা ফাতিহা: অ্যাপের গণনায় বিসমিল্লাহ আলাদা (আয়াত ১ = আলহামদু…, ৬ ও ৭ = Quran.com-এর ৭-এর দুই ভাগ) —
     Quran.com-এর (কুফি) গণনায় বিসমিল্লাহ ১ নম্বর আয়াত। হিফজ মোড ও কুরআন প্লেয়ারের একই নিয়ম। */
  function apiKey(s, a) { return s === 1 ? '1:' + (a <= 5 ? a + 1 : 7) : s + ':' + a; }
  function wbw(s, a) {
    var key = apiKey(s, a), c = wbwCache();
    if (c.d[key]) return Promise.resolve(c.d[key]);
    return getJSON(API + 'verses/by_key/' + key + '?words=true&language=bn&word_fields=text_uthmani').then(function (j) {
      var words = ((j && j.verse && j.verse.words) || []).filter(function (w) { return w && w.char_type_name === 'word'; }).map(function (w) {
        return [String(w.text_uthmani || w.text || '').slice(0, 60), String((w.translation && w.translation.text) || '').slice(0, 120), String((w.transliteration && w.transliteration.text) || '').slice(0, 60)];
      });
      if (!words.length) throw new Error('empty');
      try {
        var cc = wbwCache(); cc.d[key] = words; cc.k = cc.k.filter(function (x) { return x !== key; }); cc.k.push(key);
        while (cc.k.length > WBW_MAX) delete cc.d[cc.k.shift()];
        ui.set(WBW_KEY, cc);
      } catch (e) {}
      return words;
    });
  }
  function tafsir(book, s, a) {
    return getJSON(API + 'tafsirs/' + (+book) + '/by_ayah/' + apiKey(s, a)).then(function (j) {
      var t = j && j.tafsir; if (!t) throw new Error('empty');
      var keys = Object.keys(t.verses || {});
      return { html: String(t.text || ''), keys: keys };
    });
  }

  /* ---------- নিরাপদ HTML: শুধু অনুমোদিত ট্যাগ নতুন করে বানানো ---------- */
  var MAP = { P: 'p', DIV: 'p', BR: 'br', B: 'b', STRONG: 'b', I: 'i', EM: 'i', H1: 'h4', H2: 'h4', H3: 'h4', H4: 'h4', H5: 'h4', H6: 'h4', UL: 'ul', OL: 'ol', LI: 'li', SUP: 'sup', SUB: 'sub', BLOCKQUOTE: 'blockquote' };
  var SKIP = { SCRIPT: 1, STYLE: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, NOSCRIPT: 1, TEMPLATE: 1, SVG: 1, MATH: 1, IMG: 1, VIDEO: 1, AUDIO: 1, FORM: 1, INPUT: 1, BUTTON: 1, LINK: 1, META: 1 };
  function clean(html) {
    var out = D.createDocumentFragment(), src;
    try { src = new DOMParser().parseFromString('<body>' + html + '</body>', 'text/html').body; } catch (e) { var p = D.createElement('p'); p.textContent = String(html).replace(/<[^>]*>/g, ' '); out.appendChild(p); return out; }
    var budget = 6000;
    (function walk(from, to, depth) {
      for (var n = from.firstChild; n && budget > 0; n = n.nextSibling) {
        budget--;
        if (n.nodeType === 3) { to.appendChild(D.createTextNode(n.nodeValue)); continue; }
        if (n.nodeType !== 1 || SKIP[n.nodeName]) continue;
        var tag = MAP[n.nodeName];
        if (tag && depth < 12) { var e = D.createElement(tag); to.appendChild(e); if (tag !== 'br') walk(n, e, depth + 1); }
        else walk(n, to, depth + 1);              /* span, a, font … : শুধু ভেতরের লেখা */
      }
    })(src, out, 0);
    return out;
  }

  /* ---------- আঁকা ---------- */
  var req = 0;
  function render(el, arg) {
    var A = Q(), o = data();
    if (arg && /^\d{1,3}:\d{1,3}$/.test(String(arg))) { var p = String(arg).split(':'); o.s = +p[0]; o.a = +p[1]; save(o); ui.consumeArg(); }
    if (!A) {
      el.innerHTML = '<div class="tk-wrap"><div class="tk-card pt-card hz-load"><span class="pt-spinner"></span><p class="tk-p">কুরআনের লেখা প্রস্তুত হচ্ছে…</p></div></div>';
      try { W.__ptPages.load('f1'); } catch (e) {}
      var t0 = Date.now(), iv = setInterval(function () { if (Q() || Date.now() - t0 > 20000) { clearInterval(iv); if (T.current() === 'tafsir') ui.rerender(); } }, 400);
      return;
    }
    o.s = Math.max(1, Math.min(114, o.s));
    var sura = A.quranModel[o.s - 1], n = sura.ayahs.length; o.a = Math.max(1, Math.min(n, o.a));
    var name = (A.SURAH_BN && A.SURAH_BN[o.s - 1]) || '';
    var opts = A.quranModel.map(function (x, i) { return '<option value="' + (i + 1) + '"' + (i + 1 === o.s ? ' selected' : '') + '>' + bn(i + 1) + '. ' + esc((A.SURAH_BN || [])[i] || '') + '</option>'; }).join('');
    var bk = bookOf(o.book);
    el.innerHTML = '<div class="tk-wrap tf-wrap">' +
      ui.card({ icon: 'quran', title: 'কোন আয়াত?', body:
        '<label class="hz-sel"><span>সূরা</span><select data-in="sura">' + opts + '</select></label>' +
        '<div class="tf-nav"><button type="button" class="pt-iconbtn" data-act="go" data-v="-1" aria-label="আগের আয়াত">' + ic('prev') + '</button>' +
          '<label class="tf-ain"><span>আয়াত</span><input inputmode="numeric" data-in="ayah" value="' + bn(o.a) + '" aria-label="আয়াত নম্বর"><em>/ ' + bn(n) + '</em></label>' +
          '<button type="button" class="pt-iconbtn" data-act="go" data-v="1" aria-label="পরের আয়াত">' + ic('next') + '</button></div>' }) +
      '<section class="tk-card pt-card tf-ayah"><div class="tf-ah"><span class="pt-chip">' + esc(name) + ' · ' + bn(o.s) + ':' + bn(o.a) + '</span>' +
        '<button type="button" class="tk-x" data-act="read" aria-label="কুরআনে খুলুন">' + ic('book') + '</button></div>' +
        '<p class="pt-ar tf-ar" dir="rtl" lang="ar">' + esc(sura.ayahs[o.a - 1].text) + '</p></section>' +
      ui.seg('tab', [['wbw', 'শব্দে শব্দে অর্থ'], ['tf', 'তাফসির']], o.tab) +
      (o.tab === 'tf' ? '<div class="tk-chips tf-books">' + BOOKS.map(function (b) { return '<button type="button" class="pt-chip tk-chip' + (b[0] === bk[0] ? ' is-on' : '') + '" data-chip="book" data-v="' + b[0] + '">' + b[1] + '</button>'; }).join('') + '</div>' : '') +
      '<div id="tf-out" class="tf-out" aria-live="polite"></div>' +
      '<div class="tf-pager"><button type="button" class="pt-btn pt-btn--ghost" data-act="go" data-v="-1"' + (o.s === 1 && o.a === 1 ? ' disabled' : '') + '>' + ic('prev') + 'আগের আয়াত</button>' +
        '<button type="button" class="pt-btn pt-btn--primary" data-act="go" data-v="1"' + (o.s === 114 && o.a === n ? ' disabled' : '') + '>পরের আয়াত' + ic('next') + '</button></div>' +
      '<p class="tk-fine">' + ic('info') + 'শব্দার্থ ও তাফসির: Quran.com (Quran Foundation)-এর উন্মুক্ত তথ্যভান্ডার' + (o.tab === 'tf' ? ' · ' + esc(bk[2]) : '') + '। ইন্টারনেট লাগে; একবার দেখা শব্দার্থ পরে অফলাইনেও দেখা যায়।</p></div>';
    var sel = el.querySelector('select[data-in="sura"]');
    if (sel) sel.addEventListener('change', function () { var d = data(); d.s = +sel.value; d.a = 1; save(d); ui.rerender(); el.scrollTop = 0; });
    var ain = el.querySelector('input[data-in="ayah"]');
    if (ain) ain.addEventListener('keydown', function (e) { if (e.key === 'Enter') ain.blur(); });
    load(o);
  }

  function load(o) {
    var box = D.getElementById('tf-out'); if (!box) return;
    var my = ++req;
    box.innerHTML = '<div class="tf-skel"><i></i><i></i><i></i></div>';
    var p = o.tab === 'tf' ? tafsir(o.book, o.s, o.a) : wbw(o.s, o.a);
    p.then(function (r) {
      if (my !== req || !D.getElementById('tf-out')) return;
      box.innerHTML = '';
      if (o.tab === 'wbw') {
        var g = D.createElement('div'); g.className = 'tf-grid'; g.setAttribute('dir', 'rtl');
        g.innerHTML = r.map(function (w, i) {
          return '<div class="tf-w"><span class="tf-wn">' + bn(i + 1) + '</span><b class="pt-ar" lang="ar">' + esc(w[0]) + '</b>' + (w[2] ? '<small dir="ltr">' + esc(w[2]) + '</small>' : '') + '<span class="tf-wm" dir="ltr">' + esc(w[1].trim()) + '</span></div>';
        }).join('');
        box.appendChild(g);
      } else {
        var art = D.createElement('article'); art.className = 'tk-card pt-card tf-text';
        var mine = r.keys.indexOf(apiKey(o.s, o.a)) >= 0, empty = !r.html.replace(/<[^>]*>/g, '').trim();
        if (empty) {
          var first = r.keys[0] || '';
          art.innerHTML = ui.notice('', 'এই আয়াতের তাফসির একসাথে দেওয়া আছে', 'এই বইয়ে কয়েকটি আয়াতের ব্যাখ্যা একসাথে লেখা হয়েছে' + (first ? ' — আয়াত ' + esc(bn(first)) + ' থেকে শুরু' : '') + '। আগের আয়াতে গিয়ে পড়ুন, বা অন্য তাফসির বেছে নিন।');
        } else {
          if (!mine || r.keys.length > 1) { var h = D.createElement('p'); h.className = 'tf-grp'; h.textContent = 'যে আয়াতগুলোর একসাথে ব্যাখ্যা: ' + bn(r.keys.join(', ')) + (o.s === 1 ? ' (Quran.com-এর গণনায়)' : ''); art.appendChild(h); }
          art.appendChild(clean(r.html));
        }
        box.appendChild(art);
      }
      if (W.PT && PT.hydrateIcons) PT.hydrateIcons(box);
    }, function () {
      if (my !== req || !D.getElementById('tf-out')) return;
      box.innerHTML = ui.notice('warning', 'আনা যায়নি', navigator.onLine === false ? 'ইন্টারনেট সংযোগ নেই। সংযোগ চালু করে আবার চেষ্টা করুন।' : 'সার্ভারে পৌঁছানো যায়নি। একটু পরে আবার চেষ্টা করুন।', '<button type="button" class="pt-btn pt-btn--ghost pt-btn--sm tf-retry" data-act="retry">' + ic('refresh') + 'আবার চেষ্টা</button>');
      if (W.PT && PT.hydrateIcons) PT.hydrateIcons(box);
    });
  }

  function step(d) {
    var A = Q(), o = data(); if (!A) return;
    var n = A.quranModel[o.s - 1].ayahs.length;
    o.a += d;
    if (o.a < 1) { if (o.s > 1) { o.s--; o.a = A.quranModel[o.s - 1].ayahs.length; } else o.a = 1; }
    else if (o.a > n) { if (o.s < 114) { o.s++; o.a = 1; } else o.a = n; }
    save(o); ui.rerender();
    var c = D.querySelector('#tool-body .tf-ayah'); if (c && c.getBoundingClientRect().top < 0) c.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }

  T.register('tafsir', {
    title: 'তাফসির ও শব্দার্থ', sub: 'প্রতিটি শব্দের অর্থ ও নির্ভরযোগ্য বাংলা তাফসির', icon: 'quran', group: 'learn', order: 5,
    hub: { t: 'তাফসির ও শব্দে শব্দে অর্থ', s: 'আহসানুল বায়ান, আবু বকর জাকারিয়া, ইবনে কাসীর, ফাতহুল মাজীদ' },
    render: function (el, u, arg) { render(el, arg); },
    onEvent: function (kind, name, v, node) {
      var o = data();
      if (kind === 'seg' && name === 'tab') { o.tab = v === 'tf' ? 'tf' : 'wbw'; save(o); ui.rerender(); }
      else if (kind === 'chip' && name === 'book') { o.book = bookOf(v)[0]; save(o); ui.rerender(); }
      else if (kind === 'act' && name === 'go') step(+v);
      else if (kind === 'act' && name === 'retry') load(o);
      else if (kind === 'act' && name === 'read') { if (W.__ptGo) W.__ptGo('quran:' + o.s + ':' + o.a); }
      else if (kind === 'in' && name === 'ayah') {
        var A = Q(); if (!A) return;
        var x = parseInt(ui.en(v), 10), n = A.quranModel[o.s - 1].ayahs.length;
        if (isFinite(x)) { o.a = Math.max(1, Math.min(n, x)); save(o); }
        ui.rerender();
      }
    }
  });
})();
