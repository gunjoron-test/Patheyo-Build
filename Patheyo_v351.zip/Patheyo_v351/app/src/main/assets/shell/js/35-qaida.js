/* =============================================================================
   v350: নূরানী কায়দা ও তাজবিদ (tool:qaida)
   ধাপে ধাপে: হরফ ও মাখরাজ → হরফের রূপ → হরকত → তানবীন → সুকুন → তাশদীদ → মাদ্দ →
             নূন সাকিন/তানবীন → মীম সাকিন → গুন্নাহ → কলকলা → রা → আল্লাহ শব্দের লাম → মাদ্দের প্রকার → ওয়াকফের চিহ্ন
   + অনুশীলন: "হরফ চিনুন" (এলোমেলো ১০টি প্রশ্ন)।
   সব লেখা অফলাইনে, অ্যাপের ভেতরেই (প্রচলিত নূরানী পদ্ধতি ও তাজবিদের সাধারণ নিয়ম অনুযায়ী)।
   উদাহরণের শব্দগুলো কুরআনের পরিচিত শব্দ। শুদ্ধ উচ্চারণের জন্য উস্তাদের কাছে মশক জরুরি — পেজে বলা আছে।
   ডেটা: ptu_qaida = { done:[পাঠের id], best } (ক্লাউডে যায়)
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic, esc = ui.esc;
  var KEY = 'ptu_qaida';
  var ZWJ = '‍';
  /* [হরফ, নাম, মাখরাজ-দল, মোটা(১), সংযুক্ত হয় না(১)] */
  var L = [
    ['ا', 'আলিফ', 'j', 0, 1], ['ب', 'বা', 's', 0, 0], ['ت', 'তা', 't', 0, 0], ['ث', 'ছা', 't', 0, 0], ['ج', 'জীম', 't', 0, 0], ['ح', 'হা (গলা)', 'h', 0, 0],
    ['خ', 'খা', 'h', 1, 0], ['د', 'দাল', 't', 0, 1], ['ذ', 'যাল', 't', 0, 1], ['ر', 'রা', 't', 0, 1], ['ز', 'যা', 't', 0, 1], ['س', 'সীন', 't', 0, 0],
    ['ش', 'শীন', 't', 0, 0], ['ص', 'সোয়াদ', 't', 1, 0], ['ض', 'দোয়াদ', 't', 1, 0], ['ط', 'ত্বোয়া', 't', 1, 0], ['ظ', 'যোয়া', 't', 1, 0], ['ع', 'আইন', 'h', 0, 0],
    ['غ', 'গাইন', 'h', 1, 0], ['ف', 'ফা', 's', 0, 0], ['ق', 'ক্বাফ', 't', 1, 0], ['ك', 'কাফ', 't', 0, 0], ['ل', 'লাম', 't', 0, 0], ['م', 'মীম', 's', 0, 0],
    ['ن', 'নূন', 't', 0, 0], ['و', 'ওয়াও', 's', 0, 1], ['ه', 'হা (গোল)', 'h', 0, 0], ['ء', 'হামযা', 'h', 0, 1], ['ي', 'ইয়া', 't', 0, 0]
  ];
  var MAKH = {
    h: ['কণ্ঠ (হালক)', 'গলার ভেতর থেকে: ء ه গলার শেষ (বুকের কাছে), ع ح মাঝখান, غ خ শুরু (মুখের কাছে)'],
    t: ['জিহ্বা (লিসান)', 'জিহ্বার বিভিন্ন অংশ তালু/দাঁতে লাগিয়ে: ق ك গোড়া · ج ش ي মাঝ · ض কিনারা · ل ن ر আগা · ط د ت আগা ও উপরের দাঁতের গোড়া · ص س ز আগা ও নিচের দাঁত · ظ ذ ث আগা ও উপরের দাঁতের মাথা'],
    s: ['ঠোঁট (শাফাতান)', 'ف নিচের ঠোঁটের পেট ও উপরের দাঁতের মাথা · ب م দুই ঠোঁট মিলিয়ে · و দুই ঠোঁট গোল করে (পুরো না মিলিয়ে)'],
    j: ['মুখের খালি জায়গা (জাওফ)', 'মাদ্দের হরফ — আলিফ (আগে যবর), ওয়াও সাকিন (আগে পেশ), ইয়া সাকিন (আগে যের) — মুখ ও গলার ফাঁকা জায়গা থেকে, বাতাস টেনে']
  };
  var FATHA = 'َ', KASRA = 'ِ', DAMMA = 'ُ', SUKUN = 'ْ', SHADDA = 'ّ', TF = 'ً', TK = 'ٍ', TD = 'ٌ';
  function letters(skipAlif) { return L.filter(function (x) { return !(skipAlif && (x[0] === 'ا')); }); }
  function grid(items, cls) { return '<div class="qd-grid' + (cls ? ' ' + cls : '') + '" dir="rtl">' + items.join('') + '</div>'; }
  function cell(ar, sub, attrs) { return '<div class="qd-c"' + (attrs || '') + '><b class="pt-ar" lang="ar">' + esc(ar) + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</div>'; }
  function ex(rows) {      /* উদাহরণ: [আরবি, বাংলা ব্যাখ্যা] */
    return '<div class="qd-ex">' + rows.map(function (r) { return '<div class="qd-exr"><b class="pt-ar" dir="rtl" lang="ar">' + esc(r[0]) + '</b><span>' + r[1] + '</span></div>'; }).join('') + '</div>';
  }
  function rule(title, letterStr, text, examples) {
    return '<div class="qd-rule"><div class="qd-rh"><b>' + title + '</b>' + (letterStr ? '<span class="pt-ar qd-rl" dir="rtl" lang="ar">' + esc(letterStr) + '</span>' : '') + '</div><p>' + text + '</p>' + (examples ? ex(examples) : '') + '</div>';
  }
  function p(t) { return '<p class="tk-p qd-p">' + t + '</p>'; }

  /* ---------------------------------------------------------------- পাঠ */
  var LESSONS = [
    ['harf', 'book', 'পাঠ ১ · হরফ ও মাখরাজ', '২৯টি হরফ, নাম ও কোথা থেকে উচ্চারণ', function () {
      return p('হরফে চাপ দিলে নাম, উচ্চারণের জায়গা (মাখরাজ) আর রূপগুলো দেখাবে। <span class="qd-hv">সোনালি</span> হরফগুলো মোটা (পুর) করে পড়তে হয় — خ ص ض غ ط ق ظ।') +
        grid(L.map(function (x, i) { return cell(x[0], x[1], ' data-act="lt" data-v="' + i + '" role="button" tabindex="0"' + (x[3] ? ' data-h="1"' : '')); }), 'qd-grid--l') +
        '<div id="qd-lt"></div>' +
        '<div class="qd-mk">' + Object.keys(MAKH).map(function (k) { return '<div class="qd-mki"><b>' + MAKH[k][0] + '</b><small>' + MAKH[k][1] + '</small></div>'; }).join('') + '</div>';
    }],
    ['forms', 'grid', 'পাঠ ২ · হরফের রূপ', 'শব্দের শুরু, মাঝ ও শেষে হরফ দেখতে কেমন', function () {
      return p('আরবি হরফ শব্দে জোড়া লাগলে রূপ বদলায়। ডান থেকে: একা · শুরুতে · মাঝে · শেষে। ا د ذ ر ز و — এই ছয়টি পরের হরফের সাথে জোড়া লাগে না।') +
        '<div class="qd-forms" dir="rtl">' + letters().filter(function (x) { return x[0] !== 'ء'; }).map(function (x) {
          var f = x[4] ? [x[0], x[0], ZWJ + x[0], ZWJ + x[0]] : [x[0], x[0] + ZWJ, ZWJ + x[0] + ZWJ, ZWJ + x[0]];
          return '<div class="qd-fr"><span class="qd-fn">' + x[1] + '</span>' + f.map(function (s) { return '<b class="pt-ar" lang="ar">' + s + '</b>'; }).join('') + '</div>';
        }).join('') + '</div>';
    }],
    ['harakat', 'edit', 'পাঠ ৩ · হরকত (যবর, যের, পেশ)', 'স্বরচিহ্ন দিয়ে পড়া', function () {
      return p('<b>যবর</b> ( َ ) — হরফের উপরে, "আ"-কার: بَ = বা। <b>যের</b> ( ِ ) — নিচে, "ই"-কার: بِ = বি। <b>পেশ</b> ( ُ ) — উপরে ছোট ওয়াও, "উ"-কার: بُ = বু। হরকত টেনে নয়, ছোট করে (এক আলিফ পরিমাণ সময়) পড়তে হয়।') +
        grid(letters(true).filter(function (x) { return x[0] !== 'ء'; }).map(function (x) { return cell(x[0] + FATHA + ' ' + x[0] + KASRA + ' ' + x[0] + DAMMA, x[1]); }), 'qd-grid--w') +
        ex([['بَدَأَ', 'বাদাআ — সব যবর'], ['كُتِبَ', 'কুতিবা — পেশ, যের, যবর'], ['خَلَقَ', 'খালাক্বা']]);
    }],
    ['tanwin', 'plus', 'পাঠ ৪ · তানবীন', 'দুই যবর, দুই যের, দুই পেশ', function () {
      return p('তানবীন মানে শেষে একটি "ন" ধ্বনি যোগ হওয়া। দুই যবর ( ً ) = আন, দুই যের ( ٍ ) = ইন, দুই পেশ ( ٌ ) = উন। দুই যবরের পর সাধারণত একটি আলিফ লেখা থাকে, সেটি পড়া হয় না।') +
        grid(['ب', 'ت', 'ج', 'د', 'ر', 'س', 'ع', 'ق', 'ك', 'ل', 'م', 'ن'].map(function (h) { return cell(h + TF + ' ' + h + TK + ' ' + h + TD, ''); }), 'qd-grid--w') +
        ex([['عَلِيمٌ', 'আলীমুন'], ['حَكِيمًا', 'হাকীমান (আলিফ পড়া হয় না)'], ['غَفُورٍ', 'গাফূরিন']]);
    }],
    ['sukun', 'minus', 'পাঠ ৫ · সুকুন (জযম)', 'হরকত ছাড়া হরফ — আগের হরফের সাথে মিলিয়ে', function () {
      return p('সুকুন ( ْ ) থাকলে হরফটির নিজের কোনো স্বর নেই — আগের হরকতওয়ালা হরফের সাথে মিলিয়ে এক ঝটকায় পড়তে হয়।') +
        ex([['أَبْ', 'আব'], ['مِنْ', 'মিন'], ['قُلْ', 'কুল'], ['يَخْلُقُ', 'ইয়াখলুকু'], ['الْحَمْدُ', 'আলহামদু']]);
    }],
    ['shadda', 'sparkle', 'পাঠ ৬ · তাশদীদ', 'একই হরফ দুবার — প্রথমটি সাকিন, পরেরটি হরকতসহ', function () {
      return p('তাশদীদ ( ّ ) মানে হরফটি দুবার পড়া — প্রথমবার আগের হরফের সাথে সাকিন হয়ে, পরেরবার নিজের হরকতে। রাব্বা = রাব্‌-বা।') +
        ex([['رَبَّ', 'রাব্বা'], ['ثُمَّ', 'ছুম্মা (মীমে গুন্নাহ)'], ['إِنَّ', 'ইন্না (নূনে গুন্নাহ)'], ['الصَّلَاةَ', 'আসসালাতা']]);
    }],
    ['madd', 'expand', 'পাঠ ৭ · মাদ্দ (টেনে পড়া)', 'আলিফ, ওয়াও, ইয়া দিয়ে লম্বা স্বর', function () {
      return p('যবরের পর আলিফ, পেশের পর ওয়াও সাকিন, যেরের পর ইয়া সাকিন এলে স্বরটি দুই হরকত (এক আলিফ) পরিমাণ টেনে পড়তে হয়। খাড়া যবর ( ٰ ), খাড়া যের ও উল্টো পেশও একই রকম টানে।') +
        grid(['ب', 'ت', 'ق', 'ن'].map(function (h) { return cell(h + FATHA + 'ا ' + h + KASRA + 'ي ' + h + DAMMA + 'و', ''); }), 'qd-grid--w') +
        ex([['قَالَ', 'ক্বা-লা'], ['قِيلَ', 'ক্বী-লা'], ['يَقُولُ', 'ইয়াক্বূ-লু'], ['هٰذَا', 'হা-যা (খাড়া যবর)']]);
    }],
    ['nun', 'target', 'তাজবিদ ১ · নূন সাকিন ও তানবীন', 'ইযহার, ইদগাম, ইকলাব, ইখফা', function () {
      return p('নূন সাকিন ( نْ ) বা তানবীনের পর কোন হরফ এল, তার উপর চারটি নিয়ম:') +
        rule('১. ইযহার — স্পষ্ট করে পড়া', 'ء ه ع ح غ خ', 'কণ্ঠের ছয় হরফের আগে নূন পরিষ্কার উচ্চারণ, গুন্নাহ ছাড়া।', [['مَنْ آمَنَ', 'মান আমানা'], ['مِنْ خَوْفٍ', 'মিন খাওফ']]) +
        rule('২. ইদগাম — মিলিয়ে পড়া', 'ي ر م ل و ن', '"ইয়ারমালূন"-এর ছয় হরফে নূন পরের হরফে মিশে যায়। ي ن م و-তে গুন্নাহসহ; ل ر-তে গুন্নাহ ছাড়া। (একই শব্দের ভেতরে হলে ইদগাম হয় না, যেমন دُنْيَا)', [['مَن يَقُولُ', 'মাইঁ ইয়াক্বূলু — গুন্নাহসহ'], ['مِن رَّبِّهِمْ', 'মির রাব্বিহিম — গুন্নাহ ছাড়া']]) +
        rule('৩. ইকলাব — বদলে পড়া', 'ب', 'বা-এর আগে নূন সাকিন/তানবীন "মীম" হয়ে যায়, গুন্নাহসহ (অনেক মুসহাফে ছোট م লেখা থাকে)।', [['مِنۢ بَعْدِ', 'মিম বা’দি'], ['سَمِيعٌۢ بَصِيرٌ', 'সামীউম বাসীর']]) +
        rule('৪. ইখফা — গোপন করে পড়া', 'ت ث ج د ذ ز س ش ص ض ط ظ ف ق ك', 'বাকি ১৫ হরফে নূন পুরো উচ্চারণ না করে নাকে গুন্নাহ রেখে হালকা করে পড়া, দুই হরকত পরিমাণ।', [['مِن قَبْلِ', 'মিং ক্বাবলি'], ['أَنفُسَكُمْ', 'আংফুসাকুম'], ['كُنتُمْ', 'কুংতুম']]);
    }],
    ['mim', 'target', 'তাজবিদ ২ · মীম সাকিন', 'ইখফা শাফাবি, ইদগাম, ইযহার শাফাবি', function () {
      return rule('ইখফা শাফাবি', 'ب', 'মীম সাকিনের পর বা এলে ঠোঁট হালকা মিলিয়ে গুন্নাহসহ।', [['تَرْمِيهِم بِحِجَارَةٍ', 'তারমীহিম বিহিজারাহ']]) +
        rule('ইদগাম মিসলাইন', 'م', 'মীম সাকিনের পর মীম এলে দুটো মিলে এক মীম, গুন্নাহসহ।', [['لَهُم مَّا', 'লাহুম্মা']]) +
        rule('ইযহার শাফাবি', 'বাকি সব হরফ', 'স্পষ্ট মীম — বিশেষ করে و ও ف-এর আগে যেন গোপন না হয়ে যায়।', [['لَهُمْ فِيهَا', 'লাহুম ফীহা'], ['عَلَيْهِمْ وَلَا', 'আলাইহিম ওয়ালা']]);
    }],
    ['ghunna', 'volume', 'তাজবিদ ৩ · গুন্নাহ', 'নাকের বাঁশির সুর', function () {
      return p('নূন ও মীমে তাশদীদ থাকলে সবসময় গুন্নাহ — নাকের ভেতর দিয়ে দুই হরকত পরিমাণ সুর টেনে। ইদগাম (গুন্নাহসহ), ইকলাব, ইখফাতেও গুন্নাহ হয়।') +
        ex([['إِنَّ', 'ইন্‌— না'], ['ثُمَّ', 'ছুম্‌— মা'], ['مِنَ الْجِنَّةِ وَالنَّاسِ', 'মিনাল জিন্‌— নাতি ওয়ান্‌— নাস']]);
    }],
    ['qalqala', 'repeat', 'তাজবিদ ৪ · কলকলা', 'قطب جد — প্রতিধ্বনি দিয়ে পড়া', function () {
      return rule('কলকলার পাঁচ হরফ', 'ق ط ب ج د', '"কুতবু জাদিন" — এই হরফগুলো সাকিন হলে (বা ওয়াকফে থামলে) একটু ধাক্কা দিয়ে প্রতিধ্বনির মতো পড়তে হয়। শব্দের শেষে থামলে কলকলা আরও স্পষ্ট (বড় কলকলা)।',
        [['يَقْطَعُونَ', 'ইয়াক্‌ত্বাঊনা — মাঝে ছোট কলকলা'], ['أَحَدْ', 'আহাদ্‌ — থামলে বড় কলকলা'], ['الْفَلَقْ', 'আল-ফালাক্ব্']]);
    }],
    ['ra', 'edit', 'তাজবিদ ৫ · রা মোটা ও পাতলা', 'কখন পুর, কখন বারীক', function () {
      return rule('মোটা (পুর) রা', 'رَ رُ', 'রা-তে যবর বা পেশ থাকলে; রা সাকিন আর আগে যবর/পেশ থাকলে।', [['رَبِّ', 'রাব্বি — মোটা'], ['الْقُرْآنُ', 'আল-কুরআন — মোটা']]) +
        rule('পাতলা (বারীক) রা', 'رِ', 'রা-তে যের থাকলে; রা সাকিন আর আগে যের থাকলে (পরে মোটা হরফ না এলে)।', [['رِجَالٌ', 'রিজালুন — পাতলা'], ['فِرْعَوْنَ', 'ফির‘আওনা — পাতলা']]);
    }],
    ['allah', 'crescent', 'তাজবিদ ৬ · আল্লাহ শব্দের লাম', 'কখন মোটা, কখন পাতলা', function () {
      return rule('মোটা', 'اللّٰه', 'আগে যবর বা পেশ থাকলে, বা শুরুতেই পড়লে — লাম মোটা (আল্লাহ্‌)।', [['قَالَ اللّٰهُ', 'ক্বা-লাল্লাহু — মোটা'], ['رَسُولُ اللّٰهِ', 'রাসূলুল্লাহ — মোটা']]) +
        rule('পাতলা', 'اللّٰه', 'আগে যের থাকলে লাম পাতলা (ইল্লাহ্‌)।', [['بِسْمِ اللّٰهِ', 'বিসমিল্লাহি — পাতলা'], ['لِلّٰهِ', 'লিল্লাহি — পাতলা']]);
    }],
    ['maddtypes', 'clock', 'তাজবিদ ৭ · মাদ্দের প্রকার', 'কতটুকু টানতে হবে', function () {
      return '<div class="qd-tbl">' + [
        ['মাদ্দে তবয়ী (স্বাভাবিক)', '২ হরকত', 'قَالَ'],
        ['মাদ্দে মুত্তাসিল (একই শব্দে মাদ্দের পর হামযা)', '৪–৫ হরকত, টানা ওয়াজিব', 'جَاءَ'],
        ['মাদ্দে মুনফাসিল (পরের শব্দে হামযা)', '৪–৫ হরকত (অনেক কারি ২ও পড়েন)', 'بِمَا أُنزِلَ'],
        ['মাদ্দে লাযিম (মাদ্দের পর তাশদীদ/স্থায়ী সুকুন)', '৬ হরকত, টানা ওয়াজিব', 'الضَّآلِّينَ'],
        ['মাদ্দে আরিদ (থামার কারণে সুকুন)', '২, ৪ বা ৬ হরকত', 'الرَّحِيمْ'],
        ['মাদ্দে লীন (যবরের পর و/ي সাকিন, থামলে)', '২, ৪ বা ৬ হরকত', 'خَوْفْ']
      ].map(function (r) { return '<div class="qd-tr"><span><b>' + r[0] + '</b><small>' + r[1] + '</small></span><b class="pt-ar" dir="rtl" lang="ar">' + esc(r[2]) + '</b></div>'; }).join('') + '</div>' +
        p('এক হরকত = আঙুল একবার ভাঁজ করা বা খোলার মতো সময়।');
    }],
    ['waqf', 'pause', 'তাজবিদ ৮ · ওয়াকফের চিহ্ন', 'কোথায় থামবেন, কোথায় মিলিয়ে পড়বেন', function () {
      return '<div class="qd-tbl">' + [
        ['۝', 'আয়াতের শেষ — থামা উত্তম'], ['مـ', 'ওয়াকফে লাযিম — অবশ্যই থামুন'], ['ط', 'ওয়াকফে মুতলাক — থামা উত্তম'],
        ['ج', 'ওয়াকফে জায়েয — থামা ও মিলানো দুটোই চলে'], ['ز', 'না থামা উত্তম'], ['ص', 'দম ফুরালে থামা যায়, মিলিয়ে পড়া উত্তম'],
        ['لا', 'থামবেন না (থামলে আবার আগ থেকে মিলিয়ে পড়ুন)'], ['قلى', 'থামা উত্তম'], ['صلى', 'মিলিয়ে পড়া উত্তম'], ['∴ ∴', 'মুআনাকা — দুই জায়গার যেকোনো একটিতে থামুন, দুটিতে নয়']
      ].map(function (r) { return '<div class="qd-tr"><span><b>' + r[1] + '</b></span><b class="pt-ar qd-wq" dir="rtl" lang="ar">' + esc(r[0]) + '</b></div>'; }).join('') + '</div>' +
        p('চিহ্নগুলো উপমহাদেশে প্রচলিত মুসহাফ অনুযায়ী। থামার সময় শেষ হরফ সাকিন করে পড়ুন; দুই যবর থাকলে আলিফ টেনে (যেমন عَلِيمًا → আলীমা)।');
    }]
  ];

  /* ---------------------------------------------------------------- অনুশীলন */
  var Z = { on: false, q: [], i: 0, score: 0, picked: -1 };
  function newQuiz() {
    var pool = L.slice().sort(function () { return Math.random() - 0.5; }).slice(0, 10);
    Z.q = pool.map(function (x) {
      var opts = [x].concat(L.filter(function (y) { return y !== x; }).sort(function () { return Math.random() - 0.5; }).slice(0, 3)).sort(function () { return Math.random() - 0.5; });
      return { a: x, opts: opts };
    });
    Z.on = true; Z.i = 0; Z.score = 0; Z.picked = -1;
  }
  function quizHtml(o) {
    if (!Z.on) return '<div class="qd-qs">' + p('এলোমেলো ১০টি হরফ দেখানো হবে — সঠিক নামটি বাছুন।' + (o.best ? ' আপনার সেরা: <b>' + bn(o.best) + '/১০</b>' : '')) +
      '<button type="button" class="pt-btn pt-btn--primary" data-act="qstart">' + ic('play') + 'অনুশীলন শুরু</button></div>';
    if (Z.i >= Z.q.length) return '<div class="qd-qs qd-done"><b class="qd-big">' + bn(Z.score) + '<small>/১০</small></b>' + p(Z.score >= 9 ? 'মাশাআল্লাহ! চমৎকার।' : Z.score >= 6 ? 'ভালো হয়েছে — আরেকবার চেষ্টা করুন।' : 'হরফের পাঠটি আরেকবার দেখে নিন, তারপর আবার চেষ্টা করুন।') +
      '<button type="button" class="pt-btn pt-btn--primary" data-act="qstart">' + ic('refresh') + 'আবার খেলুন</button></div>';
    var q = Z.q[Z.i];
    return '<div class="qd-qz"><div class="qd-qh"><span class="pt-chip">প্রশ্ন ' + bn(Z.i + 1) + '/১০</span><span class="pt-chip">সঠিক ' + bn(Z.score) + '</span></div>' +
      '<b class="pt-ar qd-qa" lang="ar">' + esc(q.a[0]) + '</b><div class="qd-opts">' + q.opts.map(function (x, k) {
        var st = Z.picked < 0 ? '' : (x === q.a ? ' is-ok' : (k === Z.picked ? ' is-bad' : ''));
        return '<button type="button" class="pt-btn pt-btn--ghost qd-opt' + st + '" data-act="qpick" data-v="' + k + '"' + (Z.picked >= 0 ? ' disabled' : '') + '>' + x[1] + '</button>';
      }).join('') + '</div>' + (Z.picked >= 0 ? '<button type="button" class="pt-btn pt-btn--primary qd-nx" data-act="qnext">' + (Z.i + 1 < Z.q.length ? 'পরের প্রশ্ন' : 'ফলাফল') + ic('next') + '</button>' : '') + '</div>';
  }

  function data() { var o = ui.get(KEY, null) || {}; return { done: Array.isArray(o.done) ? o.done : [], best: +o.best || 0 }; }
  var open = '';
  function render(el) {
    var o = data(), n = o.done.length;
    el.innerHTML = '<div class="tk-wrap">' +
      '<div class="tk-card pt-card qd-hero"><div class="qd-hr"><b class="pt-ar" lang="ar" dir="rtl">' + esc('أ ب ت') + '</b><span><b>শুদ্ধ করে কুরআন পড়া শিখুন</b><small>' + bn(n) + '/' + bn(LESSONS.length) + ' পাঠ শেষ</small></span></div>' +
        '<div class="pt-progress qd-prog"><div class="pt-progress__bar" style="width:' + Math.round(n / LESSONS.length * 100) + '%"></div></div></div>' +
      LESSONS.map(function (s) {
        var done = o.done.indexOf(s[0]) >= 0;
        return ui.acc(s[0], open === s[0], done ? 'check' : s[1], s[2], s[3] + (done ? ' · শেষ' : ''), open === s[0] ? s[4]() +
          '<button type="button" class="pt-btn ' + (done ? 'pt-btn--ghost' : 'pt-btn--tonal') + ' qd-dn" data-act="done" data-v="' + s[0] + '">' + ic('check') + (done ? 'শেষ হয়েছে ✓' : 'পাঠ শেষ হয়েছে') + '</button>' : '');
      }).join('') +
      ui.acc('quiz', open === 'quiz', 'star', 'অনুশীলন · হরফ চিনুন', 'হরফ দেখে নাম বাছুন — খেলার মতো', open === 'quiz' ? quizHtml(o) : '') +
      '<p class="tk-fine">' + ic('info') + 'বই পড়ে নিয়ম জানা যায়, কিন্তু শুদ্ধ উচ্চারণ শিখতে একজন অভিজ্ঞ উস্তাদের কাছে শুনে শুনে মশক (অনুশীলন) করা জরুরি। কুরআন প্লেয়ারে কারিদের তিলাওয়াত শুনে মিলিয়ে নিন।</p></div>';
  }
  function letterCard(i) {
    var x = L[i], m = MAKH[x[2]], f = x[4] ? [x[0], ZWJ + x[0]] : [x[0], x[0] + ZWJ, ZWJ + x[0] + ZWJ, ZWJ + x[0]];
    return '<div class="qd-lc"><b class="pt-ar qd-lcb" lang="ar">' + esc(x[0]) + '</b><div class="qd-lci"><b>' + x[1] + (x[3] ? ' <span class="pt-chip pt-chip--gold">মোটা</span>' : '') + '</b>' +
      '<small>উচ্চারণের জায়গা: ' + m[0] + '</small><span class="pt-ar qd-lcf" dir="rtl" lang="ar">' + f.join(' ') + '</span>' +
      (x[0] !== 'ا' && x[0] !== 'ء' ? '<span class="pt-ar qd-lcf" dir="rtl" lang="ar">' + [FATHA, KASRA, DAMMA, SUKUN].map(function (h) { return x[0] + h; }).join('  ') + '</span>' : '') + '</div></div>';
  }

  T.register('qaida', {
    title: 'নূরানী কায়দা ও তাজবিদ', sub: 'হরফ থেকে তাজবিদ — ধাপে ধাপে', icon: 'book', group: 'learn', order: 3,
    hub: { t: 'নূরানী কায়দা ও তাজবিদ', s: 'হরফ, হরকত, মাদ্দ, গুন্নাহ, কলকলা, ওয়াকফ — অনুশীলনসহ' },
    render: function (el) { render(el); },
    onEvent: function (kind, name, v) {
      var o = data();
      if (kind !== 'act') return;
      if (name === 'acc') {
        open = open === v ? '' : v; if (v === 'quiz' && !open) Z.on = false; ui.rerender();
        if (open) setTimeout(function () { var b = D.querySelector('#tool-body [data-act="acc"][data-v="' + v + '"]'); if (b) try { b.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (e) {} }, 30);
      } else if (name === 'lt') {
        var box = D.getElementById('qd-lt'); if (!box) return;
        [].forEach.call(D.querySelectorAll('#tool-body .qd-c.is-on'), function (c) { c.classList.remove('is-on'); });
        var c = D.querySelector('#tool-body .qd-c[data-v="' + (+v) + '"]'); if (c) c.classList.add('is-on');
        box.innerHTML = letterCard(+v); ui.haptic('light');
        try { box.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {}
      } else if (name === 'done') {
        var i = o.done.indexOf(v);
        if (i >= 0) o.done.splice(i, 1); else { o.done.push(v); ui.haptic('success'); if (o.done.length === LESSONS.length) ui.toast('সব পাঠ শেষ — মাশাআল্লাহ! এবার নিয়মিত তিলাওয়াতে অনুশীলন করুন', { type: 'success' }); }
        ui.set(KEY, o);
        if (i < 0) { var idx = LESSONS.map(function (s) { return s[0]; }).indexOf(v); var nx = LESSONS[idx + 1]; open = nx ? nx[0] : ''; }
        ui.rerender();
        if (open) setTimeout(function () { var b = D.querySelector('#tool-body [data-act="acc"][data-v="' + open + '"]'); if (b) try { b.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (e) {} }, 30);
      } else if (name === 'qstart') { newQuiz(); ui.rerender(); }
      else if (name === 'qpick' && Z.picked < 0) {
        Z.picked = +v; var q = Z.q[Z.i];
        if (q.opts[Z.picked] === q.a) { Z.score++; ui.haptic('success'); } else ui.haptic('warning');
        ui.rerender();
      } else if (name === 'qnext') {
        Z.i++; Z.picked = -1;
        if (Z.i >= Z.q.length && Z.score > o.best) { o.best = Z.score; ui.set(KEY, o); }
        ui.rerender();
      }
    }
  });
})();
