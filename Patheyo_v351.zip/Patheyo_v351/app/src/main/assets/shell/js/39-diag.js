/* =============================================================================
   v351: সমস্যার রিপোর্ট (tool:diag) — সেটিংস → সহায়তা ও অ্যাপ → "সমস্যার রিপোর্ট"
   নেটিভ: PatheyoDiag (CrashRecorder.kt) — অ্যাপ ক্র্যাশ/জমে যাওয়া/শুরুতেই বন্ধ হলে তার কারিগরি কারণ ফোনেই জমা থাকে
   (অ্যাপের নিজের ধরা ত্রুটি + Android-এর ApplicationExitInfo)। কোথাও নিজে থেকে পাঠানো হয় না — ইউজার কপি/শেয়ার করেন।
   আগের বার অস্বাভাবিকভাবে বন্ধ হয়ে থাকলে অ্যাপ খোলার কিছুক্ষণ পর একবার ছোট বার্তা দেখায়।
   নিরাপত্তা: রিপোর্টের লেখা DOM-এ শুধু textContent দিয়ে।
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, ic = ui.ic;
  function N() { return W.PatheyoDiag || null; }
  var text = '';

  T.register('diag', {
    title: 'সমস্যার রিপোর্ট', sub: 'অ্যাপ বন্ধ বা আটকে গেলে তার কারিগরি কারণ', icon: 'shield',
    render: function (el) {
      var n = N(); text = '';
      try { if (n) text = String(n.report() || ''); } catch (e) {}
      el.innerHTML = '<div class="tk-wrap">' +
        (text ? ui.notice('warning', 'রিপোর্ট পাওয়া গেছে', 'নিচের লেখাটি কপি বা শেয়ার করে ডেভেলপারকে পাঠান — এতে সমস্যার আসল কারণ বোঝা যাবে। এতে আপনার ব্যক্তিগত কোনো ডেটা নেই, শুধু ফোনের মডেল, ভার্সন ও কারিগরি তথ্য।') +
            '<div class="dg-btns"><button type="button" class="pt-btn pt-btn--primary" data-act="share">' + ic('share') + 'শেয়ার</button><button type="button" class="pt-btn pt-btn--ghost" data-act="copy">' + ic('copy') + 'কপি</button></div>' +
            '<pre class="tk-card pt-card dg-pre" id="dg-pre"></pre>' +
            '<button type="button" class="pt-btn pt-btn--ghost dg-clr" data-act="clear">' + ic('trash') + 'রিপোর্ট মুছে ফেলুন</button>'
          : ui.notice('success', 'কোনো সমস্যা ধরা পড়েনি', n ? 'অ্যাপ বন্ধ হয়ে যাওয়া বা আটকে যাওয়ার কোনো রেকর্ড নেই। কখনো এমন হলে, পরের বার অ্যাপ খুলে এখানে এলে কারণ দেখতে পাবেন।' : 'এই সুবিধা শুধু অ্যাপের ভেতরে কাজ করে।')) +
        '</div>';
      var pre = D.getElementById('dg-pre'); if (pre) pre.textContent = text;
    },
    onEvent: function (kind, name) {
      if (kind !== 'act') return;
      var n = N();
      if (name === 'share') {
        try { if (W.PatheyoShare && W.PatheyoShare.shareText) { W.PatheyoShare.shareText('পাথেয় — সমস্যার রিপোর্ট\n\n' + text); return; } } catch (e) {}
        name = 'copy';
      }
      if (name === 'copy') {
        try { navigator.clipboard.writeText(text).then(function () { ui.toast('কপি হয়েছে', { type: 'success' }); }, function () { ui.toast('কপি করা যায়নি', {}); }); } catch (e) {}
      } else if (name === 'clear') {
        try { n && n.clear(); } catch (e) {}
        ui.toast('রিপোর্ট মুছে ফেলা হয়েছে', {}); ui.rerender();
      }
    }
  });

  /* আগের বার অ্যাপ অস্বাভাবিকভাবে বন্ধ হয়ে থাকলে — খোলার কিছুক্ষণ পর একবার জানানো (নেটিভ রেকর্ড পড়তে একটু সময় দিয়ে) */
  setTimeout(function () {
    try {
      var n = N(); if (!n || !n.hasUnread()) return;
      if (W.PT && PT.toast) PT.toast('আগের বার অ্যাপ ঠিকমতো চলেনি — কারণটা রিপোর্টে আছে', { action: 'দেখুন', onAction: function () { W.__ptGo && W.__ptGo('tool:diag'); }, ms: 8000 });
    } catch (e) {}
  }, 6000);
})();
