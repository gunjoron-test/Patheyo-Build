/* =============================================================================
   v347: রোজার হিসাব (tool:fasting) — রমজান · কাজা · নফল
   • রমজান: ৩০ দিনের ঘর — চাপলে "রেখেছি" → "ছুটেছে" → খালি। মাজুর অবস্থার দিনগুলো (shell/js/23-prayer-tools.js →
     window.__ptExcused) নিজে থেকেই "মাজুর" — এগুলো কাজা হিসেবে গোনা হয়।
   • কাজা: বাকি = আগের বছরের জমা + রমজানে ছুটেছে + মাজুরের দিন − আদায় করা কাজা।
   • নফল: আজ কোন সুন্নত রোজার দিন (সোম/বৃহস্পতি, আইয়ামে বীয, আশুরা, আরাফা, শাওয়ালের ছয়), সামনের দিনগুলো।
     ঈদুল ফিতর (১ শাওয়াল), ঈদুল আযহা ও তাশরিকের দিন (১০–১৩ যিলহজ) রোজা নিষিদ্ধ — এসব দিনে যোগ করা যায় না।
   হিজরি তারিখ: shared/prayer-calc.js → PtPrayer.hijriParts (অ্যাপের বাকি জায়গার একই হিসাব ও সমন্বয়)।
   ডেটা: ptu_fasting (ক্লাউডে যায়) = { ram:{ "1447":{ "1":"k"|"m"|"e" } }, base, paid:["YYYY-MM-DD"], nafl:{ "YYYY-MM-DD":1 } }
   ============================================================================= */
(function () {
  'use strict';
  var W = window, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic;
  var KEY = 'ptu_fasting';
  var HM = ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল উলা', 'জমাদিউস সানি', 'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'];

  function load() { var o = ui.get(KEY, null) || {}; return { ram: o.ram || {}, base: +o.base || 0, paid: Array.isArray(o.paid) ? o.paid : [], nafl: o.nafl || {} }; }
  function save(o) { ui.set(KEY, o); }
  function hp(d) { var P = W.PtPrayer; return P && P.hijriParts ? P.hijriParts(d, P.hijriAdj ? P.hijriAdj() : 0) : null; }
  function noon(d) { var x = new Date(d); x.setHours(12, 0, 0, 0); return x; }
  function excusedOn(d) { try { return !!(W.__ptExcused && W.__ptExcused.at(noon(d).getTime())); } catch (e) { return false; } }

  /* আজ থেকে আগে-পরে ~১৪ মাসের মধ্যে রমজানগুলো: { 1447: [Date(১ রমজান), …] } */
  var ramCache = null, ramCacheDay = '';
  function ramadans() {
    var today = ui.dkey(); if (ramCache && ramCacheDay === today) return ramCache;
    var out = {}, d = noon(new Date()); d.setDate(d.getDate() - 420);
    for (var i = 0; i < 840; i++, d.setDate(d.getDate() + 1)) {
      var h = hp(d); if (!h || h.m !== 9) continue;
      (out[h.y] = out[h.y] || [])[h.d - 1] = new Date(d);
    }
    ramCache = out; ramCacheDay = today; return out;
  }
  function dayState(o, y, n, date) {
    var v = (o.ram[y] || {})[n];
    if (v) return v;
    if (excusedOn(date) && noon(date) <= noon(new Date())) return 'e';
    return '';
  }
  /* রমজানের ছুটে যাওয়া (m) + মাজুর (e) — সব বছর */
  function ramOwed(o) {
    var n = 0, R = ramadans();
    Object.keys(o.ram).forEach(function (y) { var r = o.ram[y]; Object.keys(r).forEach(function (k) { if (r[k] === 'm' || r[k] === 'e') n++; }); });
    Object.keys(R).forEach(function (y) {                       /* মাজুরের দিন — ইউজার আলাদা করে চিহ্ন না দিলেও */
      R[y].forEach(function (d, i) { if (d && !(o.ram[y] || {})[i + 1] && dayState(o, y, i + 1, d) === 'e') n++; });
    });
    return n;
  }
  function owed(o) { return Math.max(0, o.base + ramOwed(o) - o.paid.length); }

  /* নফল/নিষিদ্ধ দিনের পরিচয় */
  function kindOf(d) {
    var h = hp(d); if (!h) return null;
    if ((h.m === 10 && h.d === 1) || (h.m === 12 && h.d >= 10 && h.d <= 13)) return { haram: true, t: h.m === 10 ? 'ঈদুল ফিতর — আজ রোজা রাখা নিষেধ' : (h.d === 10 ? 'ঈদুল আযহা' : 'আইয়ামে তাশরিক') + ' — আজ রোজা রাখা নিষেধ' };
    if (h.m === 9) return { ram: true, t: 'রমজানের রোজা' };
    if (h.m === 12 && h.d === 9) return { t: 'আরাফার রোজা', s: 'আগের ও পরের এক বছরের গুনাহ মাফের আশা (সহিহ মুসলিম)' };
    if (h.m === 1 && (h.d === 9 || h.d === 10 || h.d === 11)) return { t: 'আশুরার রোজা' + (h.d === 10 ? '' : ' (সাথের দিন)'), s: '১০ মুহাররমের সাথে ৯ বা ১১ মিলিয়ে রাখা সুন্নত' };
    if (h.m === 10) return { t: 'শাওয়ালের ছয় রোজা', s: 'রমজানের পর শাওয়ালে ছয়টি — সারা বছরের সওয়াব (সহিহ মুসলিম)' };
    if (h.d >= 13 && h.d <= 15) return { t: 'আইয়ামে বীযের রোজা', s: 'প্রতি হিজরি মাসের ১৩, ১৪ ও ১৫ তারিখ' };
    var wd = d.getDay();
    if (wd === 1 || wd === 4) return { t: (wd === 1 ? 'সোমবারের' : 'বৃহস্পতিবারের') + ' রোজা', s: 'এই দুই দিন আমল আল্লাহর কাছে পেশ করা হয় (তিরমিজি)' };
    return { t: 'নফল রোজা', s: '' };
  }

  var tab = '', ramYear = 0;
  function pickTab() {
    if (tab) return tab;
    var h = hp(new Date()); return (h && (h.m === 9 || (h.m === 10 && h.d <= 15))) ? 'ram' : (owed(load()) > 0 ? 'qaza' : 'ram');
  }

  function statsHtml(o) {
    var R = ramadans(), h = hp(new Date()) || { y: 0, m: 0 }, y = h.m >= 9 ? h.y : h.y - 1, kept = 0;
    var r = o.ram[y] || {}; Object.keys(r).forEach(function (k) { if (r[k] === 'k') kept++; });
    var naflYear = Object.keys(o.nafl).filter(function (k) { var x = hp(ui.parseKey(k)); return x && x.y === h.y; }).length;
    return '<div class="pt-stats tk-stats">' +
      '<div class="pt-stat"><div class="pt-stat__value">' + bn(owed(o)) + '</div><div class="pt-stat__label">কাজা বাকি</div></div>' +
      '<div class="pt-stat"><div class="pt-stat__value">' + bn(kept) + '<small>/' + bn((R[y] || []).filter(Boolean).length || 30) + '</small></div><div class="pt-stat__label">রমজান ' + bn(y) + '</div></div>' +
      '<div class="pt-stat"><div class="pt-stat__value">' + bn(naflYear) + '</div><div class="pt-stat__label">নফল (' + bn(h.y) + ')</div></div></div>';
  }

  function ramHtml(o) {
    var R = ramadans(), h = hp(new Date()) || { y: 0, m: 0 };
    var tday = noon(new Date());
    var years = Object.keys(R).map(Number).filter(function (y) { return R[y][0] && noon(R[y][0]) <= tday; }).sort();   /* শুধু যে রমজান শুরু হয়েছে */
    var cur = h.m >= 9 ? h.y : h.y - 1;
    if (!ramYear || years.indexOf(ramYear) < 0) ramYear = years.indexOf(cur) >= 0 ? cur : years[years.length - 1];
    var out = '';
    var next = R[h.y] && h.m < 9 ? R[h.y][0] : null;
    if (next) {
      var left = Math.round((noon(next) - noon(new Date())) / 86400000);
      out += ui.notice('', 'রমজান আসছে', 'রমজান ' + bn(h.y) + ' শুরু হতে আর প্রায় <b>' + bn(left) + ' দিন</b> (আনুমানিক ' + ui.dateBn(next) + ', চাঁদ দেখার ওপর নির্ভরশীল)। নিচে গত রমজানের হিসাব।');
    }
    if (years.length > 1) out += ui.chips('ry', years.map(function (y) { return [y, 'রমজান ' + bn(y)]; }), ramYear);
    var days = (R[ramYear] || []), today = noon(new Date());
    var cnt = { k: 0, m: 0, e: 0 };
    var cells = '';
    for (var n = 1; n <= 30; n++) {
      var d = days[n - 1];
      if (!d) { if (n === 30) break; continue; }
      var st = dayState(o, ramYear, n, d), fut = noon(d) > today, isToday = noon(d).getTime() === today.getTime();
      if (cnt[st] != null) cnt[st]++;
      var lab = st === 'k' ? 'রেখেছি' : st === 'm' ? 'ছুটেছে' : st === 'e' ? 'মাজুর' : fut ? 'সামনে' : 'চিহ্ন দিন';
      cells += '<button type="button" class="tk-day is-' + (st || (fut ? 'fut' : 'none')) + (isToday ? ' is-today' : '') + '"' + (fut ? ' disabled' : '') +
        ' data-act="rd" data-v="' + n + '" aria-label="রমজান ' + bn(n) + ', ' + ui.dateBn(d) + ': ' + lab + '">' +
        '<b>' + bn(n) + '</b><small>' + bn(d.getDate()) + '</small>' + (st === 'k' ? ic('check', 'tk-dic') : st === 'm' ? ic('close', 'tk-dic') : st === 'e' ? ic('drop', 'tk-dic') : '') + '</button>';
    }
    out += '<div class="tk-days">' + cells + '</div>' +
      '<div class="tk-legend"><span class="is-k">' + ic('check') + 'রেখেছি ' + bn(cnt.k) + '</span><span class="is-m">' + ic('close') + 'ছুটেছে ' + bn(cnt.m) + '</span><span class="is-e">' + ic('drop') + 'মাজুর ' + bn(cnt.e) + '</span></div>' +
      '<p class="tk-fine">' + ic('info') + 'ঘরে চাপ দিন: রেখেছি → ছুটেছে → খালি। "ছুটেছে" ও "মাজুর" দিনগুলো কাজার হিসাবে যোগ হয়। তারিখ আনুমানিক — আপনার এলাকার চাঁদ দেখা অনুযায়ী এক দিন আগে-পরে হতে পারে (সেটিংসে হিজরি সমন্বয়)।</p>';
    return out;
  }

  function qazaHtml(o) {
    var today = ui.dkey(), doneToday = o.paid.indexOf(today) >= 0, kd = kindOf(new Date());
    var ow = owed(o), ro = ramOwed(o);
    return '<div class="tk-big"><b>' + bn(ow) + '</b><span>কাজা রোজা বাকি</span></div>' +
      '<div class="tk-break">' +
        ui.row('আগের বছরগুলোর জমা', 'অ্যাপ ব্যবহারের আগের হিসাব নিজে বসান',
          '<span class="tk-step"><button type="button" class="pt-iconbtn" data-act="base" data-v="-1" aria-label="কমান">' + ic('minus') + '</button><b>' + bn(o.base) + '</b><button type="button" class="pt-iconbtn" data-act="base" data-v="1" aria-label="বাড়ান">' + ic('plus') + '</button></span>') +
        ui.row('রমজানে ছুটেছে ও মাজুর', 'রমজানের ঘর থেকে নিজে থেকে', '<b class="tk-num">+' + bn(ro) + '</b>') +
        ui.row('আদায় করেছেন', 'নিচের বোতাম দিয়ে যোগ হয়', '<b class="tk-num">−' + bn(o.paid.length) + '</b>') +
      '</div>' +
      (kd && kd.haram ? ui.notice('warning', '', kd.t + '।') :
        '<button type="button" class="pt-btn pt-btn--block tk-cta" data-act="paid"' + (doneToday || ow <= 0 ? ' disabled' : '') + '>' + ic('check-circle') +
        (doneToday ? 'আজকের কাজা রোজা যোগ হয়েছে' : ow <= 0 ? 'কোনো কাজা বাকি নেই — আলহামদুলিল্লাহ' : 'আজ একটি কাজা রোজা রাখছি') + '</button>') +
      (o.paid.length ? '<div class="tk-lbl tk-lbl--sm">আদায়ের তারিখ</div><div class="tk-hist">' + o.paid.slice(-8).reverse().map(function (k) {
        return '<div class="tk-hrow"><span>' + ui.dateBn(k) + ' ' + ui.parseKey(k).getFullYear() + '</span><button type="button" class="tk-x" data-act="paiddel" data-v="' + k + '" aria-label="মুছুন">' + ic('close') + '</button></div>';
      }).join('') + '</div>' : '') +
      '<p class="tk-fine">' + ic('info') + 'কাজা রোজা যেকোনো দিন রাখা যায় (দুই ঈদ ও তাশরিকের দিন ছাড়া); পরের রমজানের আগে আদায় করে নেওয়া উত্তম। কাফফারা (ইচ্ছাকৃত ভাঙলে) আলাদা বিষয় — আলেমের পরামর্শ নিন।</p>';
  }

  function naflHtml(o) {
    var now = new Date(), k = kindOf(now), today = ui.dkey(), on = !!o.nafl[today], h = hp(now) || {};
    var out = ui.card({ cls: 'tk-today', icon: 'iftar', title: 'আজ ' + ui.dateBn(now) + (h.d ? ' · ' + bn(h.d) + ' ' + HM[h.m - 1] : ''), sub: k ? k.t : '',
      body: (k && k.s ? '<p class="tk-p">' + k.s + '</p>' : '') +
        (k && k.haram ? ui.notice('warning', '', 'আজ রোজা রাখা নিষেধ।') : k && k.ram ? ui.notice('', '', 'রমজানের রোজার হিসাব "রমজান" ট্যাবে।') :
          '<button type="button" class="pt-btn pt-btn--block' + (on ? ' pt-btn--tonal' : '') + ' tk-cta" data-act="nafl">' + ic(on ? 'check-circle' : 'plus') + (on ? 'আজ রোজা রাখছি — আলহামদুলিল্লাহ (চাপলে সরবে)' : 'আজ নফল রোজা রাখছি') + '</button>') });
    if (h.m === 10) {
      var six = Object.keys(o.nafl).filter(function (d) { var x = hp(ui.parseKey(d)); return x && x.m === 10 && x.y === h.y; }).length;
      out += '<div class="tk-prog"><span>শাওয়ালের ছয় রোজা</span><b>' + bn(Math.min(6, six)) + '/৬</b><div class="pt-progress pt-progress--gold"><div class="pt-progress__fill" style="width:' + Math.min(100, six / 6 * 100) + '%"></div></div></div>';
    }
    var up = [], d = noon(now);
    for (var i = 1; i <= 35 && up.length < 8; i++) {
      d.setDate(d.getDate() + 1);
      var kk = kindOf(d); if (!kk || kk.haram || kk.ram || kk.t === 'নফল রোজা') continue;
      if (/সোমবারের|বৃহস্পতিবারের/.test(kk.t) && up.filter(function (u) { return /সোমবারের|বৃহস্পতিবারের/.test(u.t); }).length >= 3) continue;
      up.push({ d: new Date(d), t: kk.t });
    }
    out += '<div class="tk-lbl">সামনের সুন্নত রোজা</div><div class="tk-hist">' + up.map(function (u) {
      var x = hp(u.d) || {};
      return '<div class="tk-hrow"><span><b>' + u.t + '</b><small>' + ui.dateBn(u.d) + (x.d ? ' · ' + bn(x.d) + ' ' + HM[x.m - 1] : '') + '</small></span></div>';
    }).join('') + '</div>' +
      '<button type="button" class="pt-btn pt-btn--ghost pt-btn--block" data-go="reminders">' + ic('bell') + 'সোম-বৃহস্পতি ও আইয়ামে বীযের রিমাইন্ডার</button>';
    return out;
  }

  function render(el) {
    var o = load(), t = pickTab();
    el.innerHTML = '<div class="tk-wrap">' + statsHtml(o) +
      ui.seg('tab', [['ram', 'রমজান'], ['qaza', 'কাজা'], ['nafl', 'নফল']], t) +
      '<div class="tk-pane">' + (t === 'ram' ? ramHtml(o) : t === 'qaza' ? qazaHtml(o) : naflHtml(o)) + '</div></div>';
  }

  T.register('fasting', {
    title: 'রোজার হিসাব', sub: 'রমজান · কাজা · নফল রোজা', icon: 'iftar', group: 'fasting', order: 10,
    hub: { t: 'রোজার হিসাব', s: 'রমজানের ঘর, কাজার হিসাব, সুন্নত রোজার দিন' },
    render: function (el, u, arg) { if (arg) tab = arg; render(el); },
    onEvent: function (kind, name, v) {
      var o = load();
      if (kind === 'seg' && name === 'tab') { tab = v; }
      else if (kind === 'chip' && name === 'ry') { ramYear = +v; }
      else if (kind === 'act' && name === 'rd') {
        var n = +v, y = String(ramYear), r = o.ram[y] = o.ram[y] || {};
        var d = (ramadans()[ramYear] || [])[n - 1], st = dayState(o, ramYear, n, d);
        var nx = st === '' || st === 'e' ? 'k' : st === 'k' ? 'm' : '';
        if (nx) r[n] = nx; else delete r[n];
        save(o); ui.haptic('light');
      }
      else if (kind === 'act' && name === 'base') { o.base = Math.max(0, Math.min(9999, o.base + (+v))); save(o); }
      else if (kind === 'act' && name === 'paid') { var t = ui.dkey(); if (o.paid.indexOf(t) < 0) { o.paid.push(t); o.paid.sort(); save(o); ui.toast('কাজা রোজা যোগ হলো — আল্লাহ কবুল করুন', { type: 'success' }); } }
      else if (kind === 'act' && name === 'paiddel') { o.paid = o.paid.filter(function (k) { return k !== v; }); save(o); }
      else if (kind === 'act' && name === 'nafl') {
        var td = ui.dkey(); if (o.nafl[td]) delete o.nafl[td]; else { o.nafl[td] = 1; ui.toast('আল্লাহ আপনার রোজা কবুল করুন', { type: 'success' }); }
        save(o);
      }
      else return;
      ui.rerender();
    }
  });
})();
