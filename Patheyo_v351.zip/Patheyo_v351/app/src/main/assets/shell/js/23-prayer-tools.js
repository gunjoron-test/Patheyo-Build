/* =============================================================================
   v347: নামাজের সহায়ক টুল
     tool:jamaat  — মসজিদের জামাতের সময় (প্রতি ওয়াক্ত: আজানের X মিনিট পরে / নির্দিষ্ট সময়; জুম’আ আলাদা) + আগে মনে করানো
                    নামাজের সময় ফোন নীরব (ভাইব্রেট / পুরো নীরব) — নেটিভ: reminder/PrayerTools.kt (অ্যাপ বন্ধ থাকলেও চলে)
     tool:status  — সফর (কসর) মোড ও মাজুর অবস্থা
   হোমে: "আজকের নামাজ"-এর নিচে এক লাইনের তথ্য (#wq-info): পরের জামাত · সফর · মাজুর।
   ডেটা: ptu_jamaat, ptu_silent, ptu_safar (ক্লাউডে যায়) · pt_excused_v1 (শুধু এই ফোনে — ব্যক্তিগত, ক্লাউডে যায় না)।
   মাজুর অবস্থায় ওয়াক্ত শেষে "পড়া হয়নি" বসে না (shell/js/09-home.js → window.__ptExcused)।
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic;
  var IDS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  var NAME = { fajr: 'ফজর', dhuhr: 'যোহর', asr: 'আসর', maghrib: 'মাগরিব', isha: 'এশা' };

  /* ---------------------------------------------------------------- ডেটা */
  var JAM_DEF = { on: false, remind: 10, jumuah: '13:30',
    w: { fajr: { m: 'after', v: 20 }, dhuhr: { m: 'after', v: 15 }, asr: { m: 'after', v: 15 }, maghrib: { m: 'after', v: 5 }, isha: { m: 'after', v: 15 } } };
  var SIL_DEF = { on: false, mode: 'vibrate', from: 'jamaat', after: 10, dur: 20, jdur: 45, w: { fajr: true, dhuhr: true, asr: true, maghrib: true, isha: true } };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function merge(def, v) { var o = clone(def); if (v && typeof v === 'object') for (var k in v) if (v[k] != null) o[k] = (typeof def[k] === 'object' && !Array.isArray(def[k])) ? merge(def[k], v[k]) : v[k]; return o; }
  function jam() { return merge(JAM_DEF, ui.get('ptu_jamaat', null)); }
  function sil() { return merge(SIL_DEF, ui.get('ptu_silent', null)); }
  function nat() { try { var b = W.PatheyoPrayerTools; return b && typeof b.save === 'function' ? b : null; } catch (e) { return null; } }
  function pushNative() { var b = nat(); if (!b) return; try { b.save(JSON.stringify({ jamaat: jam(), silent: sil() })); } catch (e) {} }
  function natState() { try { var b = nat(); return b ? JSON.parse(b.state() || '{}') : {}; } catch (e) { return {}; } }
  function saveJam(o) { ui.set('ptu_jamaat', o); pushNative(); changed(); }
  function saveSil(o) { ui.set('ptu_silent', o); pushNative(); changed(); }
  function changed() { try { W.dispatchEvent(new CustomEvent('pt:prayertools')); } catch (e) {} paintInfo(); }

  /* মাজুর: [{f: শুরু (ms), t: শেষ (ms) | null = চলছে}] — শুধু এই ফোনে */
  var EXK = 'pt_excused_v1';
  function exc() { var o = ui.get(EXK, null); return o && Array.isArray(o.p) ? o : { p: [] }; }
  function excSave(o) { o.p = o.p.slice(-24); ui.set(EXK, o); changed(); }
  function excActive() { var p = exc().p, l = p[p.length - 1]; return l && !l.t ? l : null; }
  function excAt(ms) { return exc().p.some(function (r) { return ms >= r.f && (!r.t || ms <= r.t); }); }
  W.__ptExcused = { at: excAt, active: function () { return !!excActive(); }, periods: function () { return exc().p.slice(); } };

  function safar() { var o = ui.get('ptu_safar', null); return o && typeof o === 'object' ? o : { on: false }; }
  function hanafi() { try { return (localStorage.getItem('currentMadhab') || '1') !== '0'; } catch (e) { return true; } }

  /* আজকের আজান (দিনের শুরু থেকে মিনিট) — হোমের WAQT ইঞ্জিন (namaz পেজের/অফলাইন হিসাবের একই সময়) */
  function azanMin(i) { var Wq = W.WAQT; return Wq && Wq.ready && Wq.starts.length === 5 ? Math.round(Wq.starts[i] / 60) : null; }
  function isFri() { return new Date().getDay() === 5; }
  function jamaatMin(i, j, fri) {
    j = j || jam(); var k = IDS[i];
    if (k === 'dhuhr' && (fri === undefined ? isFri() : fri) && j.jumuah) return ui.toMin(j.jumuah);
    var w = j.w[k] || {}, a = azanMin(i);
    if (w.m === 'at') return ui.toMin(w.t);
    if (w.m === 'after' && a != null) return a + (+w.v || 0);
    return null;
  }
  W.__ptJamaat = { min: jamaatMin, on: function () { return jam().on; } };

  /* ---------------------------------------------------------------- হোমের এক লাইনের তথ্য */
  var info = null;
  function ensureInfo() {
    if (info) return info;
    var strip = D.querySelector('.hub-waqt-strip'); if (!strip) return null;
    info = D.createElement('div'); info.id = 'wq-info'; info.className = 'wq-info'; info.hidden = true;
    strip.parentNode.insertBefore(info, strip.nextSibling);
    info.addEventListener('click', function (e) { var b = e.target.closest('[data-go]'); if (!b) return; });
    return info;
  }
  function paintInfo() {
    var el = ensureInfo(); if (!el) return;
    var parts = [];
    if (excActive()) parts.push('<button type="button" class="wq-i wq-i--exc" data-go="tool:status">' + ic('drop') + '<span>মাজুর অবস্থা চলছে — নামাজের চিহ্ন বসছে না</span></button>');
    var s = safar();
    if (s.on) parts.push('<button type="button" class="wq-i wq-i--saf" data-go="tool:status">' + ic('plane') + '<span>সফরে আছেন — যোহর, আসর ও এশা <b>২ রাকাত</b> (কসর)</span></button>');
    var j = jam();
    if (j.on && W.WAQT && W.WAQT.ready) {
      var now = new Date(), nm = now.getHours() * 60 + now.getMinutes(), best = null;
      for (var i = 0; i < 5; i++) { var m = jamaatMin(i, j); if (m != null && m >= nm && (best === null || m < best.m)) best = { i: i, m: m }; }
      if (best) {
        var left = best.m - nm, nmName = (IDS[best.i] === 'dhuhr' && isFri() && j.jumuah) ? 'জুম’আ' : NAME[IDS[best.i]];
        var lt = left < 1 ? 'এখনই' : left < 60 ? 'আর ' + bn(left) + ' মিনিট' : 'আর ' + bn(Math.floor(left / 60)) + ' ঘণ্টা ' + (left % 60 ? bn(left % 60) + ' মিনিট' : '');
        parts.push('<button type="button" class="wq-i wq-i--jam" data-go="tool:jamaat">' + ic('users') + '<span>পরের জামাত · <b>' + nmName + ' ' + ui.t12(best.m) + '</b> · ' + lt + '</span></button>');
      }
    }
    var html = parts.join('');
    if (el.__h !== html) { el.__h = html; el.innerHTML = html; el.hidden = !html; }
  }
  setInterval(function () { if (!D.hidden) paintInfo(); }, 30000);
  W.addEventListener('storage', function (e) { if (e.key === 'ptu_jamaat' || e.key === 'ptu_safar' || e.key === EXK) paintInfo(); });
  D.addEventListener('visibilitychange', function () { if (!D.hidden) paintInfo(); });
  setTimeout(function () { paintInfo(); pushNative(); }, 2500);        /* অ্যাপ খুললেই নেটিভকে শেষ সেটিংস (নতুন ফোনে রিস্টোরের পরও) */
  var tries = 0, iv = setInterval(function () { if ((W.WAQT && W.WAQT.ready) || ++tries > 40) { clearInterval(iv); paintInfo(); } }, 500);

  /* ================================================================= tool:jamaat */
  var openW = '';      /* কোন ওয়াক্তের সম্পাদক খোলা */
  function waqtRow(i, j) {
    var k = IDS[i], w = j.w[k] || { m: 'off' }, a = azanMin(i), jm = jamaatMin(i, j, false);
    var val = w.m === 'off' ? '<span class="tk-muted">বন্ধ</span>' : jm == null ? '—' : '<b>' + ui.t12(jm) + '</b>';
    var sub = (a != null ? 'আজান ' + ui.t12(a) : 'আজানের সময় পাওয়া যায়নি') + (w.m === 'after' ? ' · আজানের ' + bn(w.v) + ' মিনিট পরে' : w.m === 'at' ? ' · নির্দিষ্ট সময়' : '');
    var open = openW === k;
    var ed = '';
    if (open) {
      ed = '<div class="tk-ed">' + ui.seg('jm:' + k, [['after', 'আজানের পরে'], ['at', 'নির্দিষ্ট সময়'], ['off', 'বন্ধ']], w.m) +
        (w.m === 'after' ? '<div class="tk-lbl">আজানের কত মিনিট পরে জামাত?</div>' + ui.chips('jv:' + k, [5, 10, 15, 20, 25, 30, 45], w.v) : '') +
        (w.m === 'at' ? '<button type="button" class="pt-btn pt-btn--tonal pt-btn--sm tk-tbtn" data-act="jt" data-v="' + k + '">' + ic('clock') + (w.t ? ui.t12(w.t) + ' — বদলান' : 'সময় বাছুন') + '</button>' : '') +
        (jm != null && a != null && jm < a ? ui.notice('warning', '', 'জামাতের সময় আজানের আগে পড়েছে — সময়টি আবার দেখে নিন।') : '') + '</div>';
    }
    return '<div class="tk-wq' + (open ? ' is-open' : '') + '"><button type="button" class="tk-wqh" data-act="jw" data-v="' + k + '" aria-expanded="' + open + '">' +
      '<span class="tk-wqn">' + NAME[k] + '</span><span class="tk-rt"><span class="tk-wqv">' + val + '</span><small>' + sub + '</small></span>' + ic(open ? 'chev-up' : 'chev-down', 'tk-chev') + '</button>' + ed + '</div>';
  }
  function renderJamaat(el) {
    var j = jam(), s = sil(), st = natState(), hasNat = !!nat();
    var jamBody = !j.on ? '<p class="tk-p">নিজের মসজিদের জামাতের সময় বসিয়ে রাখুন — হোমে "পরের জামাত" দেখাবে, আর জামাতের আগে মনে করিয়ে দেবে।</p>' :
      '<div class="tk-wqs">' + IDS.map(function (k, i) { return waqtRow(i, j); }).join('') + '</div>' +
      ui.row('জুম’আর জামাত', j.jumuah ? 'শুক্রবার যোহরের বদলে এই সময়' : 'শুক্রবারও যোহরের নিয়মে',
        '<button type="button" class="pt-btn pt-btn--tonal pt-btn--sm" data-act="jumuah">' + (j.jumuah ? ui.t12(j.jumuah) : 'সময় দিন') + '</button>') +
      '<div class="tk-lbl">জামাতের কত মিনিট আগে মনে করাবে?</div>' + ui.chips('remind', [[0, 'বন্ধ'], 5, 10, 15, 20, 30], j.remind) +
      (hasNat ? '' : ui.notice('', '', 'মনে করানো ও নীরব করার সুবিধা অ্যাপে কাজ করে (ব্রাউজারে নয়)।'));

    var silBody = '';
    if (!s.on) silBody = '<p class="tk-p">নামাজের সময় ফোন নিজে থেকে ভাইব্রেটে/নীরবে যাবে, শেষ হলে আগের অবস্থায় ফিরবে। জামাতে মোবাইলের শব্দে আর বিব্রত হতে হবে না।</p>';
    else {
      var useJam = j.on && s.from === 'jamaat';
      silBody =
        (st.silentNow ? ui.notice('success', 'এখন ফোন নীরব আছে', st.until ? ui.t12(new Date(st.until).getHours() * 60 + new Date(st.until).getMinutes()) + ' পর্যন্ত — তারপর নিজে থেকে আগের অবস্থায় ফিরবে।' : '',
          '<button type="button" class="pt-btn pt-btn--sm tk-nbtn" data-act="silend">এখনই চালু করুন</button>') : '') +
        '<div class="tk-lbl">কীভাবে নীরব হবে?</div>' + ui.seg('mode', [['vibrate', 'ভাইব্রেট'], ['silent', 'পুরো নীরব']], s.mode) +
        (s.mode === 'silent' && hasNat && !st.dnd ? ui.notice('warning', 'একটি অনুমতি লাগবে', 'পুরো নীরব করতে Android-এর "বিরক্ত করবেন না" অনুমতি দিন। না দিলে শুধু ভাইব্রেট হবে।',
          '<button type="button" class="pt-btn pt-btn--sm tk-nbtn" data-act="dnd">অনুমতি দিন</button>') : '') +
        '<div class="tk-lbl">কখন শুরু?</div>' +
        (j.on ? ui.seg('from', [['jamaat', 'জামাতের ২ মিনিট আগে'], ['azan', 'আজানের পরে']], s.from) : '') +
        (!useJam ? '<div class="tk-lbl tk-lbl--sm">আজানের কত মিনিট পরে?</div>' + ui.chips('after', [0, 5, 10, 15, 20, 30], s.after) : '') +
        '<div class="tk-lbl">কতক্ষণ নীরব থাকবে?</div>' + ui.chips('dur', [10, 15, 20, 30, 45, 60], s.dur) +
        '<div class="tk-lbl tk-lbl--sm">জুম’আর দিন যোহরে</div>' + ui.chips('jdur', [30, 45, 60, 90], s.jdur) +
        '<div class="tk-lbl">কোন কোন ওয়াক্তে?</div><div class="tk-chips">' + IDS.map(function (k) {
          return '<button type="button" class="pt-chip tk-chip' + (s.w[k] !== false ? ' is-on' : '') + '" aria-pressed="' + (s.w[k] !== false) + '" data-act="sw-w" data-v="' + k + '">' + NAME[k] + '</button>';
        }).join('') + '</div>' +
        '<p class="tk-fine">' + ic('info') + 'শুরুর সময় ফোন রিং-মোডে থাকলে তবেই বদলায়, আর শেষে ফেরত দেয় শুধু যদি মাঝে আপনি নিজে না বদলান — আপনার নিজের সেটিং কখনো নষ্ট হয় না।</p>';
    }
    el.innerHTML = '<div class="tk-wrap">' +
      ui.card({ icon: 'users', title: 'মসজিদের জামাতের সময়', sub: 'হোমে পরের জামাত ও আগে মনে করানো', right: ui.sw('jam', j.on, 'জামাতের সময়'), body: jamBody }) +
      ui.card({ icon: 'phone-off', title: 'নামাজের সময় ফোন নীরব', sub: 'নিজে থেকে নীরব, নিজে থেকে চালু', right: ui.sw('sil', s.on, 'নামাজের সময় ফোন নীরব'), body: silBody }) +
      '</div>';
  }
  T.register('jamaat', {
    title: 'জামাত ও সাইলেন্ট', sub: 'মসজিদের জামাতের সময় · নামাজে নীরব ফোন', icon: 'users', group: 'prayer', order: 10,
    hub: { t: 'জামাত ও সাইলেন্ট', s: 'মসজিদের সময়, জামাতের আগে মনে করানো, নীরব ফোন' },
    render: function (el) { renderJamaat(el); },
    onEvent: function (kind, name, v, node) {
      var j = jam(), s = sil();
      if (kind === 'sw' && name === 'jam') { j.on = v; saveJam(j); ui.toast(v ? 'জামাতের সময় চালু — নিচে প্রতি ওয়াক্তের সময় মিলিয়ে নিন' : 'জামাতের সময় বন্ধ', { type: v ? 'success' : '' }); }
      else if (kind === 'sw' && name === 'sil') { s.on = v; saveSil(s); ui.toast(v ? 'চালু হলো — নামাজের সময় ফোন নিজে থেকে নীরব হবে, ইনশাআল্লাহ' : 'বন্ধ হলো', { type: v ? 'success' : '' }); }
      else if (kind === 'act' && name === 'jw') { openW = openW === v ? '' : v; }
      else if (kind === 'seg' && name.indexOf('jm:') === 0) {
        var k = name.slice(3), w = j.w[k] || {}; w.m = v;
        if (v === 'after' && !(w.v >= 0)) w.v = 15;
        j.w[k] = w; saveJam(j);
        if (v === 'at' && !w.t) { renderJamaat(D.getElementById('tool-body')); hydrate(); return pick(k); }
      }
      else if (kind === 'chip' && name.indexOf('jv:') === 0) { j.w[name.slice(3)].v = +v; saveJam(j); }
      else if (kind === 'act' && name === 'jt') return pick(v);
      else if (kind === 'act' && name === 'jumuah') {
        ui.pickTime(j.jumuah || '13:30', function (t) { var o = jam(); o.jumuah = t; saveJam(o); ui.toast('জুম’আর জামাত ' + ui.t12(t), { type: 'success' }); ui.rerender(); });
        return;
      }
      else if (kind === 'chip' && name === 'remind') { j.remind = +v; saveJam(j); }
      else if (kind === 'seg' && name === 'mode') { s.mode = v; saveSil(s); }
      else if (kind === 'seg' && name === 'from') { s.from = v; saveSil(s); }
      else if (kind === 'chip' && (name === 'after' || name === 'dur' || name === 'jdur')) { s[name] = +v; saveSil(s); }
      else if (kind === 'act' && name === 'sw-w') { s.w[v] = s.w[v] === false; if (!IDS.some(function (k) { return s.w[k] !== false; })) { s.w[v] = true; ui.toast('অন্তত একটি ওয়াক্ত রাখুন'); } saveSil(s); }
      else if (kind === 'act' && name === 'dnd') { try { nat().openDndSettings(); } catch (e) {} setTimeout(ui.rerender, 1500); return; }
      else if (kind === 'act' && name === 'silend') { try { nat().endSilentNow(); } catch (e) {} ui.toast('ফোন আগের অবস্থায় ফিরেছে'); setTimeout(ui.rerender, 300); return; }
      else return;
      ui.rerender();
    }
  });
  function hydrate() { var b = D.getElementById('tool-body'); if (W.PT && PT.hydrateIcons && b) PT.hydrateIcons(b); }
  function pick(k) {
    var j = jam(), cur = (j.w[k] && j.w[k].t) || ui.hhmm((azanMin(IDS.indexOf(k)) || 780) + 15);
    ui.pickTime(cur, function (t) {
      var o = jam(); o.w[k] = { m: 'at', t: t }; saveJam(o);
      var a = azanMin(IDS.indexOf(k));
      ui.toast(NAME[k] + '-এর জামাত ' + ui.t12(t) + (a != null && ui.toMin(t) < a ? ' — আজানের আগে পড়েছে, দেখে নিন' : ''), { type: 'success' });
      ui.rerender();
    });
  }

  /* ================================================================= tool:status — সফর ও মাজুর */
  var showOther = false;
  function qasrRules(h) {
    var li = function (a) { return '<ul class="tk-ul">' + a.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>'; };
    return h ? li([
      'চার রাকাতের ফরজ — যোহর, আসর ও এশা — <b>দুই রাকাত</b> পড়বেন (কসর)। হানাফি মতে কসর করা <b>ওয়াজিব</b>।',
      'ফজর (২) ও মাগরিব (৩) পুরোটাই পড়বেন। বিতর বাদ দেবেন না।',
      'সুন্নত: সময় ও সুযোগ থাকলে পড়বেন; তাড়া থাকলে বাদ দেওয়া যায় — তবে ফজরের সুন্নত যত্নসহ পড়বেন।',
      'সফর ধরা হয় নিজের এলাকা থেকে প্রায় <b>৭৮ কিমি</b> (৪৮ মাইল) বা তার বেশি দূরে যাওয়ার নিয়তে বের হলে।',
      'কোথাও <b>১৫ দিন বা বেশি</b> থাকার নিয়ত করলে সেখানে মুকিম — তখন পুরো নামাজ।',
      'মুকিম ইমামের পেছনে জামাতে পড়লে ইমামের মতো পুরো চার রাকাত পড়বেন।',
      'দুই ওয়াক্ত একসাথে (জমা) পড়া হানাফি মতে আরাফা ও মুযদালিফা ছাড়া নয়; প্রতিটি নিজের ওয়াক্তে পড়বেন।'
    ]) : li([
      'চার রাকাতের ফরজ — যোহর, আসর ও এশা — <b>দুই রাকাত</b> পড়া যায় (কসর); শাফেয়ি, মালিকি ও হাম্বলি মতে এটি ছাড় (রুখসত), উত্তম।',
      'ফজর ও মাগরিব পুরোটাই।',
      'সফর ধরা হয় প্রায় <b>৮১ কিমি</b> বা তার বেশি দূরত্বে।',
      'কোথাও আসা-যাওয়ার দিন বাদে <b>৪ দিনের বেশি</b> থাকার নিয়ত করলে পুরো নামাজ।',
      'যোহর-আসর এবং মাগরিব-এশা একসাথে (জমা) — আগে বা পরের ওয়াক্তে — পড়া জায়েজ।'
    ]);
  }
  function daysSince(k) { return Math.max(0, Math.round((ui.parseKey(ui.dkey()) - ui.parseKey(k)) / 86400000)); }
  function renderStatus(el) {
    var s = safar(), h = hanafi(), view = showOther ? !h : h;
    var limit = h ? 15 : 4, d = s.on && s.since ? daysSince(s.since) : 0;
    var safBody = (s.on ? '<div class="tk-statline">' + ic('calendar') + '<span>' + ui.dateBn(s.since) + ' থেকে · ' + (d ? bn(d) + ' দিন' : 'আজ শুরু') + '</span></div>' +
        '<div class="tk-lbl tk-lbl--sm">সফর শুরু হয়েছে</div>' + ui.chips('safsince', [[0, 'আজ'], [1, 'গতকাল'], [2, '২ দিন আগে'], [3, '৩ দিন আগে']], d > 3 ? -1 : d) +
        (d >= limit ? ui.notice('warning', bn(limit) + ' দিন পেরিয়েছে', 'এক জায়গায় ' + bn(limit) + (h ? ' দিন বা বেশি' : ' দিনের বেশি') + ' থাকার নিয়ত থাকলে আপনি এখন মুকিম — পুরো নামাজ পড়বেন। ফিরে এসে থাকলে সফর মোড বন্ধ করুন।',
          '<button type="button" class="pt-btn pt-btn--sm tk-nbtn" data-act="safend">সফর শেষ</button>') : '')
      : '<p class="tk-p">সফরে বের হলে চালু করুন — হোমে কসরের কথা মনে করিয়ে দেবে, আর নিচে নিয়মগুলো এক নজরে।</p>') +
      '<div class="tk-rules"><div class="tk-rules-h"><b>' + ic('book') + 'কসরের নিয়ম — ' + (view ? 'হানাফি মাযহাব' : 'শাফেয়ি, মালিকি ও হাম্বলি') + '</b>' +
        '<button type="button" class="tk-link" data-act="other">' + (view ? 'অন্য মাযহাব' : 'হানাফি মাযহাব') + '</button></div>' + qasrRules(view) + '</div>';

    var a = excActive(), list = exc().p.filter(function (r) { return r.t; }).slice(-4).reverse();
    var excDays = a ? Math.max(0, Math.floor((Date.now() - a.f) / 86400000)) : 0;
    var excBody = (a ? '<div class="tk-statline">' + ic('drop') + '<span>' + ui.dateBn(new Date(a.f)) + ' থেকে · ' + (excDays ? bn(excDays) + ' দিন' : 'আজ শুরু') + '</span></div>' +
        '<div class="tk-lbl tk-lbl--sm">কবে থেকে?</div>' + ui.chips('excsince', [[0, 'আজ'], [1, 'গতকাল'], [2, '২ দিন আগে'], [3, '৩ দিন আগে']], excDays > 3 ? -1 : excDays)
      : '<p class="tk-p">মাজুর অবস্থায় (হায়েজ বা নিফাস) নামাজ মাফ — পরে কাজাও করতে হয় না। চালু থাকলে ওয়াক্ত শেষে "পড়া হয়নি" বসবে না, আর কাজার হিসাবেও যোগ হবে না।</p>') +
      '<ul class="tk-ul tk-ul--sm"><li>নামাজ মাফ — পরে কাজা নেই।</li><li>রমজানের রোজা রাখা যায় না — পরে কাজা করতে হয়; রোজার হিসাবে এই দিনগুলো নিজে থেকেই কাজা হিসেবে যোগ হয়।</li><li>জিকির, দোয়া ও ইস্তেগফার চালিয়ে যেতে পারেন।</li></ul>' +
      (list.length ? '<div class="tk-lbl tk-lbl--sm">আগের হিসাব</div><div class="tk-hist">' + list.map(function (r, i) {
        var days = Math.max(1, Math.round((r.t - r.f) / 86400000));
        return '<div class="tk-hrow"><span>' + ui.dateBn(new Date(r.f)) + ' – ' + ui.dateBn(new Date(r.t)) + '</span><b>' + bn(days) + ' দিন</b><button type="button" class="tk-x" data-act="excdel" data-v="' + r.f + '" aria-label="মুছুন">' + ic('close') + '</button></div>';
      }).join('') + '</div>' : '') +
      '<p class="tk-fine">' + ic('lock') + 'এই তথ্য শুধু এই ফোনে থাকে — ক্লাউড ব্যাকআপে বা কোথাও পাঠানো হয় না।</p>';

    el.innerHTML = '<div class="tk-wrap">' +
      ui.card({ icon: 'plane', title: 'সফর (কসর) মোড', sub: 'সফরে নামাজ ছোট করার নিয়ম', right: ui.sw('saf', !!s.on, 'সফর মোড'), body: safBody }) +
      ui.card({ icon: 'drop', title: 'মাজুর অবস্থা', sub: 'মহিলাদের জন্য — নামাজের হিসাব থামানো', right: ui.sw('exc', !!a, 'মাজুর অবস্থা'), body: excBody }) +
      '<p class="tk-fine tk-fine--c">মাসআলায় সন্দেহ হলে নির্ভরযোগ্য আলেমের পরামর্শ নিন।</p></div>';
  }
  /* মাজুর শুরু পিছিয়ে দিলে ওই সময়ের নিজে-বসা "পড়া হয়নি" চিহ্নগুলো সরানো */
  function clearMissedFrom(fromMs) {
    var P = W.__ptPrayed; if (!P) return 0;
    var n = 0, d = new Date(fromMs); d.setHours(0, 0, 0, 0);
    var amolIds = ['fajr', 'midday', 'asr', 'maghrib', 'isha'];
    for (; d.getTime() <= Date.now(); d.setDate(d.getDate() + 1)) {
      var key = ui.dkey(d);
      amolIds.forEach(function (id) { try { if (P.get(key, id) === 'missed') { P.set(key, id, ''); n++; } } catch (e) {} });
    }
    return n;
  }
  T.register('status', {
    title: 'সফর ও মাজুর', sub: 'কসর ও বিশেষ অবস্থায় নামাজের হিসাব', icon: 'plane', group: 'prayer', order: 20,
    hub: { t: 'সফর ও মাজুর', s: 'কসরের নিয়ম, মাজুর অবস্থায় হিসাব থামানো' },
    render: function (el) { renderStatus(el); },
    onEvent: function (kind, name, v) {
      if (kind === 'sw' && name === 'saf') {
        ui.set('ptu_safar', v ? { on: true, since: ui.dkey() } : { on: false });
        ui.toast(v ? 'সফর মোড চালু — আল্লাহ আপনার সফর সহজ করুন' : 'সফর মোড বন্ধ — এখন পুরো নামাজ', { type: v ? 'success' : '' }); changed();
      }
      else if (kind === 'chip' && name === 'safsince') { var d0 = new Date(); d0.setDate(d0.getDate() - (+v)); ui.set('ptu_safar', { on: true, since: ui.dkey(d0) }); changed(); }
      else if (kind === 'act' && name === 'safend') { ui.set('ptu_safar', { on: false }); ui.toast('সফর মোড বন্ধ'); changed(); }
      else if (kind === 'act' && name === 'other') { showOther = !showOther; }
      else if (kind === 'sw' && name === 'exc') {
        var o = exc(), a = excActive();
        if (v && !a) { var now = Date.now(); o.p.push({ f: now, t: null }); excSave(o); ui.toast('মাজুর অবস্থা চালু — এখন থেকে "পড়া হয়নি" বসবে না'); }
        else if (!v && a) { a.t = Date.now(); excSave(o); ui.toast('মাজুর অবস্থা শেষ — আবার নামাজের হিসাব চলবে', { type: 'success' }); }
        if (W.__homePillsUpdated) W.__homePillsUpdated();
      }
      else if (kind === 'chip' && name === 'excsince') {
        var o2 = exc(), a2 = excActive(); if (!a2) return;
        var d1 = new Date(); d1.setDate(d1.getDate() - (+v)); d1.setHours(0, 0, 0, 0);
        a2.f = Math.min(Date.now(), d1.getTime()); excSave(o2);
        var n = clearMissedFrom(a2.f);
        if (n) ui.toast('এই সময়ের ' + bn(n) + 'টি "পড়া হয়নি" চিহ্ন সরানো হলো');
        if (W.__homePillsUpdated) W.__homePillsUpdated();
      }
      else if (kind === 'act' && name === 'excdel') { var o3 = exc(); o3.p = o3.p.filter(function (r) { return String(r.f) !== String(v) || !r.t; }); excSave(o3); }
      else return;
      ui.rerender();
    }
  });
})();
