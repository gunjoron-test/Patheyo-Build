/* =============================================================================
   v349: হিফজ মোড (tool:hifz) — অল্প অল্প করে মুখস্থ
   • আয়াতের লেখা আসে অ্যাপের নিজের কুরআন থেকে (কুরআন পেজের QuranApp.quranModel — পেছনে লোড হয়, পেজ খোলে না)।
     তাই আলাদা কোনো কপি নেই, ভুলের ঝুঁকিও নেই।
   • অডিও: কুরআন প্লেয়ারে বাছাই করা কারির কণ্ঠ (everyayah.com, প্লেয়ারের একই উৎস) — প্রতি আয়াত N বার, পুরো অংশ M বার।
   • লেখা দেখানো: পুরো · শুধু প্রথম শব্দ · লুকানো (চাপলে কয়েক সেকেন্ড দেখা যায়) — নিজেকে যাচাই।
   • "মুখস্থ হয়েছে" চিহ্ন ও অগ্রগতি: ptu_hifz = { sura:{ "112":[1,2,3,4] }, last:{ s, a, b } } (ক্লাউডে যায়)।
   ============================================================================= */
(function () {
  'use strict';
  var W = window, D = document, T = W.PTTools; if (!T) return;
  var ui = T.ui, bn = ui.bn, ic = ui.ic, esc = ui.esc;
  var BASE = 'https://everyayah.com/data/';
  var KEY = 'ptu_hifz';
  function pad3(n) { return ('00' + n).slice(-3); }

  function Q() { try { var w = W.__ptPages && W.__ptPages.frameWin('f1'); var A = w && w.QuranApp; return A && A.quranModel && A.quranModel.length === 114 ? { A: A, w: w } : null; } catch (e) { return null; } }
  function data() { var o = ui.get(KEY, null) || {}; return { sura: o.sura || {}, last: o.last || { s: 114, a: 1, b: 6 }, rep: +o.rep || 3, loop: o.loop == null ? 2 : +o.loop, gap: +o.gap || 0, view: o.view || 'full' }; }
  function save(o) { ui.set(KEY, o); }
  function memo(o, s) { return (o.sura[s] || []).slice(); }

  /* কারি: কুরআন প্লেয়ারের পছন্দ (pt_qa_prefs) — না পেলে আফাসি */
  function reciterFolder() {
    try {
      var q = Q(), pref = JSON.parse(localStorage.getItem('pt_qa_prefs') || '{}');
      var list = q && q.w.QuranAudio && q.w.QuranAudio.reciters;
      if (list) { var r = list.filter(function (x) { return x.id === pref.reciter; })[0] || list[0]; return { f: r.f, n: r.n }; }
    } catch (e) {}
    return { f: 'Alafasy_128kbps', n: 'মিশারি আল-আফাসি' };
  }
  /* সূরা ফাতিহা: অ্যাপের গণনা (৭ আয়াত) ↔ everyayah ফাইল (১ = বিসমিল্লাহ, ৬+৭ একসাথে) — কুরআন প্লেয়ারের একই নিয়ম */
  function fileOf(s, a) { if (s === 1) return a <= 5 ? '001' + pad3(a + 1) : '001007'; return pad3(s) + pad3(a); }

  /* ---------- প্লেয়ার ---------- */
  var P = { on: false, i: 0, rep: 0, loop: 0, list: [], audio: null, timer: 0, peek: {} };
  function audio() {
    if (P.audio) return P.audio;
    var a = P.audio = new Audio(); a.preload = 'auto';
    a.addEventListener('ended', function () { clearTimeout(P.timer); P.timer = setTimeout(next, (data().gap || 0) * 1000 + 150); });
    a.addEventListener('error', function () { if (!P.on) return; stop(); ui.toast('অডিও চালানো যায়নি — ইন্টারনেট সংযোগ দেখুন', {}); });
    return a;
  }
  function playCur() {
    var o = data(), it = P.list[P.i]; if (!it) return stop();
    var a = audio(); a.src = BASE + reciterFolder().f + '/' + fileOf(it.s, it.a) + '.mp3';
    var pr = a.play(); if (pr && pr.catch) pr.catch(function () { stop(); });
    paintPlayer();
  }
  function next() {
    if (!P.on) return;
    var o = data();
    P.rep++;
    if (P.rep < o.rep) return playCur();
    P.rep = 0; P.i++;
    if (P.i < P.list.length) return playCur();
    P.loop++; P.i = 0;
    if (o.loop === 0 || P.loop < o.loop) return playCur();          /* ০ = বারবার (∞) */
    stop(); ui.toast('অংশটি শেষ হলো — মাশাআল্লাহ, এবার লেখা লুকিয়ে নিজে পড়ে দেখুন', { type: 'success' });
  }
  function start(fromIdx) {
    var o = data(), s = o.last.s, a = Math.min(o.last.a, o.last.b), b = Math.max(o.last.a, o.last.b);
    P.list = []; for (var x = a; x <= b; x++) { if (s === 1 && x === 7) continue; P.list.push({ s: s, a: x }); }   /* ফাতিহার ৬-৭ একটি ফাইল */
    P.on = true; P.i = Math.max(0, Math.min(P.list.length - 1, fromIdx || 0)); P.rep = 0; P.loop = 0;
    try { var q = Q(); if (q && q.w.QuranAudio && q.w.QuranAudio.isPlaying && q.w.QuranAudio.isPlaying()) q.w.QuranAudio.toggle(); } catch (e) {}   /* কুরআন প্লেয়ার চললে থামানো */
    playCur();
  }
  function stop() { P.on = false; clearTimeout(P.timer); try { if (P.audio) P.audio.pause(); } catch (e) {} paintPlayer(); }
  W.addEventListener('pt:pagehome', stop);
  setInterval(function () { if (P.on && (W.PTTools.current() !== 'hifz' || !D.getElementById('tool-overlay').classList.contains('is-open'))) stop(); }, 1000);
  D.addEventListener('visibilitychange', function () { if (D.hidden && P.on) stop(); });

  function paintPlayer() {
    var b = D.getElementById('hz-player'); if (!b) return;
    var o = data(), it = P.list[P.i];
    b.querySelector('.hz-st').innerHTML = P.on && it ? 'আয়াত <b>' + bn(it.s === 1 && it.a === 6 ? '৬–৭' : it.a) + '</b> · ' + bn(P.rep + 1) + '/' + bn(o.rep) + ' বার' + (o.loop !== 1 ? ' · চক্র ' + bn(P.loop + 1) + (o.loop ? '/' + bn(o.loop) : '') : '') : 'চালু করলে আয়াত ধরে ধরে বারবার শোনাবে';
    var pb = b.querySelector('[data-act="play"]'); if (pb) { pb.innerHTML = ic(P.on ? 'pause' : 'play'); pb.setAttribute('aria-label', P.on ? 'থামান' : 'চালু করুন'); }
    [].forEach.call(D.querySelectorAll('#tool-body .hz-a'), function (el) { el.classList.toggle('is-now', P.on && it && +el.getAttribute('data-a') === it.a); });
    /* শুধু আয়াত বদলালে স্ক্রল — নইলে প্রতি পুনরাবৃত্তিতে পেজ নড়ে, ইউজারের চাপ ভুল জায়গায় পড়ে */
    var now = D.querySelector('#tool-body .hz-a.is-now'), key = it ? it.s + ':' + it.a : '';
    if (now && P.on && P.scrolled !== key) { P.scrolled = key; try { now.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) {} }
    if (!P.on) P.scrolled = '';
  }

  function viewText(t, mode, a) {
    if (mode === 'full' || P.peek[a]) return esc(t);
    if (mode === 'first') { var w = t.split(/\s+/); return esc(w[0]) + ' <span class="hz-dots">' + w.slice(1).map(function () { return '…'; }).join(' ') + '</span>'; }
    return '<span class="hz-hide">চাপ দিয়ে দেখুন</span>';
  }

  function render(el) {
    var q = Q(), o = data();
    if (!q) {
      el.innerHTML = '<div class="tk-wrap"><div class="tk-card pt-card hz-load"><span class="pt-spinner"></span><p class="tk-p">কুরআনের লেখা প্রস্তুত হচ্ছে…</p></div></div>';
      try { W.__ptPages.load('f1'); } catch (e) {}
      var t0 = Date.now(), iv = setInterval(function () { if (Q() || Date.now() - t0 > 20000) { clearInterval(iv); if (W.PTTools.current() === 'hifz') ui.rerender(); } }, 400);
      return;
    }
    var A = q.A, s = o.last.s, sura = A.quranModel[s - 1], n = sura.ayahs.length;
    var a = Math.max(1, Math.min(n, o.last.a)), b = Math.max(a, Math.min(n, o.last.b));
    var M = memo(o, s), name = (A.SURAH_BN && A.SURAH_BN[s - 1]) || '';
    var total = Object.keys(o.sura).reduce(function (t, k) { return t + (o.sura[k] || []).length; }, 0);
    var opts = A.quranModel.map(function (x, i) { return '<option value="' + (i + 1) + '"' + (i + 1 === s ? ' selected' : '') + '>' + bn(i + 1) + '. ' + esc((A.SURAH_BN || [])[i] || '') + ' (' + bn(x.ayahs.length) + ')</option>'; }).join('');
    var ay = '';
    for (var x = a; x <= b; x++) {
      var t = sura.ayahs[x - 1].text, done = M.indexOf(x) >= 0;
      ay += '<div class="hz-a' + (done ? ' is-done' : '') + '" data-a="' + x + '"><div class="hz-ah"><span class="pt-numbadge">' + bn(x) + '</span>' +
        '<button type="button" class="pt-chip tk-chip hz-mk' + (done ? ' is-on' : '') + '" data-act="mk" data-v="' + x + '" aria-pressed="' + done + '">' + ic(done ? 'check' : 'plus') + (done ? 'মুখস্থ' : 'মুখস্থ হয়েছে') + '</button>' +
        '<button type="button" class="tk-x" data-act="from" data-v="' + x + '" aria-label="এখান থেকে শুনুন">' + ic('play') + '</button></div>' +
        '<p class="pt-ar hz-ar" dir="rtl" lang="ar" data-act="peek" data-v="' + x + '">' + viewText(t, o.view, x) + '</p></div>';
    }
    el.innerHTML = '<div class="tk-wrap">' +
      '<div class="pt-stats tk-stats"><div class="pt-stat"><div class="pt-stat__value">' + bn(M.length) + '<small>/' + bn(n) + '</small></div><div class="pt-stat__label">' + esc(name) + '</div></div>' +
        '<div class="pt-stat"><div class="pt-stat__value">' + bn(total) + '</div><div class="pt-stat__label">মোট মুখস্থ আয়াত</div></div>' +
        '<div class="pt-stat"><div class="pt-stat__value">' + bn(Object.keys(o.sura).filter(function (k) { return (o.sura[k] || []).length >= A.quranModel[k - 1].ayahs.length; }).length) + '</div><div class="pt-stat__label">পুরো সূরা</div></div></div>' +
      ui.card({ icon: 'quran', title: 'কোন অংশ মুখস্থ করবেন?', body:
        '<label class="hz-sel"><span>সূরা</span><select data-in="sura">' + opts + '</select></label>' +
        '<div class="hz-rng"><span>আয়াত</span><span class="tk-step"><button type="button" class="pt-iconbtn" data-act="ra" data-v="-1" aria-label="কমান">' + ic('minus') + '</button><b>' + bn(a) + '</b><button type="button" class="pt-iconbtn" data-act="ra" data-v="1" aria-label="বাড়ান">' + ic('plus') + '</button></span>' +
          '<span>থেকে</span><span class="tk-step"><button type="button" class="pt-iconbtn" data-act="rb" data-v="-1" aria-label="কমান">' + ic('minus') + '</button><b>' + bn(b) + '</b><button type="button" class="pt-iconbtn" data-act="rb" data-v="1" aria-label="বাড়ান">' + ic('plus') + '</button></span></div>' +
        '<div class="tk-lbl tk-lbl--sm">প্রতি আয়াত কতবার?</div>' + ui.chips('rep', [1, 3, 5, 7, 10], o.rep) +
        '<div class="tk-lbl tk-lbl--sm">পুরো অংশ কতবার?</div>' + ui.chips('loop', [[1, '১'], [2, '২'], [3, '৩'], [0, 'বারবার']], o.loop) +
        '<div class="tk-lbl tk-lbl--sm">প্রতি আয়াতের পর বিরতি (নিজে পড়ার সময়)</div>' + ui.chips('gap', [[0, 'নেই'], [3, '৩ সে.'], [5, '৫ সে.'], [10, '১০ সে.']], o.gap) }) +
      '<div class="tk-card pt-card hz-player" id="hz-player"><button type="button" class="pt-iconbtn hz-pb" data-act="prev" aria-label="আগের আয়াত">' + ic('prev') + '</button>' +
        '<button type="button" class="hz-play" data-act="play" aria-label="চালু করুন">' + ic('play') + '</button>' +
        '<button type="button" class="pt-iconbtn hz-pb" data-act="next" aria-label="পরের আয়াত">' + ic('next') + '</button><span class="hz-st"></span>' +
        '<small class="hz-rc">কারি: ' + esc(reciterFolder().n) + ' · কুরআন প্লেয়ার থেকে বদলানো যায়</small></div>' +
      ui.seg('view', [['full', 'পুরো লেখা'], ['first', 'প্রথম শব্দ'], ['hide', 'লুকানো']], o.view) +
      '<div class="hz-list">' + ay + '</div>' +
      '<p class="tk-fine">' + ic('info') + 'পরামর্শ: প্রতিদিন অল্প (৩–৫ আয়াত) — আগে শুনে শুনে, তারপর "প্রথম শব্দ", শেষে "লুকানো" করে নিজে পড়ুন। পরের দিন নতুন অংশের আগে আগেরটা একবার ঝালিয়ে নিন।</p></div>';
    var sel = el.querySelector('select[data-in="sura"]');
    if (sel) sel.addEventListener('change', function () { var d = data(), ns = +sel.value, nn = A.quranModel[ns - 1].ayahs.length; stop(); d.last = { s: ns, a: 1, b: Math.min(nn, 5) }; save(d); ui.rerender(); });
    paintPlayer();
  }

  T.register('hifz', {
    title: 'হিফজ মোড', sub: 'শুনে শুনে, ধাপে ধাপে মুখস্থ', icon: 'quran', group: 'learn', order: 20,
    hub: { t: 'হিফজ মোড', s: 'আয়াত বারবার শোনা, লেখা লুকিয়ে যাচাই, মুখস্থের অগ্রগতি' },
    render: function (el) { render(el); },
    onEvent: function (kind, name, v) {
      var o = data(), q = Q(); if (!q) return;
      var n = q.A.quranModel[o.last.s - 1].ayahs.length;
      if (kind === 'chip' && (name === 'rep' || name === 'loop' || name === 'gap')) { o[name] = +v; save(o); ui.rerender(); }
      else if (kind === 'seg' && name === 'view') { o.view = v; P.peek = {}; save(o); ui.rerender(); }
      else if (kind === 'act' && (name === 'ra' || name === 'rb')) {
        stop();
        if (name === 'ra') { o.last.a = Math.max(1, Math.min(n, o.last.a + (+v))); if (o.last.b < o.last.a) o.last.b = o.last.a; }
        else { o.last.b = Math.max(o.last.a, Math.min(n, o.last.b + (+v))); }
        save(o); ui.rerender();
      }
      else if (kind === 'act' && name === 'play') { if (P.on) stop(); else start(0); }
      else if (kind === 'act' && name === 'from') { var idx = 0; start(0); P.list.forEach(function (it, i) { if (it.a === +v) idx = i; }); P.i = idx; P.rep = 0; playCur(); }
      else if (kind === 'act' && (name === 'next' || name === 'prev')) { if (!P.on) start(0); P.i = Math.max(0, Math.min(P.list.length - 1, P.i + (name === 'next' ? 1 : -1))); P.rep = 0; playCur(); }
      else if (kind === 'act' && name === 'mk') {
        var s = String(o.last.s), arr = o.sura[s] || [], i = arr.indexOf(+v);
        if (i >= 0) arr.splice(i, 1); else { arr.push(+v); arr.sort(function (x, y) { return x - y; }); }
        o.sura[s] = arr; if (!arr.length) delete o.sura[s]; save(o);
        if (i < 0) { ui.haptic('success'); if (arr.length === n) ui.toast('পুরো সূরা মুখস্থ — মাশাআল্লাহ! আল্লাহ কবুল করুন', { type: 'success' }); }
        var on = P.on; ui.rerender(); if (on) paintPlayer();
      }
      else if (kind === 'act' && name === 'peek') {
        if (o.view === 'full') return;
        P.peek[v] = 1; var p = D.querySelector('#tool-body .hz-ar[data-v="' + v + '"]'), t = q.A.quranModel[o.last.s - 1].ayahs[v - 1].text;
        if (p) p.innerHTML = esc(t);
        setTimeout(function () { delete P.peek[v]; var p2 = D.querySelector('#tool-body .hz-ar[data-v="' + v + '"]'); if (p2) p2.innerHTML = viewText(t, data().view, +v); }, 4000);
      }
    }
  });
})();
