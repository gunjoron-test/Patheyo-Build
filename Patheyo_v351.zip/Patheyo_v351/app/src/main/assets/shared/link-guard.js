/*!
 * shared/link-guard.js — v346 (নিরাপত্তা ৪): বিপজ্জনক লিংকে ক্লিক আটকানো (সব পেজে, সবার আগে লোড হয়)
 *
 * অ্যাপের পেজগুলো অনেক নেটিভ ব্রিজ (অ্যাকাউন্ট, ব্যাকআপ, পেমেন্ট…) ছুঁতে পারে। বাইরে থেকে আসা কোনো লেখায়
 * (এড, নোটিফিকেশন, ডাউনলোড করা ফাইল) কখনো "javascript:" বা এমন লিংক ঢুকে পড়লে ক্লিকেই কোড চলে যেত।
 * এখানে শুধু এগুলো চলতে দেওয়া হয়: https:, http:, mailto:, tel:, আর একই পেজের/অ্যাপের নিজের ঠিকানা (#, আপেক্ষিক পথ)।
 * নতুন ধরনের লিংক লাগলে ALLOW-এ যোগ করুন — কিন্তু javascript:/data:/file:/intent:/content: কখনো নয়।
 */
(function () {
  'use strict';
  var ALLOW = { 'https:': 1, 'http:': 1, 'mailto:': 1, 'tel:': 1 };
  function bad(href) {
    if (href == null) return false;
    var h = String(href).replace(/[\u0000- \u007f-\u009f]/g, '');   /* "java\nscript:" ধরনের লুকোচুরিও ধরা */
    var m = /^([a-z][a-z0-9+.\-]*):/i.exec(h);
    if (!m) return false;                                                /* আপেক্ষিক পথ বা #অংশ — ঠিক আছে */
    var scheme = m[1].toLowerCase() + ':';
    if (ALLOW[scheme]) return false;
    if (scheme === location.protocol) return false;                      /* অ্যাপের নিজের পেজ (file:/https: যেটায় চলছে) */
    return true;
  }
  function guard(e) {
    var t = e.target, a = t && t.closest ? t.closest('a[href], area[href]') : null;
    if (!a) return;
    if (bad(a.getAttribute('href'))) {
      e.preventDefault(); e.stopImmediatePropagation();
      try { console.warn('[link-guard] blocked', String(a.getAttribute('href')).slice(0, 40)); } catch (x) {}
    }
  }
  ['click', 'auxclick'].forEach(function (ev) { document.addEventListener(ev, guard, true); });
  window.__ptLinkGuardBad = bad;   /* পরীক্ষার জন্য */
})();
