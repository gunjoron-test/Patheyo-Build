package com.gunjoron.patheyo.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.ContextThemeWrapper
import com.gunjoron.patheyo.R

/**
 * v35: সিস্টেম লোকেশন-পারমিশন চাওয়ার আগে ইউজারকে বুঝিয়ে বলার গ্লাস পপআপ।
 * আপডেট পপআপের সাথে হুবহু একই ডিজাইন (GlassStyle)।
 */
object LocationPermissionDialog {

    private const val PREFS = "patheyo_permission_prefs"
    private const val KEY_DECLINED = "loc_rationale_declined"

    fun alreadyDeclined(activity: Activity): Boolean =
        activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).getBoolean(KEY_DECLINED, false)

    /** onAllow: ইউজার "অনুমতি" চাপলে (এখন সিস্টেম পপআপ চাইতে হবে)।  onDone: "না" চাপলে বা ব্যাক করলে। */
    fun show(activity: Activity, onAllow: () -> Unit, onDone: () -> Unit) {
        val themed = ContextThemeWrapper(activity, R.style.Theme_Patheyo)
        val view = LayoutInflater.from(themed).inflate(R.layout.dialog_location_permission, null)

        view.findViewById<TextView>(R.id.tvAppName).text = DialogText.nameWithTag(
            activity, GlassStyle.appLabel(activity), activity.getString(R.string.loc_perm_tag), latinTag = false
        )
        view.findViewById<TextView>(R.id.tvNotes).text = DialogText.formatList(
            activity, activity.getString(R.string.loc_perm_benefits), activity.getColor(R.color.update_tag_text)
        )

        var chose = false
        val dialog = AlertDialog.Builder(themed).setView(view).setCancelable(true).create()
        dialog.setOnDismissListener { if (!chose) { chose = true; onDone() } }
        val prepared = GlassStyle.prepare(activity, dialog)

        GlassStyle.limitHeight(view.findViewById(R.id.svNotes), maxDp = 200)

        view.findViewById<View>(R.id.btnAllow).setOnClickListener {
            chose = true; dialog.dismiss(); onAllow()
        }
        view.findViewById<View>(R.id.btnDeny).setOnClickListener {
            chose = true
            activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putBoolean(KEY_DECLINED, true).apply()
            dialog.dismiss(); onDone()
        }

        dialog.show()
        GlassStyle.present(activity, dialog, view, prepared)
    }
}
