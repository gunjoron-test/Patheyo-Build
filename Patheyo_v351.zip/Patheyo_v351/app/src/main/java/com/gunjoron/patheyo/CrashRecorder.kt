package com.gunjoron.patheyo

// v351: "অ্যাপ খুলছে না, কিছু বলছেও না" — ধরনের সমস্যার আসল কারণ ফোনেই ধরে রাখার ব্যবস্থা।
//
// দুই উৎস থেকে রিপোর্ট জমা হয় (অ্যাপের প্রাইভেট ফোল্ডারে: filesDir/diag/, সর্বোচ্চ ৬টি, প্রতিটি ≤ ১৬KB):
//  ১) অ্যাপের নিজের কোডে কোনো থ্রেডে ধরা-না-পড়া ত্রুটি (StartupGuard-এর হ্যান্ডলার থেকে) — স্ট্যাক-ট্রেসসহ।
//  ২) Android-এর নিজের খাতা (ApplicationExitInfo, Android 11+): আগের বার প্রসেস কেন মরেছিল — ক্র্যাশ, নেটিভ ক্র্যাশ,
//     ANR (অ্যাপ জমে যাওয়া — সাথে মেইন থ্রেডের ট্রেস), শুরুতেই ব্যর্থ। এতে এমন কারণও ধরা পড়ে যা অ্যাপের কোড কখনো দেখে না।
//
// গোপনীয়তা/নিরাপত্তা: রিপোর্টে শুধু কারিগরি তথ্য (ফোনের মডেল, Android ও অ্যাপের ভার্সন, নেট আছে কি না, স্ট্যাক-ট্রেস)।
// কোথাও নিজে থেকে পাঠানো হয় না — ইউজার চাইলে "সমস্যার রিপোর্ট" পেজ থেকে নিজে কপি/শেয়ার করেন।

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.os.Looper
import android.webkit.JavascriptInterface
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CrashRecorder {
    private const val DIR = "diag"
    private const val PREFS = "patheyo_diag"
    private const val K_SEEN = "exit_seen_ts"
    private const val K_UNREAD = "unread"
    private const val MAX_FILES = 6
    private const val MAX_CHARS = 16_000

    @Volatile private var appCtx: Context? = null

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    private fun dir(c: Context) = File(c.filesDir, DIR).apply { mkdirs() }
    private fun stamp(ms: Long) = try { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms)) } catch (_: Throwable) { ms.toString() }

    private fun header(c: Context, title: String, at: Long): String {
        val ver = try { val p = c.packageManager.getPackageInfo(c.packageName, 0); "${p.versionName} (${if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else @Suppress("DEPRECATION") p.versionCode.toLong()})" } catch (_: Throwable) { "?" }
        val wv = try { if (Build.VERSION.SDK_INT >= 26) android.webkit.WebView.getCurrentWebViewPackage()?.versionName ?: "?" else "?" } catch (_: Throwable) { "?" }
        return "== $title ==\nসময়: ${stamp(at)}\nঅ্যাপ: $ver · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "WebView: $wv · নেট: ${if (StartupGuard.isOnline(c)) "আছে" else "নেই"}\n"
    }

    private fun write(c: Context, kind: String, text: String) {
        try {
            val d = dir(c)
            File(d, "r_${System.currentTimeMillis()}_$kind.txt").writeText(if (text.length > MAX_CHARS) text.take(MAX_CHARS) + "\n…(কাটা)" else text)
            d.listFiles()?.sortedByDescending { it.name }?.drop(MAX_FILES)?.forEach { try { it.delete() } catch (_: Throwable) {} }
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(K_UNREAD, true).commit()
        } catch (_: Throwable) {}
    }

    /** StartupGuard-এর হ্যান্ডলার থেকে — প্রসেস মরার আগে দ্রুত, সিঙ্ক্রোনাসভাবে লেখা */
    @Volatile private var recorded = 0
    fun record(thread: Thread, error: Throwable, swallowed: Boolean) {
        val c = appCtx ?: return
        if (swallowed && ++recorded > 12) return          // একই ত্রুটি বারবার হলে ডিস্ক ভরে না যায়
        try {
            val sw = StringWriter(); error.printStackTrace(PrintWriter(sw))
            val main = thread === Looper.getMainLooper()?.thread
            write(c, if (swallowed) "caught" else "crash",
                header(c, if (swallowed) "ধরা পড়া ত্রুটি (অ্যাপ চলেছে)" else "ক্র্যাশ", System.currentTimeMillis()) +
                    "থ্রেড: ${thread.name}${if (main) " (মেইন)" else ""}\n\n$sw")
        } catch (_: Throwable) {}
    }

    /** অ্যাপ চালু হলে (ব্যাকগ্রাউন্ড থ্রেডে) — Android-এর খাতা থেকে আগের অস্বাভাবিক বন্ধ হওয়াগুলো তুলে রাখা */
    fun collectExitInfo(c: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val seen = sp.getLong(K_SEEN, 0L)
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val list = am.getHistoricalProcessExitReasons(c.packageName, 0, 10)
            var newest = seen
            for (e in list) {
                if (e.timestamp <= seen) continue
                if (e.timestamp > newest) newest = e.timestamp
                val name = when (e.reason) {
                    ApplicationExitInfo.REASON_CRASH -> "ক্র্যাশ (Java)"
                    ApplicationExitInfo.REASON_CRASH_NATIVE -> "নেটিভ ক্র্যাশ"
                    ApplicationExitInfo.REASON_ANR -> "ANR — অ্যাপ জমে গিয়েছিল"
                    ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "শুরুতেই ব্যর্থ"
                    ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "অতিরিক্ত রিসোর্স ব্যবহার"
                    else -> null
                } ?: continue
                val sb = StringBuilder(header(c, "Android-এর রেকর্ড: $name", e.timestamp))
                sb.append("বিবরণ: ").append(e.description ?: "-").append('\n')
                sb.append("গুরুত্ব: ").append(e.importance).append(" · মেমরি PSS: ").append(e.pss).append("KB\n")
                if (e.reason == ApplicationExitInfo.REASON_ANR) {
                    try {
                        e.traceInputStream?.bufferedReader()?.use { r ->
                            val all = r.readText()
                            val i = all.indexOf("\"main\"")
                            sb.append("\n--- মেইন থ্রেড ---\n").append(if (i >= 0) all.substring(i, minOf(all.length, i + 7000)) else all.take(7000))
                        }
                    } catch (_: Throwable) {}
                }
                write(c, "exit", sb.toString())
            }
            if (newest != seen) sp.edit().putLong(K_SEEN, newest).apply()
        } catch (_: Throwable) {}
    }

    fun hasUnread(c: Context) = try { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(K_UNREAD, false) && (dir(c).listFiles()?.isNotEmpty() == true) } catch (_: Throwable) { false }

    fun report(c: Context): String {
        return try {
            val files = dir(c).listFiles()?.sortedByDescending { it.name } ?: emptyList()
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(K_UNREAD, false).apply()
            if (files.isEmpty()) "" else files.joinToString("\n\n") { try { it.readText() } catch (_: Throwable) { "" } }
        } catch (_: Throwable) { "" }
    }

    fun clear(c: Context) {
        try { dir(c).listFiles()?.forEach { it.delete() } } catch (_: Throwable) {}
        try { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(K_UNREAD, false).apply() } catch (_: Throwable) {}
    }
}

/** JS: PatheyoDiag (shell/js/39-diag.js) */
class DiagBridge(private val ctx: Context) {
    @JavascriptInterface fun hasUnread(): Boolean = CrashRecorder.hasUnread(ctx)
    @JavascriptInterface fun report(): String = CrashRecorder.report(ctx)
    @JavascriptInterface fun clear() = CrashRecorder.clear(ctx)
}
