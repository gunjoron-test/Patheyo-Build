// app/src/main/java/com/gunjoron/patheyo/alarm/AzanVoice.kt
// v350 (প্রিমিয়াম): "নিজের পছন্দের আজানের কণ্ঠ" — ইউজার ফোন থেকে একটি অডিও ফাইল বাছেন, অ্যাপ সেটি নিজের
// প্রাইভেট ফোল্ডারে (filesDir/azan/custom.audio) কপি করে রাখে, আর ওয়াক্তের আজানে সেটিই বাজে।
//
// কেন বাইরের "আজানের কণ্ঠ" ডাউনলোড নয়: রেকর্ডিংগুলোর ব্যবহারের অনুমতি (লাইসেন্স) নিশ্চিত নয়; ইউজারের নিজের
// বাছা ফাইলে সে সমস্যা নেই, আর যেকোনো মুয়াজ্জিনের কণ্ঠ বেছে নেওয়া যায়।
//
// নিরাপত্তা (SECURITY_RULES.md):
//  - প্রিমিয়াম যাচাই নেটিভে (PremiumBridge.isActive — সার্ভারের লেখা অবস্থা, uid-বাঁধা)। JS-এর কথায় নয়।
//    প্রিমিয়াম শেষ হলে ফাইল থাকলেও বাজে না — বাজে অ্যাপের নিজের আজান।
//  - ফাইল: সর্বোচ্চ ১৫ MB, ৫ সেকেন্ড–৮ মিনিট, MediaMetadataRetriever দিয়ে সত্যিই অডিও কিনা যাচাই। না মিললে মুছে ফেলা।
//  - ফাইলের নাম শুধু দেখানোর জন্য, ৬০ অক্ষরে কাটা ও নিয়ন্ত্রণ-অক্ষর বাদ; JS-এ JSON হয়ে যায় (JS-এ textContent/esc)।
//  - কোনো স্টোরেজ পারমিশন লাগে না (সিস্টেম ডকুমেন্ট-পিকার)।
package com.gunjoron.patheyo.alarm

import android.app.Activity
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.gunjoron.patheyo.premium.PremiumBridge
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

object AzanVoice {
    private const val PREFS = "patheyo_azan_voice"
    private const val MAX_BYTES = 15L * 1024 * 1024
    private const val MIN_MS = 5_000L
    private const val MAX_MS = 8L * 60 * 1000

    private fun dir(ctx: Context) = File(ctx.filesDir, "azan").apply { mkdirs() }
    private fun file(ctx: Context) = File(dir(ctx), "custom.audio")

    /** আজানের সার্ভিস এটি ডাকে: প্রিমিয়াম চালু আর ফাইল ঠিক থাকলে সেটির পথ, নইলে null (= অ্যাপের নিজের আজান) */
    fun customFileIfAllowed(ctx: Context): File? {
        val f = file(ctx)
        if (!f.isFile || f.length() <= 0L) return null
        return if (PremiumBridge.isActive(ctx)) f else null
    }

    fun state(ctx: Context): JSONObject {
        val f = file(ctx)
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val has = f.isFile && f.length() > 0L
        return JSONObject()
            .put("custom", has)
            .put("name", if (has) sp.getString("name", "") ?: "" else "")
            .put("sec", if (has) sp.getLong("ms", 0L) / 1000 else 0)
            .put("premium", PremiumBridge.isActive(ctx))
            .put("active", has && PremiumBridge.isActive(ctx))
    }

    private fun cleanName(raw: String?): String {
        val s = (raw ?: "").replace(Regex("[\\p{Cntrl}<>]"), "").trim()
        return if (s.length > 60) s.take(57) + "…" else s
    }

    /** পিকার থেকে আসা ফাইল কপি ও যাচাই। ফল: {ok, code?, …state} */
    fun importFrom(ctx: Context, uri: Uri): JSONObject {
        if (!PremiumBridge.isActive(ctx)) return JSONObject().put("ok", false).put("code", "premium")
        val tmp = File(dir(ctx), "incoming.tmp")
        try {
            var name = ""
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0) ?: ""
                        val size = if (c.isNull(1)) -1L else c.getLong(1)
                        if (size > MAX_BYTES) return JSONObject().put("ok", false).put("code", "big")
                    }
                }
            } catch (_: Throwable) {}
            var total = 0L
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf); if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) { out.close(); tmp.delete(); return JSONObject().put("ok", false).put("code", "big") }
                        out.write(buf, 0, n)
                    }
                }
            } ?: return JSONObject().put("ok", false).put("code", "read")

            // সত্যিই চালানো যায় এমন অডিও কিনা
            val mmr = MediaMetadataRetriever()
            val ms: Long
            try {
                mmr.setDataSource(tmp.absolutePath)
                val hasAudio = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
                val hasVideo = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
                ms = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                if (hasAudio != "yes" || hasVideo == "yes") { tmp.delete(); return JSONObject().put("ok", false).put("code", "type") }
            } catch (_: Throwable) {
                tmp.delete(); return JSONObject().put("ok", false).put("code", "type")
            } finally { try { mmr.release() } catch (_: Throwable) {} }
            if (ms < MIN_MS) { tmp.delete(); return JSONObject().put("ok", false).put("code", "short") }
            if (ms > MAX_MS) { tmp.delete(); return JSONObject().put("ok", false).put("code", "long") }

            val dst = file(ctx)
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) { tmp.copyTo(dst, overwrite = true); tmp.delete() }
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("name", cleanName(name).ifEmpty { "আমার আজান" }).putLong("ms", ms).apply()
            return state(ctx).put("ok", true)
        } catch (_: Throwable) {
            tmp.delete()
            return JSONObject().put("ok", false).put("code", "read")
        }
    }

    fun reset(ctx: Context): JSONObject {
        try { file(ctx).delete() } catch (_: Throwable) {}
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        return state(ctx).put("ok", true)
    }
}

/** JS-এর জন্য (shell/js/38-azan-voice.js) — নাম: PatheyoAzanVoice */
class AzanVoiceBridge(private val activity: Activity, private val webView: WebView, private val launchPicker: ((Uri?) -> Unit) -> Unit) {
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var player: MediaPlayer? = null

    private fun emit(id: String, o: JSONObject) {
        val safeId = id.replace(Regex("[^A-Za-z0-9_]"), "").take(24)
        val js = "window.__ptAzanCb&&window.__ptAzanCb(" + JSONObject.quote(safeId) + "," + JSONObject.quote(o.toString()) + ")"
        try { webView.post { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} } } catch (_: Throwable) {}
    }

    @JavascriptInterface fun state(): String = AzanVoice.state(activity.applicationContext).toString()

    @JavascriptInterface fun pick(id: String) {
        val ctx = activity.applicationContext
        if (!PremiumBridge.isActive(ctx)) { emit(id, JSONObject().put("ok", false).put("code", "premium")); return }
        activity.runOnUiThread {
            try {
                launchPicker { uri ->
                    if (uri == null) { emit(id, JSONObject().put("ok", false).put("code", "cancel")); return@launchPicker }
                    io.execute { emit(id, AzanVoice.importFrom(ctx, uri)) }
                }
            } catch (_: Throwable) { emit(id, JSONObject().put("ok", false).put("code", "read")) }
        }
    }

    @JavascriptInterface fun reset(): String { stopPreview(); return AzanVoice.reset(activity.applicationContext).toString() }

    /** শুনে দেখা (মিডিয়া ভলিউমে; ৩০ সেকেন্ড পর নিজে থামে)। which = "custom" | "default" */
    @JavascriptInterface fun preview(which: String) {
        activity.runOnUiThread {
            stopPreview()
            try {
                val ctx = activity.applicationContext
                val mp = MediaPlayer()
                mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                val f = File(File(ctx.filesDir, "azan"), "custom.audio")
                if (which == "custom" && f.isFile) mp.setDataSource(f.absolutePath)
                else ctx.assets.openFd("azan.mp3").use { mp.setDataSource(it.fileDescriptor, it.startOffset, it.length) }
                mp.setOnPreparedListener { it.start() }
                mp.setOnCompletionListener { stopPreview() }
                mp.setOnErrorListener { _, _, _ -> stopPreview(); true }
                mp.prepareAsync()
                player = mp
                webView.postDelayed({ if (player === mp) stopPreview() }, 30_000L)
            } catch (_: Throwable) { stopPreview() }
        }
    }

    @JavascriptInterface fun stopPreview() {
        val p = player; player = null
        if (p != null) {
            try { p.stop() } catch (_: Throwable) {}
            try { p.release() } catch (_: Throwable) {}
            try { webView.post { try { webView.evaluateJavascript("window.__ptAzanStopped&&window.__ptAzanStopped()", null) } catch (_: Throwable) {} } } catch (_: Throwable) {}
        }
    }
}
