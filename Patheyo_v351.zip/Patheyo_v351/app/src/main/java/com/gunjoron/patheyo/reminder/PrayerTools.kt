package com.gunjoron.patheyo.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.gunjoron.patheyo.MainActivity
import com.gunjoron.patheyo.R
import com.gunjoron.patheyo.widget.PrayerWidgetProvider
import org.json.JSONObject
import java.util.Calendar

/**
 * v347: মসজিদের জামাতের সময় (রিমাইন্ডার) ও নামাজের সময় ফোন নীরব করা — অ্যাপ বন্ধ থাকলেও।
 *
 * JS (shell/js/23-prayer-tools.js) → PatheyoPrayerTools.save({jamaat:{…}, silent:{…}})
 *   jamaat = { on, remind(মিনিট, ০=বন্ধ), w:{fajr|dhuhr|asr|maghrib|isha: {m:"after", v:মিনিট} | {m:"at", t:"HH:mm"} | {m:"off"}}, jumuah:"HH:mm"|"" }
 *   silent = { on, mode:"vibrate"|"silent", from:"jamaat"|"azan", after(মিনিট), dur(মিনিট), jdur(জুম’আর মিনিট), w:{fajr:true,…} }
 * আজানের সময় আসে নামাজ পেজের সেভ করা সময়সূচি থেকে (PrayerWidgetProvider.KEY_TIMINGS — আজান/উইজেটের একই উৎস)।
 *
 * নীরব করার নিয়ম (ইউজারের নিজের সেটিং কখনো নষ্ট হয় না):
 *   • শুরুর সময় ফোন "সাধারণ" (রিং) মোডে থাকলে তবেই বদলায়; আগে থেকেই নীরব/ভাইব্রেট থাকলে কিছু করে না।
 *   • শেষে ফেরত দেয় শুধু তখন, যখন ফোন এখনো ঠিক আমাদের বসানো মোডে আছে (মাঝে ইউজার নিজে বদলালে আর হাত দেয় না)।
 *   • "পুরো নীরব" করতে Android-এর "বিরক্ত করবেন না" অনুমতি লাগে; না থাকলে ভাইব্রেট করে।
 * সব অ্যালার্ম এক-বারের; বাজার পর পরেরটা বসে। সময়সূচি বদলালে/রিবুটে ReminderAlarms.scheduleAll আবার বসায়।
 */
object PrayerTools {
    private const val PREFS = "patheyo_prayer_tools"
    private const val KEY = "cfg"
    private const val K_PREV = "silent_prev"        // নীরব করার আগের মোড
    private const val K_SET = "silent_set"          // আমরা কোন মোড বসিয়েছিলাম
    private const val K_UNTIL = "silent_until"
    private const val QUIET_CHANNEL = "patheyo_quiet_v1"
    private const val QUIET_NOTIF_ID = 9258
    private const val END_REQ = 9259
    const val PREFIX = "pt:"

    // কী → (জামাত-রিমাইন্ডারের রিকোয়েস্ট কোড, নীরব-শুরুর রিকোয়েস্ট কোড, নাম "-এর")
    private val WAQT = linkedMapOf(
        "fajr" to Triple(9241, 9251, "ফজরের"), "dhuhr" to Triple(9242, 9252, "যোহরের"), "asr" to Triple(9243, 9253, "আসরের"),
        "maghrib" to Triple(9244, 9254, "মাগরিবের"), "isha" to Triple(9245, 9255, "এশার")
    )
    private val HHMM = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(ctx: Context): JSONObject = try { JSONObject(prefs(ctx).getString(KEY, null) ?: "{}") } catch (_: Throwable) { JSONObject() }

    /** JS থেকে আসা কনফিগ যাচাই করে রাখা — অজানা/ভুল মান বাদ */
    fun save(ctx: Context, json: String) {
        val inc = try { JSONObject(json) } catch (_: Throwable) { return }
        val out = JSONObject()
        inc.optJSONObject("jamaat")?.let { j ->
            val w = JSONObject()
            val jw = j.optJSONObject("w") ?: JSONObject()
            for (k in WAQT.keys) {
                val o = jw.optJSONObject(k) ?: continue
                when (o.optString("m")) {
                    "after" -> w.put(k, JSONObject().put("m", "after").put("v", o.optInt("v", 15).coerceIn(0, 120)))
                    "at" -> if (HHMM.matches(o.optString("t"))) w.put(k, JSONObject().put("m", "at").put("t", o.optString("t")))
                    else -> w.put(k, JSONObject().put("m", "off"))
                }
            }
            val jum = j.optString("jumuah", "")
            out.put("jamaat", JSONObject().put("on", j.optBoolean("on", false))
                .put("remind", j.optInt("remind", 10).coerceIn(0, 60))
                .put("w", w).put("jumuah", if (HHMM.matches(jum)) jum else ""))
        }
        inc.optJSONObject("silent")?.let { s ->
            val w = JSONObject(); val sw = s.optJSONObject("w") ?: JSONObject()
            for (k in WAQT.keys) w.put(k, sw.optBoolean(k, true))
            out.put("silent", JSONObject().put("on", s.optBoolean("on", false))
                .put("mode", if (s.optString("mode") == "silent") "silent" else "vibrate")
                .put("from", if (s.optString("from") == "azan") "azan" else "jamaat")
                .put("after", s.optInt("after", 10).coerceIn(0, 90))
                .put("dur", s.optInt("dur", 20).coerceIn(5, 120))
                .put("jdur", s.optInt("jdur", 45).coerceIn(10, 150))
                .put("w", w))
        }
        prefs(ctx).edit().putString(KEY, out.toString()).apply()
        schedule(ctx)
    }

    // ---------------------------------------------------------------- সময়ের হিসাব

    private fun timings(ctx: Context): JSONObject? = try {
        ctx.applicationContext.getSharedPreferences(PrayerWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PrayerWidgetProvider.KEY_TIMINGS, null)?.let { JSONObject(it) }
    } catch (_: Throwable) { null }

    private fun minutesOf(hhmm: String): Int? = try {
        val p = hhmm.trim().split(" ")[0].split(":"); p[0].toInt() * 60 + p[1].toInt()
    } catch (_: Throwable) { null }

    /** নির্দিষ্ট দিনের (dayOffset: ০ = আজ, ১ = কাল) জামাতের মিনিট (দিনের শুরু থেকে); না থাকলে null */
    private fun jamaatMin(cfg: JSONObject, t: JSONObject, key: String, isFriday: Boolean): Int? {
        val j = cfg.optJSONObject("jamaat") ?: return null
        if (key == "dhuhr" && isFriday) { j.optString("jumuah").takeIf { it.isNotEmpty() }?.let { return minutesOf(it) } }
        val o = j.optJSONObject("w")?.optJSONObject(key) ?: return null
        val azan = minutesOf(t.optString(key, "")) ?: return null
        return when (o.optString("m")) {
            "after" -> azan + o.optInt("v", 15)
            "at" -> minutesOf(o.optString("t"))
            else -> null
        }
    }

    /** আজ বা কালকের যে মুহূর্তটি এখনো আসেনি: f(dayOffset, isFriday) → দিনের মিনিট */
    private fun nextAt(f: (Boolean) -> Int?): Long? {
        for (d in 0..1) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, d); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val min = f(cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) ?: continue
            val at = cal.timeInMillis + min * 60_000L
            if (at > System.currentTimeMillis() + 5_000L) return at
        }
        return null
    }

    // ---------------------------------------------------------------- শিডিউল

    private fun pi(ctx: Context, req: Int, kind: String): PendingIntent =
        PendingIntent.getBroadcast(ctx, req, Intent(ctx, ReminderReceiver::class.java).putExtra(ReminderAlarms.EXTRA_KIND, kind),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** সময় গুরুত্বপূর্ণ (নীরব শুরু/শেষ) — এক্সাক্ট, কিন্তু স্ট্যাটাস-বারে অ্যালার্ম-ঘড়ি নয় */
    private fun exact(ctx: Context, am: AlarmManager, at: Long, p: PendingIntent) {
        try {
            val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p); return }
        } catch (_: Throwable) {}
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Throwable) {}
    }

    fun schedule(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val cfg = get(app)
        val t = timings(app)
        val jam = cfg.optJSONObject("jamaat")
        val sil = cfg.optJSONObject("silent")
        for ((key, meta) in WAQT) {
            // ১) জামাতের আগে মনে করানো
            try {
                val p = pi(app, meta.first, PREFIX + "jam:" + key)
                val remind = jam?.optInt("remind", 10) ?: 0
                val at = if (jam?.optBoolean("on") == true && remind > 0 && t != null)
                    nextAt { fri -> jamaatMin(cfg, t, key, fri)?.minus(remind) } else null
                if (at == null) am.cancel(p) else exact(app, am, at, p)
            } catch (_: Throwable) {}
            // ২) নীরব শুরু
            try {
                val p = pi(app, meta.second, PREFIX + "sil:" + key)
                val on = sil?.optBoolean("on") == true && sil.optJSONObject("w")?.optBoolean(key, true) != false && t != null
                val at = if (on) nextAt { fri -> silentStartMin(cfg, t!!, key, fri) } else null
                if (at == null) am.cancel(p) else exact(app, am, at, p)
            } catch (_: Throwable) {}
        }
        // নীরব বন্ধ করা হলে, আমাদের বসানো নীরবতা চলতে থাকলে এখনই ফেরত
        if (sil?.optBoolean("on") != true && prefs(app).getInt(K_SET, -1) != -1) restore(app)
    }

    /** নীরব শুরুর মিনিট: জামাতের ২ মিনিট আগে (জামাতের সময় দেওয়া থাকলে), নইলে আজানের X মিনিট পরে */
    private fun silentStartMin(cfg: JSONObject, t: JSONObject, key: String, fri: Boolean): Int? {
        val s = cfg.optJSONObject("silent") ?: return null
        if (s.optString("from") == "jamaat" && cfg.optJSONObject("jamaat")?.optBoolean("on") == true) {
            jamaatMin(cfg, t, key, fri)?.let { return (it - 2).coerceAtLeast(0) }
        }
        val azan = minutesOf(t.optString(key, "")) ?: return null
        return azan + s.optInt("after", 10)
    }

    // ---------------------------------------------------------------- বাজলে

    fun fire(ctx: Context, kind: String) {
        val app = ctx.applicationContext
        val rest = kind.removePrefix(PREFIX)
        try {
            when {
                rest.startsWith("jam:") -> fireJamaat(app, rest.removePrefix("jam:"))
                rest.startsWith("sil:") -> startSilent(app, rest.removePrefix("sil:"))
                rest == "silend" -> restore(app)
            }
        } finally { if (rest != "silend") schedule(app) }
    }

    private fun bn(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")
    private fun t12(min: Int): String {
        val h = (min / 60) % 24; val m = min % 60
        val part = when { h < 4 -> "রাত"; h < 6 -> "ভোর"; h < 12 -> "সকাল"; h < 15 -> "দুপুর"; h < 18 -> "বিকাল"; h < 20 -> "সন্ধ্যা"; else -> "রাত" }
        return part + " " + bn("${if (h % 12 == 0) 12 else h % 12}:${m.toString().padStart(2, '0')}")
    }

    private fun fireJamaat(app: Context, key: String) {
        val meta = WAQT[key] ?: return
        val cfg = get(app); val t = timings(app) ?: return
        val jam = cfg.optJSONObject("jamaat") ?: return
        if (!jam.optBoolean("on")) return
        val fri = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
        val min = jamaatMin(cfg, t, key, fri) ?: return
        val name = if (key == "dhuhr" && fri) "জুম’আর" else meta.third
        val left = jam.optInt("remind", 10)
        ReminderAlarms.post(app, meta.first, "$name জামাত ${bn(left.toString())} মিনিট পরে",
            "জামাত ${t12(min)}-এ। অজু করে মসজিদের দিকে রওনা দিন — প্রতিটি কদমে সওয়াব।", 1)
    }

    private fun audio(app: Context) = app.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun dndGranted(ctx: Context): Boolean = try {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted
    } catch (_: Throwable) { false }

    private fun startSilent(app: Context, key: String) {
        val cfg = get(app); val s = cfg.optJSONObject("silent") ?: return
        if (!s.optBoolean("on") || s.optJSONObject("w")?.optBoolean(key, true) == false) return
        val am = audio(app) ?: return
        val sp = prefs(app)
        val fri = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY
        val dur = if (key == "dhuhr" && fri) s.optInt("jdur", 45) else s.optInt("dur", 20)
        val until = System.currentTimeMillis() + dur * 60_000L
        val already = sp.getInt(K_SET, -1) != -1
        if (!already) {
            if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return          // ইউজার আগে থেকেই নীরব/ভাইব্রেটে — হাত দিই না
            val want = if (s.optString("mode") == "silent" && dndGranted(app)) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_VIBRATE
            try { am.ringerMode = want } catch (_: Throwable) { return }
            if (am.ringerMode != want) return
            sp.edit().putInt(K_PREV, AudioManager.RINGER_MODE_NORMAL).putInt(K_SET, want).apply()
        }
        sp.edit().putLong(K_UNTIL, until).apply()
        (app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.let { exact(app, it, until, pi(app, END_REQ, PREFIX + "silend")) }
        quietNotice(app, WAQT[key]?.third ?: "", dur, fri && key == "dhuhr")
    }

    private fun restore(app: Context) {
        val sp = prefs(app)
        val set = sp.getInt(K_SET, -1)
        val prev = sp.getInt(K_PREV, AudioManager.RINGER_MODE_NORMAL)
        sp.edit().remove(K_SET).remove(K_PREV).remove(K_UNTIL).apply()
        try { NotificationManagerCompat.from(app).cancel(QUIET_NOTIF_ID) } catch (_: Throwable) {}
        try { (app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.cancel(pi(app, END_REQ, PREFIX + "silend")) } catch (_: Throwable) {}
        if (set == -1) return
        val am = audio(app) ?: return
        if (am.ringerMode == set) { try { am.ringerMode = prev } catch (_: Throwable) {} }     // ইউজার মাঝে বদলালে আর হাত দিই না
    }

    /** নীরব থাকা অবস্থায় শান্ত নোটিফিকেশন (শব্দ নেই) — "এখনই চালু করুন" বোতামসহ */
    private fun quietNotice(app: Context, nameEr: String, dur: Int, jumuah: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = app.getSystemService(NotificationManager::class.java)
                if (nm?.getNotificationChannel(QUIET_CHANNEL) == null) nm?.createNotificationChannel(
                    NotificationChannel(QUIET_CHANNEL, "নামাজের সময় নীরব", NotificationManager.IMPORTANCE_LOW).apply {
                        description = "নামাজের জন্য ফোন নীরব থাকার সময় শব্দহীন একটি নোটিফিকেশন"; setSound(null, null)
                    })
            }
            val endNow = PendingIntent.getBroadcast(app, END_REQ + 1,
                Intent(app, ReminderReceiver::class.java).putExtra(ReminderAlarms.EXTRA_KIND, PREFIX + "silend"),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val open = PendingIntent.getActivity(app, QUIET_NOTIF_ID, Intent(app, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP); putExtra("go", "tool:jamaat")
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val title = if (jumuah) "জুম’আর জন্য ফোন নীরব" else "${nameEr} নামাজের জন্য ফোন নীরব"
            val n = NotificationCompat.Builder(app, QUIET_CHANNEL)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(ContextCompat.getColor(app, R.color.brand_notif_color))
                .setContentTitle(title)
                .setContentText("${bn(dur.toString())} মিনিট পর ফোন নিজে থেকেই আগের অবস্থায় ফিরবে।")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setSilent(true).setOngoing(true)
                .setContentIntent(open)
                .addAction(0, "এখনই চালু করুন", endNow)
                .build()
            NotificationManagerCompat.from(app).notify(QUIET_NOTIF_ID, n)
        } catch (_: Throwable) {}
    }

    fun openDndSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
        }
    }

    fun state(ctx: Context): JSONObject {
        val sp = prefs(ctx)
        return JSONObject().put("dnd", dndGranted(ctx))
            .put("silentNow", sp.getInt(K_SET, -1) != -1)
            .put("until", sp.getLong(K_UNTIL, 0L))
    }
}

/** JS ↔ জামাত ও নীরব (window.PatheyoPrayerTools) */
class PrayerToolsBridge(private val ctx: Context) {
    @JavascriptInterface fun save(json: String) { try { if (json.length < 8000) PrayerTools.save(ctx, json) } catch (_: Throwable) {} }
    @JavascriptInterface fun state(): String = try { PrayerTools.state(ctx).toString() } catch (_: Throwable) { "{}" }
    @JavascriptInterface fun openDndSettings() { try { PrayerTools.openDndSettings(ctx) } catch (_: Throwable) {} }
    @JavascriptInterface fun endSilentNow() { try { PrayerTools.fire(ctx, PrayerTools.PREFIX + "silend") } catch (_: Throwable) {} }
}
