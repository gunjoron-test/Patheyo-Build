package com.gunjoron.patheyo

// v341: অফলাইন/নেটহীন অবস্থায় অ্যাপ ঢোকা নিশ্চিত করার "শুরুর পাহারাদার"।
//
// সমস্যা: ইন্টারনেট ছাড়া খুললে স্প্ল্যাশ এসে অ্যাপ নিজে বন্ধ হয়ে যেত। কারণ ছিল শুরুর সময়ে চলা নেটনির্ভর কাজগুলো
// (Firebase, FCM, আপডেট-চেক, হার্টবিট ইত্যাদি) — এদের কোনো একটার ব্যাকগ্রাউন্ড থ্রেডের ব্যর্থতা পুরো অ্যাপ নামিয়ে দিত।
//
// এখন তিনটি সুরক্ষা:
//  ১) নেটওয়ার্ক/IO ত্রুটি কোনো ব্যাকগ্রাউন্ড থ্রেডে (বা কোরুটিনে) অব্যবহৃত থেকে গেলেও অ্যাপ বন্ধ হবে না — শুধু লগ হবে।
//  ২) প্রতিটি নেটনির্ভর শুরুর কাজ একটি "ধাপ" (stage) হিসেবে চলে। কোনো ধাপের মাঝে প্রসেস মরে গেলে (ক্র্যাশ/ANR)
//     পরের বার ওই ধাপ ২৪ ঘণ্টা বাদ থাকে — অ্যাপ নিজে ঢুকে যায়, বাকি সব কাজ চলে।
//  ৩) নেটনির্ভর কাজগুলো শুধু নেট থাকলে (বা নেট আসার পর) চলে — নেট না থাকলে শুরুতে ওগুলো ছোঁয়াই হয় না।

import android.app.ActivityManager
import android.app.Application
import android.app.ApplicationExitInfo
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeoutException

object StartupGuard {

    private const val TAG = "PatheyoGuard"
    private const val PREFS = "patheyo_boot_guard"
    private const val K_STAGE = "running_stage"      // এখন যে ধাপ চলছে (খালি = কোনোটাই চলছে না)
    private const val K_STAGE_AT = "running_stage_at"
    private const val K_BAD = "bad_stages"           // {"ধাপের নাম": কখন পর্যন্ত বাদ (ms)}
    private const val BAD_FOR_MS = 24L * 60L * 60L * 1000L

    @Volatile private var appCtx: Context? = null
    private var installed = false

    /** Application.onCreate()-এর একদম শুরুতে একবার */
    fun install(app: Application) {
        if (installed) return
        installed = true
        appCtx = app.applicationContext
        try { CrashRecorder.init(app) } catch (_: Throwable) { }
        try { settleLastRun(app) } catch (_: Throwable) { }
        try {
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                val swallow = try { shouldSwallow(thread, error) } catch (_: Throwable) { false }
                // v351: প্রতিটি ত্রুটি আগে ফোনে লিখে রাখা (সমস্যার রিপোর্ট) — তারপর সিদ্ধান্ত
                try { CrashRecorder.record(thread, error, swallow) } catch (_: Throwable) { }
                if (swallow) {
                    Log.w(TAG, "ত্রুটি ধরা হলো, অ্যাপ চলতে থাকবে (thread=${thread.name})", error)
                } else {
                    previous?.uncaughtException(thread, error)
                }
            }
        } catch (_: Throwable) { }
    }

    /**
     * v351: শুরুর ভারী কিন্তু অপেক্ষা-না-করলেও-চলে কাজ (অ্যালার্ম/নোটিফিকেশন/তারিখ-কার্ড শিডিউল ইত্যাদি) একটি
     * ব্যাকগ্রাউন্ড থ্রেডে, পরপর (একসাথে নয়) — যাতে অ্যাপের প্রথম পর্দা আঁকতে মেইন থ্রেড আটকে না থাকে।
     * পুরনো/ধীর ফোনে বা অনেকদিন পর খুললে (অনেক অ্যালার্ম নতুন করে বসানো লাগে) এগুলো মেইন থ্রেডে সেকেন্ডের পর
     * সেকেন্ড নিত — তখন স্ক্রিন সাদা/আটকে থাকত, কোনো কোনো ফোন অ্যাপটাই বন্ধ করে দিত।
     */
    private val bg: java.util.concurrent.ExecutorService by lazy {
        java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "patheyo-startup").apply { priority = Thread.NORM_PRIORITY - 1 } }
    }
    fun background(name: String, block: () -> Unit) {
        try {
            bg.execute {
                try { block() } catch (t: Throwable) { Log.e(TAG, "পেছনের কাজ ব্যর্থ (অ্যাপ চলছে): $name", t) }
            }
        } catch (t: Throwable) {
            try { block() } catch (_: Throwable) { }
        }
    }

    /** ফোন এখন ইন্টারনেটে যুক্ত কি না (দ্রুত, ব্লক করে না) */
    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork
            if (net == null) {
                false
            } else {
                val caps = cm.getNetworkCapabilities(net)
                caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        } catch (_: Throwable) { false }
    }

    /**
     * একটি শুরুর কাজ নিরাপদে চালায়: আগের বার এই ধাপের মাঝে প্রসেস মরে থাকলে বাদ দেয়,
     * নইলে চালায় (ভেতরে exception হলে শুধু লগ)। নিজে কখনো exception ছোঁড়ে না।
     */
    fun stage(name: String, block: () -> Unit) {
        val c = appCtx
        if (c != null && isBad(c, name)) {
            Log.w(TAG, "ধাপ বাদ (আগের বার এখানে প্রসেস মরেছিল): $name")
            return
        }
        val sp = c?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        try { sp?.edit()?.putString(K_STAGE, name)?.putLong(K_STAGE_AT, System.currentTimeMillis())?.apply() } catch (_: Throwable) { }
        try {
            block()
        } catch (t: Throwable) {
            Log.e(TAG, "ধাপ ব্যর্থ (অ্যাপ চলছে): $name", t)
        }
        try { sp?.edit()?.putString(K_STAGE, "")?.apply() } catch (_: Throwable) { }
    }

    // ------------------------------------------------------------------ ভেতরের অংশ

    private fun shouldSwallow(thread: Thread, error: Throwable): Boolean {
        val main = Looper.getMainLooper()?.thread
        // v351: ব্যাকগ্রাউন্ড থ্রেডের যেকোনো ত্রুটিতে (শুধু নেটওয়ার্ক নয়) — ঐ থ্রেডটাই শেষ হয়, পুরো অ্যাপ নয়।
        // আগে শুধু নেটওয়ার্ক/IO ত্রুটি ধরা হতো; অন্য কোনো ত্রুটি (যেমন কোনো SDK-র ভেতরের, ফাইল/ডাটাবেস, অনুমতি)
        // কোনো ব্যাকগ্রাউন্ড কাজে ঘটলে ইউজারের সামনে খোলা অ্যাপটাই নিঃশব্দে বন্ধ হয়ে যেত।
        if (thread !== main) return true
        if (!isNetworkError(error)) return false
        // মেইন থ্রেডে শুধু কোরুটিনের ব্যর্থতা (হ্যান্ডলারটা সাধারণ মেথডের মতো ডাকা হয়, থ্রেড মরে না)
        return Thread.currentThread().stackTrace.any { it.className.startsWith("kotlinx.coroutines.CoroutineExceptionHandler") }
    }

    private fun isNetworkError(e: Throwable?): Boolean {
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth < 8) {
            if (t is IOException || t is TimeoutException) return true
            val n = t.javaClass.name
            if (n == "android.os.NetworkOnMainThreadException") return true
            if (n.startsWith("com.google.firebase") && n.contains("Network")) return true
            t = t.cause
            depth++
        }
        return false
    }

    private fun readBad(sp: android.content.SharedPreferences): JSONObject =
        try { JSONObject(sp.getString(K_BAD, "{}") ?: "{}") } catch (_: Throwable) { JSONObject() }

    private fun isBad(c: Context, name: String): Boolean {
        return try {
            val sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            readBad(sp).optLong(name, 0L) > System.currentTimeMillis()
        } catch (_: Throwable) { false }
    }

    /** আগের রানে কোনো ধাপ চলা অবস্থায় প্রসেস মরে থাকলে সেই ধাপ কিছুদিনের জন্য বাদ */
    private fun settleLastRun(app: Application) {
        val sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stage = sp.getString(K_STAGE, "") ?: ""
        if (stage.isEmpty()) return
        val since = sp.getLong(K_STAGE_AT, 0L)
        val ed = sp.edit().putString(K_STAGE, "")
        if (diedAbnormally(app, since)) {
            val bad = readBad(sp)
            bad.put(stage, System.currentTimeMillis() + BAD_FOR_MS)
            ed.putString(K_BAD, bad.toString())
            Log.e(TAG, "আগের রানে \"$stage\" ধাপে প্রসেস মরেছিল — ২৪ ঘণ্টা এটি বাদ থাকবে")
        }
        ed.apply()
    }

    @Suppress("NewApi")
    private fun diedAbnormally(ctx: Context, since: Long): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return true
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.getHistoricalProcessExitReasons(ctx.packageName, 0, 5).any {
                it.timestamp >= since - 1000L && (
                    it.reason == ApplicationExitInfo.REASON_CRASH ||
                    it.reason == ApplicationExitInfo.REASON_CRASH_NATIVE ||
                    it.reason == ApplicationExitInfo.REASON_ANR ||
                    it.reason == ApplicationExitInfo.REASON_INITIALIZATION_FAILURE)
            }
        } catch (_: Throwable) { true }
    }
}
